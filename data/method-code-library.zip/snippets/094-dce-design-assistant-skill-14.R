# R：dfidx 构造选择数据（mlogit 用）
library(mlogit)
md <- dfidx(dat, idx = c("id", "alt"), choice = "choice")