library(fixest)

# 模型 A：pooled OLS + 医院聚类稳健标准误（不吸收固定效应）
m_ols <- feols(y ~ treated*post*group, cluster = ~id, data = dat)
summary(m_ols)

# 模型 B：医院 + 时间固定效应（treated、post 因共线被自动移除）
m_fe <- feols(y ~ treated*post*group | id + time, cluster = ~id, data = dat)
summary(m_fe)

# 三重交互系数 δ（fixest 中交互用 ":" 连接，对应 Stata 的 #）
coef(m_fe)["treated:post:group"]