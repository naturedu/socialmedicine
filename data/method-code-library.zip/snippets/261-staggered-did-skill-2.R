library(fixest)
# 教学接口：d中never-treated的g按sunab文档编码；不得直接复制did的0编码
# d$g_sa <- ifelse(d$g==0, max(d$year)+100, d$g)
# m <- feols(y ~ sunab(g_sa,year,ref.p=-1) | id+year,data=d,cluster=~id)
# iplot(m)