m <- lm(y ~ time + post + time_after, data = dat)
lmtest::coeftest(m, vcov = sandwich::NeweyWest(m, lag = 1))