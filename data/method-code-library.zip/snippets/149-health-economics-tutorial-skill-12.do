* Stata：贴现因子与 10 年年金贴现因子（r = 5%）
scalar r = 0.05
scalar df = 0
forvalues t = 1/10 {
    scalar df = df + 1 / (1 + r)^`t'
}
display "10 年、5% 的年金贴现因子 = " %9.4f df      // 7.7217

* 贴现后的增量成本与增量效果
scalar dC = (12000 - 8000) * df
scalar dE = (0.78 - 0.70) * df
display "贴现后 ΔC = " %9.2f dC                      // 30886.93 元
display "贴现后 ΔE = " %9.4f dE                      // 0.6177 QALY

* 贴现率敏感性（0–8%）
foreach rr in 0 0.03 0.05 0.08 {
    scalar df = 0
    forvalues t = 1/10 {
        scalar df = df + 1 / (1 + `rr')^`t'
    }
    display "r = " `rr' "：10 年年金贴现因子 = " %9.4f df
}