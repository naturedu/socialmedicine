* 当前数据：每行一个去重后的原始研究，rev1-rev3 为0/1
egen n_reviews = rowtotal(rev1-rev3)
keep if n_reviews > 0
quietly count
scalar r = r(N)
quietly summarize n_reviews
scalar N = r(sum)
scalar c = 3
display (N-r)/(r*c-r)