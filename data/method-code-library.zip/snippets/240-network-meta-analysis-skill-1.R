library(netmeta)
d <- data.frame(
  study = paste0("trial", 1:6),
  t1 = c("education","digital","family","digital","family","family"),
  t2 = c("usual","usual","usual","education","education","digital"),
  TE = log(c(.85,.72,.76,.87,.91,1.05)),
  seTE = c(.14,.16,.17,.19,.20,.18)
)
fit <- netmeta(TE, seTE, t1, t2, studlab=study, data=d,
  sm="OR", reference.group="usual", common=FALSE, random=TRUE,
  method.tau="REML", small.values="desirable")
summary(fit)
netgraph(fit)
netleague(fit)
netsplit(fit)
decomp.design(fit)
netrank(fit, small.values="good")
sessionInfo()