* Stata：示例 long 数据（1 名受访者、2 个选择集、各 3 个方案）
clear
input id choice_set alt choice a b c d
1 1 1 1 0 0 1 1
1 1 2 0 1 1 0 0
1 1 3 0 0 0 0 0
1 2 1 0 1 0 1 0
1 2 2 1 0 1 0 1
1 2 3 0 0 0 0 0
end

* 宽表 → 长表（宽表每行一个选择集，选项变量带后缀 _1/_2/_3）
reshape long choice_ a_ b_ c_ d_, i(id choice_set) j(alt)
rename (choice_ a_ b_ c_ d_) (choice a b c d)

* effects coding 示例：三水平属性 a（0/1/2 → -1/0/1）
recode a (0 = -1) (1 = 0) (2 = 1)