# 0/1教学标签；真实任务应保留无法判断、缺失及多标签规则
gold <- c(1,0,1,0,1,0,1,0)
pred <- c(1,0,0,0,1,1,1,0)
tab <- table(factor(gold,levels=0:1),factor(pred,levels=0:1))
precision <- tab[2,2]/sum(tab[,2])
recall <- tab[2,2]/sum(tab[2,])
c(precision=precision,recall=recall,F1=2*precision*recall/(precision+recall))
# 稀有标签、空分母、地区/年份分层及区间需在正式分析中单独处理。