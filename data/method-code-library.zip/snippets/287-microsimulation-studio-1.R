# 虚构四状态教学模型，不读取任何受访者数据。
source("scripts/microsimulation_demo.R")
demo <- run_demo(n = 5000, cycles = 20, reps = 8, psa_draws = 40,
                 seed = 20261024, out = "microsimulation-demo")
demo$comparison
demo$mcse