* Stata：gsem 多层（医院随机截距）；语法细节以 help gsem 为准
gsem (HL -> x1 x2 x3) (SE -> y1 y2 y3) (SE <- HL M1[hospital]), vce(cluster hospital)
estat icc