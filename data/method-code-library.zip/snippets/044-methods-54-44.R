library(fixest)
m <- feols(y ~ i(time, treat, ref = -1) | id + time, data = dat)
coefplot(m)                              // 事件研究图