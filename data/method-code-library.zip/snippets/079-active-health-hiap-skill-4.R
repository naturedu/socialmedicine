library(readxl)
df <- read_excel("GBD_results.xlsx")     # 从 GBD Results Tool 导出的 CSV/XLSX
agg <- aggregate(deaths ~ year + location, data = df, sum)
# 与政策时点对齐：政策前后负担变化（配合 ITS/DID skill 做因果评估）