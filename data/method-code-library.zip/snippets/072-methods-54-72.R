# R：lavaan 双层写法
library(lavaan)
model2 <- '
  level: 1
    SEw =~ y1 + y2 + y3
    SEw ~ HLw
  level: 2
    SEb =~ y1 + y2 + y3
    SEb ~ HLb '
fit2 <- sem(model2, data = dat, cluster = "hospital")