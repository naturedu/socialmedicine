# R
install.packages(c("lavaan", "QCA", "quanteda"))