* Stata：预测试数据体检——受访者选择 opt-out 的次数分布
egen n_optout = total(choice == 1 & alt == 3), by(id)
tab n_optout
* 提示：某受访者所有题都选 opt-out，说明属性或任务设计可能有问题