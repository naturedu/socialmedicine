* Stata：为每个选择集追加 opt-out 行（alt == 3，属性全为 0）
local nset 4
forvalues s = 1/`nset' {
    set obs `=_N+1'
    replace choice_set = `s' if _n == _N
    replace alt = 3 if _n == _N
    foreach v in a b c d {
        replace `v' = 0 if _n == _N
    }
}