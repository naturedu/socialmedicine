## R：DDD 三重交互（主效应被固定效应吸收时仅保留三重交互）
feols(y ~ treat:post:group | id + time, data = dat, cluster = ~id)