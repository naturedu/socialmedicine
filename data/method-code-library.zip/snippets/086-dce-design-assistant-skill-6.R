# R：正交主效应设计（DoE.base）
library(DoE.base)
des24 <- oa.design(nlevels = c(2, 2, 2, 2))    # 2^4 → 8 行 L8
des33 <- oa.design(nlevels = c(3, 3, 3, 3))    # 3^4 → 9 行 L9
as.data.frame(des24)

# R：D-效率设计（AlgDesign）
library(AlgDesign)
full36 <- expand.grid(x1 = c(0, 1, 2), x2 = c(0, 1, 2), x3 = c(0, 1), x4 = c(0, 1))
dopt <- optFederov(~ ., data = full36, nTrials = 16, criterion = "D")
dopt$design                                  # 选中的 16 个 profile
dopt$D                                       # D-效率值