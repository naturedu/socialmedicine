# R：clogit（survival）与 mlogit 等价实现
library(survival)
clogit(choice ~ a + b + c + d + strata(choice_set), data = dat)

library(mlogit)
m1 <- mlogit(choice ~ a + b + c + d | 0, data = md)
summary(m1)