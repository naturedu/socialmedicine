* 官方（Stata 16+/17+/18+）
meta funnelplot, esrefline(1)
confunnel                       // 轮廓增强漏斗图（Stata 17+；选项以 help confunnel 为准）
meta bias, egger begg harbord   // Stata 18+；以 help meta bias 为准

* SSC（metafunnel 一般随 metan 附带；以 ssc describe metan 为准）
metafunnel _ES _seES
metabias lnOR selnOR, egger     // Egger：效应量与 SE 两变量
metabias lnOR selnOR, begg      // Begg 秩相关（选项名以 help metabias 为准）
metabias a b c d, harbord       // Harbord：四格表单元 a b c d