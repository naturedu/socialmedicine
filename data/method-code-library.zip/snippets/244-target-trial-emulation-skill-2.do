* 真实固定时点数据需先明确基线、完整随访和混杂变量
teffects ipw (y) (a age severity, logit), ate
tebalance summarize