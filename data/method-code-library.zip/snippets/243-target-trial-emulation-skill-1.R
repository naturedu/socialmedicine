set.seed(20261023)
n <- 2000
d <- data.frame(age=rnorm(n,65,8), severity=rnorm(n))
d$a <- rbinom(n,1,plogis(-.2+.02*(d$age-65)+.5*d$severity))
d$y <- rbinom(n,1,plogis(-1+.35*d$a+.3*d$severity+.01*(d$age-65)))
psfit <- glm(a~age+severity,binomial(),data=d)
d$ps <- predict(psfit,type="response")
stopifnot(all(d$ps>0 & d$ps<1))
p <- mean(d$a)
d$w <- ifelse(d$a==1,p/d$ps,(1-p)/(1-d$ps))
print(quantile(d$w,c(0,.01,.5,.99,1)))
print(with(d, tapply(ps,a,range)))
print(sum(d$w)^2/sum(d$w^2)) # 总体有效样本量摘要；也应分组检查
library(survey)
des <- svydesign(ids=~1,weights=~w,data=d)
fit <- svyglm(y~a,design=des,family=quasibinomial(link="identity"))
coef(fit)["a"]
confint(fit)["a",]
# 研究分析还需检查加权前后平衡、权重重叠，并按估计流程考虑bootstrap。