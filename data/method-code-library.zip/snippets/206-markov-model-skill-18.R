# ============ 第 7.1 步：tornado（R） ============
phsA <- 1-exp(-0.02); phsB <- 1-exp(-0.014)
phd <- 0.010; psd <- 1-exp(-0.10)
bA <- c(phsA, phd, psd, 3000, 20000, 0.85, 0.62)   # 对照臂基线
bB <- c(phsB, phd, psd, 3500, 20000, 0.85, 0.62)   # 干预臂基线
nms <- c("对照卒中率", "干预卒中率", "背景死亡", "卒中后死亡",
         "无并发症成本", "卒中后成本", "效用-无并发症", "效用-卒中后")

makeP <- function(p) matrix(c(1-p[1]-p[2], p[1], p[2],
                              0, 1-p[3], p[3],
                              0, 0, 1), nrow = 3, byrow = TRUE)
pair_icer <- function(pA, pB) {                    # 复用第 5.2 步的 sim()
  rA <- sim(makeP(pA), pA[4], pA[5], pA[6], pA[7], 0.05, 30)
  rB <- sim(makeP(pB), pB[4], pB[5], pB[6], pB[7], 0.05, 30)
  (rB["cost"] - rA["cost"]) / (rB["qaly"] - rA["qaly"])
}
icer0 <- pair_icer(bA, bB)                         # ≈ 2139.80

tor <- t(sapply(seq_along(nms), function(i) {
  loA <- bA; loB <- bB; hiA <- bA; hiB <- bB
  if (i == 1)      { loA[1] <- bA[1]*.8; hiA[1] <- bA[1]*1.2 }
  else if (i == 2) { loB[1] <- bB[1]*.8; hiB[1] <- bB[1]*1.2 }
  else {
    j <- i - 1
    loA[j] <- bA[j]*.8; loB[j] <- bB[j]*.8
    hiA[j] <- bA[j]*1.2; hiB[j] <- bB[j]*1.2
  }
  c(lo = pair_icer(loA, loB), hi = pair_icer(hiA, hiB))
}))
tor_df <- data.frame(param = nms, lo = tor[, "lo"], hi = tor[, "hi"])
tor_df

# 基础 R tornado 图（横条 + 基线竖线）
dotchart(tor_df$lo, labels = tor_df$param,
         xlim = range(c(tor_df$lo, tor_df$hi, icer0)))
segments(tor_df$lo, seq_along(nms), tor_df$hi, seq_along(nms))
abline(v = icer0, lty = 2, col = "red")
# 负 ICER：表示该情景下落入了占优 / 西南象限，见第 6 步象限规则，勿直接比较大小