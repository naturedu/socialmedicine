# R：meta 包
funnel(m.or)
metabias(m.or, method.bias = "linreg")   // Egger（加权线性回归）
metabias(m.or, method.bias = "rank")     // Begg 秩相关
tf <- trimfill(m.or); summary(tf); funnel(tf)

# R：metafor
funnel(res)
regtest(res, model = "rma")              // Egger（meta 回归法）
trimfill(res)                            // 输出 k0 与调整后估计