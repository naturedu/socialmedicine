* SFA：Cobb-Douglas 随机前沿，半正态无效率
sfcross y x1 x2, distribution(hnormal)
predict te_sfa, te
* DEA：投入导向 BCC（先 ssc install dea）
dea x1 x2 = y, rts(vrs) ort(in)   // 效率得分；选项以 help dea 为准