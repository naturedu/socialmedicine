* Andersen 三因素变量清单（就诊行为研究示例）
* 倾向特征 predisposing：age 年龄、female 性别(0/1)、edu 教育年限
* 使能资源 enabling：lnincome 家庭收入对数、insured 是否参保(0/1)、dist 距最近机构(km)
* 需要因素 need：sahealth 自评健康(1-5)、chronic 慢病种数
logit visit age female edu lnincome insured dist sahealth chronic, or