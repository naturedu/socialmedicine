bia <- data.frame(year = 1:5, pop = 1e5, uptake = c(.2, .4, .6, .8, .9))
bia$bi <- bia$pop * bia$uptake * (c_new - c_cur)
bia                            # 逐年预算影响；sum(bia$bi) 为合计