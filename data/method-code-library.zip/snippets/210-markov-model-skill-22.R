# R：同样的极端值检验（复用 sim() 与 makeP()）
# ① 卒中率 → 0：两臂应完全相同
P0 <- makeP(c(0, phd, psd))
r01 <- sim(P0, 3000, 20000, 0.85, 0.62, 0.05)
r02 <- sim(P0, 3500, 20000, 0.85, 0.62, 0.05)
round(c(qaly_A = r01["qaly"], qaly_B = r02["qaly"], equal = r01["qaly"] == r02["qaly"]), 4)
# ② 卒中率 = 0 且死亡率 = 1：第 1 周期后全灭
sim(makeP(c(0, 1, 1)), 3000, 20000, 0.85, 0.62, 0.05)
# ③ 效用全 = 1：QALY = 贴现生命年
sim(makeP(c(phsA, phd, psd)), 0, 0, 1, 1, 0.05)["qaly"]