* Stata：无需额外安装；确认版本 ≥ 17
version