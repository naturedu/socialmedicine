# R：随机配对、分块
library(dplyr)
set.seed(2026)
prof  <- as.data.frame(des24) |> sample_frac(1)      # 随机打乱
pairs <- matrix(seq_len(nrow(prof)), ncol = 2, byrow = TRUE)
nset  <- nrow(pairs)                                  # 选择集数
nblock <- 2; per <- 2                                 # 2 个块、每块 2 题
block  <- rep(1:nblock, each = per, length.out = nset)
out <- data.frame(choice_set = rep(1:nset, each = 2),
                  block = rep(block, each = 2),
                  alt = rep(1:2, times = nset),
                  prof[as.vector(t(pairs)), ])
# opt-out 在问卷中额外提供“都不选”；数据里记 alt == 3、各属性 = 0