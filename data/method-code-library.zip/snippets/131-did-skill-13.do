* 接第 4 步 csdid
estat event                   // 官方 18；SSC 版为 csdid_estat event
csdid_plot                    // 事件研究图（官方 18 与 SSC 版均有）
* 若版本支持，亦可用 marginsplot：estat event 后 marginsplot
* （以 help csdid postestimation / help csdid_plot 为准）