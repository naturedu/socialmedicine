library(QCA)
set.seed(2026)
n <- 30
d <- data.frame(
  score = rnorm(n, 70, 15),          # 成效评分
  res   = rnorm(n, 20, 8),           # 资源投入
  staff = rnorm(n, 10, 4),           # 人员配置
  inc   = rnorm(n, 0.5, 0.2),        # 激励机制
  it    = rnorm(n, 3, 1.2))          # 信息化
d <- data.frame(
  成效   = calibrate(d$score, c(60, 75, 90)),
  资源   = calibrate(d$res, c(10, 20, 30)),
  人员   = calibrate(d$staff, c(5, 10, 15)),
  激励   = calibrate(d$inc, c(0.2, 0.5, 0.8)),
  信息化 = calibrate(d$it, c(1, 3, 5)))

tt <- truthTable(d, outcome = "成效", n.cut = 1, incl.cut = 0.8)
tt
sol <- minimize(tt, include = "?")   # 中间解
sol
XYplot(tt$tt$资源, d$成效, xlab = "资源", ylab = "成效")   # 必要条件散点（对单一条件判断必要性）