library(quanteda)
corp <- corpus(data.frame(text = interviews$text, doc_id = interviews$id))
dfm(corp, remove = stopwords("zh"), remove_punct = TRUE) |>
  textstat_frequency(n = 30)          # 高频词提示开放编码线索