# R
install.packages(c("fixest", "did", "MatchIt", "ggplot2", "cobalt", "modelsummary"))