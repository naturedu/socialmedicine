r  <- (rank(ses) - 0.5) / length(ses)   # 按经济状况排序的分数秩
ci <- 2 * cov(y, r) / mean(y)           # 协方差法集中指数