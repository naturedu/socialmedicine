* ICER 增量计算（arm：1 = 干预，0 = 对照；ttest 按组值升序，组 2 为 arm=1）
ttest c, by(arm)
scalar dC = r(mu_2) - r(mu_1)
ttest e, by(arm)
scalar dE = r(mu_2) - r(mu_1)
di "ICER = " dC / dE