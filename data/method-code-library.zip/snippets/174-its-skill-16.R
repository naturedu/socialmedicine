# 主表：用 HAC 标准误覆盖（texreg；以包文档为准）
library(texreg)
hac_se <- sqrt(diag(NeweyWest(m, lag = 1, prewhite = FALSE)))
screenreg(m, override.se = hac_se,
          custom.model.names = "ITS 分段回归（HAC 标准误）")