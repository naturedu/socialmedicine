# 干预前基线平衡表
aggregate(cbind(y, adm, x1, x2) ~ treated, data = subset(dat, t == 1), FUN = mean)
# 各期均值图
means <- aggregate(y ~ treated + t, data = dat, FUN = mean)
with(means, {
    plot(t, y, type = "n", xlab = "t", ylab = "次均药品费用")
    lines(t[treated == 1], y[treated == 1], col = "red",  lwd = 2)
    lines(t[treated == 0], y[treated == 0], col = "blue", lwd = 2)
    abline(v = 2.5, lty = 2)
    legend("topright", c("处理组", "对照组"), col = c("red", "blue"), lwd = 2)
})