clear
set seed 20261023
capture program drop mc_mean
program define mc_mean, rclass
    drop _all
    set obs 200
    gen byte a = _n > 100
    gen y = .3*a + rnormal(0,cond(a==1,1.5,1))
    quietly regress y a, vce(robust)
    return scalar est = _b[a]
    return scalar se = _se[a]
    return scalar covered = abs((_b[a]-.3)/_se[a]) <= invttail(e(df_r),.025)
end
simulate est=r(est) se=r(se) covered=r(covered), reps(2000): mc_mean
summarize est se covered
* Stata示例用稳健回归区间，R示例用Welch区间，二者并非完全同一方法。