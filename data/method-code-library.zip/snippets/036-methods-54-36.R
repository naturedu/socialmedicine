library(MatchIt)
m <- matchit(t ~ x1 + x2, data = dat, method = "nearest")
md <- match.data(m)
lm(y ~ t + x1 + x2, data = md, weights = weights)
cobalt::love.plot(m, abs = TRUE)   # SMD 平衡图