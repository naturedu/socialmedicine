* id_s 是字符键，pid 仅作当前数据内面板编码，不输出映射。
assert !missing(id_s, year)
isid id_s year
egen long pid = group(id_s)
xtset pid year
xtreg y x i.year, fe vce(cluster pid)
* 单波数据不运行此面板流程；先选择合适的survey描述/横断面模型。