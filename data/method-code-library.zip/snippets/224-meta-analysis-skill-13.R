# R：亚组（byvar 须在 metagen 的原始 data 中）
update(m.or, byvar = mode)
forest(update(m.or, byvar = mode))

# R：meta 回归
metareg(m.or, ~ year)                                # meta 包（默认 REML，以 help(metareg) 为准）
rma(yi, vi, mods = ~ year, data = dat.or, method = "REML")   # metafor
rma(yi, vi, mods = ~ mode, data = dat.or, method = "REML")   # 二分类协变量等价于亚组