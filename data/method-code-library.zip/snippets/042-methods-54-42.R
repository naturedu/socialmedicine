dp <- Synth::dataprep(foo = dat, predictors = c("x1", "x2"), dependent = "y",
                      unit.variable = "id", time.variable = "time",
                      treatment.identifier = 1, controls.identifier = 2:20,
                      time.predictors.prior = 1990:1999, time.optimize.ssr = 1990:1999)
s1 <- Synth::synth(dp)