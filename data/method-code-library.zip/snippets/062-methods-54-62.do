* 个体层：age sex edu | 人际层：fam_support 家庭支持(0-3) | 社区层：park_density 绿地密度
* 随机截距两水平模型（个体嵌套于社区）
mixed behavior age sex edu fam_support park_density || community: , mle
* 跨层交互：社区环境调节个体因素
mixed behavior age sex edu fam_support c.fam_support#c.park_density || community: , mle