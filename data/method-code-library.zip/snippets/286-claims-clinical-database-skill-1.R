# 已去标识的标准化示意：每次就诊费用先聚合，避免多表多行膨胀。
stopifnot(!anyDuplicated(encounter$encounter_id))
tot <- aggregate(amount ~ encounter_id, cost_detail, sum)
a <- merge(encounter, tot, by="encounter_id", all.x=TRUE)
stopifnot(nrow(a)==nrow(encounter))
# 缺少明细先核查，不能不加判断地将NA替换为0。