* Stata：水平平衡 + 两两相关
tab1 a b c d
pwcorr a b c d