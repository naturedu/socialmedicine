# ---------- ICER 与 NMB ----------
dC   <- resB5["cost"] - resA5["cost"]
dE   <- resB5["qaly"] - resA5["qaly"]
c(dC = dC, dE = dE, ICER = dC / dE)   # 期望：dC≈726.90, dE≈0.3397, ICER≈2139.80

lam <- 100000                          # 阈值（1 倍人均 GDP）
NMB_A <- lam * resA5["qaly"] - resA5["cost"]
NMB_B <- lam * resB5["qaly"] - resB5["cost"]
c(NMB_A = NMB_A, NMB_B = NMB_B, dNMB = NMB_B - NMB_A)   # dNMB≈33243

# 象限与决策规则
if (dE > 0 & dC < 0) {
  "东南象限：占优（更便宜且更有效）→ 采纳"
} else if (dE < 0 & dC > 0) {
  "西北象限：被占优（更贵且更差）→ 拒绝"
} else if (dE > 0) {
  ifelse(dC/dE < lam, "东北象限：ICER < λ → 采纳", "东北象限：ICER ≥ λ → 拒绝")
} else {
  ifelse(dC/dE > lam,
         "西南象限：ICER > λ（节省的钱高于损失 QALY 的价值）→ 可采纳",
         "西南象限：ICER ≤ λ → 拒绝")
}
# 本例期望输出：dC>0 且 dE>0 → 东北象限，ICER≈2140 < 100000 → 采纳