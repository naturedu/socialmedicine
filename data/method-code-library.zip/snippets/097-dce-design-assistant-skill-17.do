* 随机系数：a、b、c 正态，d 固定
mixlogit choice a b c d, group(choice_set) id(id) rand(a b c) nrep(500)
est store mixl
fitstat                                     // AIC/BIC，与 clogit 比较

* 对数正态费用 + 相关随机参数（ln(1) = rand() 中第 1 个随机参数取对数正态）
mixlogit choice a b c d, group(choice_set) id(id) rand(a b c) ln(1) corr nrep(500)

* WTP：mixlwtp（SSC）或 delta 方法；具体语法以 help mixlwtp 为准