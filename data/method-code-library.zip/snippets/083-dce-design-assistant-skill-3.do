* Stata：生成 2^4 全因子（16 行），用于观察所有组合
clear
set obs 16
gen a = mod(_n-1, 2)              // 0/1
gen b = mod(int((_n-1)/2), 2)
gen c = mod(int((_n-1)/4), 2)
gen d = mod(int((_n-1)/8), 2)
list