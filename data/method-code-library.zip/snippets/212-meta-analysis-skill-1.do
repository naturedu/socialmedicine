* Stata（联网安装一次；metafunnel 一般随 metan 附带，缺失时单独安装）
ssc install metan, replace
ssc install metareg, replace
ssc install metabias, replace