set.seed(20261023)
n <- 1000
arrival <- cumsum(rexp(n,rate=4))
service <- rexp(n,rate=5)
start <- finish <- numeric(n)
for(i in seq_len(n)){
  start[i] <- max(arrival[i],if(i==1) 0 else finish[i-1])
  finish[i] <- start[i]+service[i]
}
wait <- start-arrival
c(mean_wait=mean(wait),p95_wait=unname(quantile(wait,.95)))