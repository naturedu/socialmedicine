library(rdrobust)
rdrobust(y = dat$y, x = dat$x, c = 0)
rddensity::rddensity(dat$x, c = 0)   # 操纵检验