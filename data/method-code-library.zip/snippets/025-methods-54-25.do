* 逐年预算影响 = 目标人群 × 渗透率 ×（新方案 − 现行方案）人均年费用
gen bi = pop * uptake * (c_new - c_cur)
list year bi
sum bi                         // 研究期内合计