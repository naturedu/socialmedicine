## R lavaan 等价写法（多题项做潜变量时用）
library(lavaan)
model <- 'intention ~ att + sn + pbc
          behavior ~ intention + pbc'
fit <- sem(model, data = d)
summary(fit, standardized = TRUE, fit.measures = TRUE)