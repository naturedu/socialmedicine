* Stata：1:1 近邻匹配估计 ATT（y 结局、t 处理、x1 x2 协变量）
teffects psmatch (y) (t x1 x2), atet
tebalance summarize          // 平衡性：SMD 与方差比
tebalance density            // 共同支撑：倾向得分重叠图