# 结果表（fixest::etable 或 modelsummary）
etable(list(m_2x2, m_psm, m_adm), cluster = ~id, fitstat = ~n)
# library(modelsummary)
# modelsummary(list("2x2" = m_2x2, "PSM-DID" = m_psm, "住院率" = m_adm), stars = TRUE)