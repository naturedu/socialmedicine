* Stata：2^(4-1) 分辨率 IV 正交主效应设计（8 行，生成元 d = a*b*c 模 2）
clear
set obs 16
gen a = mod(_n-1, 2)
gen b = mod(int((_n-1)/2), 2)
gen c = mod(int((_n-1)/4), 2)
gen d = mod(int((_n-1)/8), 2)
keep if mod(a+b+c+d, 2) == 0
list, sep(0)

* Stata：3^4 的 L9 正交设计（9 行）
clear
set obs 27
gen a = mod(_n-1, 3)
gen b = mod(int((_n-1)/3), 3)
gen c = mod(int((_n-1)/9), 3)
keep if mod(a+b+c, 3) == 0

* Stata：D-效率设计（dcreate，SSC）。示例：3 个属性、每选择集 2 个方案、12 个选择集
matrix b0 = J(1, 3, 0)                    // 先验参数（默认 0）
dcreate i.x1 i.x2 i.x3, nalt(2) nset(12) bmat(b0) seed(2026)
* 注：dcreate 要求因子变量写法；详细选项以 help dcreate 为准