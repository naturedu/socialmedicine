glm cost i.a c.x if cost>0, family(gamma) link(log) vce(robust)
margins, dydx(a)
poisson visits i.a c.x, exposure(person_time) vce(robust)
qreg cost i.a c.x, quantile(.5)