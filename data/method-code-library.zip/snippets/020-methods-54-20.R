set.seed(2026)
boot <- replicate(1000, mean(sample(cost, replace = TRUE)))
mean(cost)                       # 点估计
quantile(boot, c(.025, .975))    # 95% 百分位置信区间