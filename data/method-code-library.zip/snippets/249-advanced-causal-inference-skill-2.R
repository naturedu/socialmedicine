library(DoubleML)
library(mlr3)
library(mlr3learners)
set.seed(20261023)
n <- 600
d <- data.frame(x1=rnorm(n),x2=rnorm(n))
d$a <- .5*d$x1+rnorm(n)
d$y <- .8*d$a+d$x1+d$x2^2+rnorm(n)
obj <- DoubleMLData$new(d,y_col="y",d_cols="a",x_cols=c("x1","x2"))
fit <- DoubleMLPLR$new(obj,
  ml_l=lrn("regr.rpart"),ml_m=lrn("regr.rpart"),n_folds=5)
fit$fit()
fit$summary()