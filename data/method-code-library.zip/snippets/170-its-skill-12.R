# R（基础包）
m <- lm(y ~ time_c + level + trend_after, data = dat)
dat$fit <- fitted(m)
b <- coef(m)
dat$cf  <- b["(Intercept)"] + b["time_c"] * dat$time_c     # 反事实

plot(y ~ time, data = dat, type = "o", pch = 16, cex = 0.7, col = "gray50",
     main = "ITS：DRG 改革对次均住院费用的影响",
     xlab = "月份", ylab = "次均费用（元）")
abline(v = 24.5, lty = 3, col = "gray40")
lines(dat$time, dat$fit, col = "navy", lwd = 2)
lines(dat$time[dat$time >= 25], dat$cf[dat$time >= 25], col = "red", lwd = 2, lty = 2)
legend("bottomleft", legend = c("观测值", "模型拟合", "反事实（无干预）"),
       col = c("gray50", "navy", "red"), lty = c(1, 1, 2),
       lwd = c(1, 2, 2), bty = "n")

# ggplot2 等价写法（ggplot2 ≥ 3.4 用 linewidth，低版本用 size）
library(ggplot2)
ggplot(dat, aes(time, y)) +
  geom_point(colour = "grey50") +
  geom_vline(xintercept = 24.5, linetype = 3) +
  geom_line(aes(y = fit), colour = "navy", linewidth = 1) +
  geom_line(data = subset(dat, time >= 25), aes(y = cf),
            colour = "red", linetype = 2, linewidth = 1) +
  labs(x = "月份", y = "次均费用（元）",
       title = "ITS：DRG 改革对次均住院费用的影响") +
  theme_minimal()