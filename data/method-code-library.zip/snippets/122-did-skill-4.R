# ============================================================
# 模拟面板：60 地区 × 4 期；30 个处理组交错入组；真实 ATT = -150
# ============================================================
set.seed(2026)
N <- 60; Tmax <- 4
id  <- 1:N
g   <- c(rep(2, 10), rep(3, 10), rep(4, 10), rep(0, 30))   # 处理时点；0 = 永不受理
treated <- as.integer(g > 0)
alpha <- rnorm(N, 900, 50)          # 地区固定效应
beta  <- rnorm(N, -8, 4)            # 地区自身趋势
x1 <- rnorm(N, 0.3 * treated, 1)    # 协变量 1：与入选相关
x2 <- rnorm(N, 0, 1)                # 协变量 2

dat <- expand.grid(id = id, t = 1:Tmax)
dat$g <- g[dat$id]; dat$treated <- treated[dat$id]
dat$alpha <- alpha[dat$id]; dat$beta <- beta[dat$id]
dat$x1 <- x1[dat$id]; dat$x2 <- x2[dat$id]
dat$D <- as.integer(dat$t >= dat$g & dat$g > 0)
dat$y <- dat$alpha + dat$beta * (dat$t - 1) - 30 * (dat$t - 1) +
         (-150) * dat$D + rnorm(N * Tmax, 0, 40)                       # 次均药品费用
dat$adm <- 0.20 - 0.01 * (dat$t - 1) + (dat$alpha - 900) / 3000 +
           (-0.02) * dat$D + rnorm(N * Tmax, 0, 0.04)                  # 住院率

table(dat$g)                        # 队列规模
aggregate(y ~ treated + t, data = dat, FUN = mean)     # 各期均值（干预前应接近）