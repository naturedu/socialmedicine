library(AER)
m_iv <- ivreg(y ~ t | z, data = dat)
summary(m_iv, diagnostics = TRUE)   # 含弱工具变量诊断