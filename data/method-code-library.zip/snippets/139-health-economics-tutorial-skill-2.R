# R
install.packages("boot")      # bootstrap 置信区间；其余均为基础 R