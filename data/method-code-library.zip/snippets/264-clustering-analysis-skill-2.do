* 仅对选定连续特征标准化；先完成缺失与异常检查
egen z_age = std(age)
egen z_util = std(utilization)
egen z_cost = std(logcost)
set seed 20261023
cluster kmeans z_age z_util z_cost, k(3) name(km3)
tabulate km3