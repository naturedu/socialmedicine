* ============ 第 7.2 步：PSA（Stata：rbeta/rgamma/rnormal 循环） ============
* 分布依据：概率→beta；率/RR→lognormal（exp(rnormal)）；成本→gamma；效用→beta
* 注：1000 次 × 30 周期的 .do 循环较慢（数分钟）；可改调第 7.1 步的
* Mata markov_ce() 提速（逻辑完全相同）。
set seed 2026
local N = 1000
local T = 30
matrix PSA = J(0, 4, .)                    // 每行：cA qA cB qB
forvalues i = 1/`N' {
    * ---- 参数抽样 ----
    local p_hsA = 1 - exp(-exp(rnormal(ln(0.02), 0.20)))
    local p_hsB = 1 - exp(-exp(rnormal(ln(0.02), 0.20))*exp(rnormal(ln(0.70), 0.10)))
    local p_hd  = rbeta(24.74, 2449.26)
    local p_sd  = 1 - exp(-exp(rnormal(ln(0.10), 0.15)))
    local cA0   = rgamma(25, 120)
    local cB0   = `cA0' + rgamma(25, 20)
    local cS    = rgamma(25, 800)
    local uW    = rbeta(119.6, 21.1)
    local uS    = rbeta(57.8, 35.4)
    * ---- 对照臂队列模拟（同第 5.1 步循环） ----
    clear
    set obs `=`T'+1'
    gen healthy = .
    gen sick = .
    gen dead = .
    replace healthy = 1 in 1
    replace sick = 0 in 1
    replace dead = 0 in 1
    forvalues t = 2/`=`T'+1' {
        replace healthy = healthy[`t'-1]*(1-`p_hsA'-`p_hd') in `t'
        replace sick    = healthy[`t'-1]*`p_hsA' + sick[`t'-1]*(1-`p_sd') in `t'
        replace dead    = dead[`t'-1] + healthy[`t'-1]*`p_hd' + sick[`t'-1]*`p_sd' in `t'
    }
    gen w = 1/(1+0.05)^(_n-0.5) if _n <= `T'
    gen cA_c = (healthy*`cA0' + sick*`cS')*w
    gen qA_c = (healthy*`uW'  + sick*`uS')*w
    qui sum cA_c
    local cA_t = r(sum)
    qui sum qA_c
    local qA_t = r(sum)
    * ---- 干预臂队列模拟 ----
    replace healthy = 1 in 1
    replace sick = 0 in 1
    replace dead = 0 in 1
    forvalues t = 2/`=`T'+1' {
        replace healthy = healthy[`t'-1]*(1-`p_hsB'-`p_hd') in `t'
        replace sick    = healthy[`t'-1]*`p_hsB' + sick[`t'-1]*(1-`p_sd') in `t'
        replace dead    = dead[`t'-1] + healthy[`t'-1]*`p_hd' + sick[`t'-1]*`p_sd' in `t'
    }
    gen cB_c = (healthy*`cB0' + sick*`cS')*w
    gen qB_c = (healthy*`uW'  + sick*`uS')*w
    qui sum cB_c
    local cB_t = r(sum)
    qui sum qB_c
    local qB_t = r(sum)
    matrix PSA = PSA \ (`cA_t', `qA_t', `cB_t', `qB_t')
}
matrix colnames PSA = cA qA cB qB

* ---- 成本-效果散点图 ----
svmat PSA, names(col)
gen dC = cB - cA
gen dE = qB - qA
twoway (scatter dC dE, msize(tiny) mcolor(gs8%35)), ///
    yline(0, lpattern(dash)) xline(0, lpattern(dash)) ///
    xtitle("增量 QALY") ytitle("增量成本（元）") ///
    title("PSA 成本-效果散点图 (n=1000)") name(ce_scatter, replace)

* ---- CEAC ----
matrix CEAC = J(0, 2, .)
forvalues lam = 0(20000)300000 {
    count if dC - `lam'*dE < 0
    local pce = r(N)/_N
    matrix CEAC = CEAC \ (`lam', `pce')
}
svmat CEAC
line CEAC2 CEAC1, xtitle("阈值 λ（元/QALY）") ///
    ytitle("P(具有成本效果)") name(ceac, replace)
* 期望（示意，与随机种子有关）：本示例各阈值下 P(CE) > 0.99，P(占优) ≈ 0.36