* Stata（本教程主要用官方命令；结果表导出可选用 estout，putexcel 为官方命令）
ssc install estout, replace