library(MatchIt)
library(cobalt)
set.seed(20261023)
n <- 1000
d <- data.frame(age=rnorm(n,65,8),severity=rnorm(n))
d$a <- rbinom(n,1,plogis(-.3+.03*(d$age-65)+.5*d$severity))
d$y <- 100+8*d$a+2*d$severity+.4*d$age+rnorm(n,0,10)
m <- matchit(a~age+severity,data=d,method="nearest",distance="glm",
  link="linear.logit",estimand="ATT",ratio=1,caliper=.2,std.caliper=TRUE)
summary(m)
love.plot(m,thresholds=c(m=.1))
md <- match.data(m)
fit <- lm(y~a,data=md,weights=weights)
lmtest::coeftest(fit,vcov.=sandwich::vcovCL(fit,cluster=~subclass))
# 示例为无替换1:1匹配；复杂替换/聚类设计需重新选择推断。