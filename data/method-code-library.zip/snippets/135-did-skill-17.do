* 结果表（esttab，SSC；官方 etable 亦可）
esttab m_2x2 m_psm m_adm, b(%9.2f) se(%9.2f) star(* 0.10 ** 0.05 *** 0.01) ///
    mtitles("2x2 DID" "PSM-DID" "结局=住院率") ///
    stats(N N_clust, labels("观测数" "聚类数"))
* CS 聚合结果用 estat simple / estat event 直接导出；
* esttab 与 etable 选项以 help esttab / help etable 为准