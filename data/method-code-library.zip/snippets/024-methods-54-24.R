dat <- dat[order(dat$id, dat$t), ]
qaly <- tapply(seq_len(nrow(dat)), dat$id, function(i) {
  t <- dat$t[i]; q <- dat$q[i]
  sum(diff(t) * (head(q, -1) + tail(q, -1)) / 2)     # 梯形面积法
})