# 接第 2 步的 d2（t ∈ {1,2}；post、treated2 已定义）
library(fixest)

# ---------- 6.1 伪处理组（500 次随机重抽） ----------
set.seed(2026)
ids <- unique(d2$id)
b_null <- replicate(500, {
    fake <- sample(ids, 10)                      # 随机 10 个伪处理地区
    d2$treatedF <- as.integer(d2$id %in% fake)
    m <- feols(y ~ treatedF * post | id + t, data = d2, cluster = ~id)
    coef(m)["treatedF:post"]                     # 系数名以 coef(m) 输出为准
})
pval <- (sum(b_null <= -150) + 1) / 501          # 经验 p 值（单侧）
hist(b_null, breaks = 30, main = "伪处理组 DID 系数分布")
abline(v = -150, col = "red", lwd = 2)

# ---------- 6.2 伪时点 ----------
d_pre <- subset(dat, g %in% c(0, 3) & t %in% 1:2)
d_pre$post <- as.integer(d_pre$t == 2)
d_pre$treated3 <- as.integer(d_pre$g == 3)
feols(y ~ treated3 * post | id + t, data = d_pre, cluster = ~id)   # 预期 ≈ 0

# ---------- 6.3 剔除极端值 ----------
q <- quantile(d2$y, c(0.01, 0.99))
d2t <- subset(d2, y > q[1] & y < q[2])
feols(y ~ treated2 * post | id + t, data = d2t, cluster = ~id)

# ---------- 6.4 PSM-DID ----------
library(MatchIt)
d2pre <- subset(d2, t == 1)
m.out <- matchit(treated2 ~ x1 + x2, data = d2pre, method = "nearest", ratio = 1)
summary(m.out)                       # 匹配后标准化均值差应 < 0.1
# library(cobalt); love.plot(m.out)  # 平衡性图
md  <- match.data(m.out)             # 匹配样本（含 weights）
d2m <- subset(d2, id %in% unique(md$id))
feols(y ~ treated2 * post | id + t, data = d2m, cluster = ~id)

# ---------- 6.5 更换结局与聚类层级 ----------
feols(adm ~ treated2 * post | id + t, data = d2, cluster = ~id)     # 住院率 ≈ -0.02
d2$group3 <- ceiling(d2$id / 3)
feols(y ~ treated2 * post | id + t, data = d2, cluster = ~group3)   # 更保守聚类