* 仅基线处理、固定时点结局的教学接口，不是纵向MSM
teffects aipw (y age severity) (a age severity), ate
tebalance summarize