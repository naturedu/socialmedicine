* Stata：成本条目按研究视角纳入的示意见表（1 = 纳入，0 = 不纳入）
* 注：中文值需 Stata 17+（UTF-8）
clear
input byte payer byte system byte society str50 item
1 1 1 "药品费用（医保报销部分）"
1 1 1 "检查与住院（医保报销部分）"
0 1 1 "政府财政补助与公共卫生投入"
0 1 1 "患者自付医疗费用"
0 0 1 "交通、陪护与食宿（患者家庭）"
0 0 1 "因病损失的生产力"
end
label var payer   "医保支付方视角"
label var system  "卫生体系视角"
label var society "社会视角"
list, sep(0) noobs