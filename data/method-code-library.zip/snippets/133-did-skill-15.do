* ---------- 6.1 伪处理组（随机重抽处理组身份，500 次） ----------
preserve
keep if inlist(t, 1, 2)
gen post = (t == 2)
tempname pf
tempfile pfres
postfile `pf' b_did using `pfres', replace
set seed 2026
forvalues r = 1/500 {
    * 在地区层面抽一个伪处理身份（同一地区两期身份一致）
    bysort id: gen rnd_id = runiform() if _n == 1
    bysort id (rnd_id): replace rnd_id = rnd_id[1]
    egen prank = rank(rnd_id), unique
    gen treatedF = (prank <= 10)          // 随机 10 个伪处理地区
    quietly reg y i.treatedF##i.post, vce(cluster id)
    post `pf' (_b[1.treatedF#1.post])
    drop rnd_id prank treatedF
}
postclose `pf'
use `pfres', clear
summarize b_did, detail                  // 伪系数分布：中心应 ≈ 0
count if b_did <= -150                   // 伪系数 ≤ 真实系数（-150）的次数
di (r(N) + 1) / 501                      // 经验 p 值（单侧）
histogram b_did, normal xline(-150, lcolor(red))
* 备选：ritest（SSC）做随机化推断，支持聚类层级（选项以 help ritest 为准）
restore

* ---------- 6.2 伪时点（预期效应检验） ----------
* 用 g=3 队列的干预前两期（t=1,2），人为假设 t=2 已干预
preserve
keep if inlist(g, 0, 3) & inlist(t, 1, 2)
gen post = (t == 2)
gen treated3 = (g == 3)
reg y i.treated3##i.post, vce(cluster id)     // 预期系数 ≈ 0
restore

* ---------- 6.3 剔除部分样本 ----------
* (a) 剔除 y 上下 1% 极端值后重估 2×2
preserve
keep if inlist(t, 1, 2)
gen post = (t == 2)
gen treated2 = (g == 2)
quietly summarize y, detail
drop if y < r(p1) | y > r(p99)
reg y i.treated2##i.post, vce(cluster id)
restore
* (b) 对照只用永不受理组（排除尚未处理队列），多期 FE 估计
preserve
keep if inlist(g, 0, 2)
gen post = (t >= 2)
gen treated2 = (g == 2)
reghdfe y i.treated2#i.post, absorb(id t) vce(cluster id)
restore

* ---------- 6.4 PSM-DID ----------
preserve
keep if inlist(t, 1, 2)
gen post = (t == 2)
gen treated2 = (g == 2)
* 方案 A（官方 teffects）：横截面 ATT 演示（把两期分别视为观测）
teffects psmatch (y) (treated2 x1 x2), atet
* 方案 B（psmatch2 + DID，SSC；实务常用）：按干预前协变量匹配后做 DID
psmatch2 treated2 x1 x2, out(y) logit common
pstest x1 x2, both                        // 匹配后平衡性：标准化差异应 < 0.1
reg y i.treated2##i.post [pw = _weight], vce(cluster id)
est store m_psm
* 注：psmatch2 生成的 _weight 为匹配权重；以 help psmatch2 为准
restore

* ---------- 6.5 更换结局与聚类层级 ----------
preserve
keep if inlist(t, 1, 2)
gen post = (t == 2)
gen treated2 = (g == 2)
reg adm i.treated2##i.post, vce(cluster id)      // 结局换为住院率：预期 ≈ -0.02
est store m_adm
* 聚类层级敏感性：地区 → 更保守的层级（示例：每 3 个地区并为一组）
egen group3 = group(ceil(id/3))
reg y i.treated2##i.post, vce(cluster group3)    // 聚类数变少，标准误通常变大
restore