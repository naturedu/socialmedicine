# ① 残差诊断
m0 <- lm(y ~ time_c + level + trend_after, data = dat)
plot(resid(m0), type = "o", pch = 16, cex = 0.7,
     xlab = "月份", ylab = "残差"); abline(h = 0)
acf(resid(m0), lag.max = 12, main = "残差 ACF")

library(lmtest)
dwtest(m0)                    # Durbin-Watson（一阶）
bgtest(m0, order = 4)         # Breusch-Godfrey LM（高阶）

# ② Newey-West / HAC 标准误
library(sandwich)
summary(m0)                                                    # 普通 SE（参考）
coeftest(m0, vcov = NeweyWest(m0, lag = 1, prewhite = FALSE))  # HAC SE，lag 固定为 1
coeftest(m0, vcov = NeweyWest(m0))                             # 默认：自动带宽 + prewhite
# 注：NeweyWest 默认 prewhite = TRUE 且自动选带宽；与 Stata lag(1) 对照时
#     用 lag = 1, prewhite = FALSE（以 help(NeweyWest) 为准）

# ③ 备选：AR(1) 误差模型（nlme）
library(nlme)
g1 <- gls(y ~ time_c + level + trend_after, data = dat,
          correlation = corAR1(form = ~ time))
summary(g1)