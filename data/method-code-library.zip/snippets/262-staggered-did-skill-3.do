* 第三方csdid；先核对所装版本help csdid，g=0为从未处理
* ssc install csdid
* ssc install drdid
csdid y x_pre, ivar(id) time(year) gvar(g) method(dripw) cluster(id)
estat simple
estat event, window(-2 2)