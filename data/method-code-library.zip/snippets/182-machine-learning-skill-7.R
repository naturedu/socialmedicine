# ---- 统一建模数据框（特征 + 结局）----
feats <- c("age_s", "sex", "comorb_s", "los_s", "insurance",
           "z1", "z2", "z3", "z4", "z5", "highcost")
tr_m <- tr[, feats]; va_m <- va[, feats]; te_m <- te[, feats]

# ---- 随机森林（ranger；分类结局须为 factor）----
library(ranger)
set.seed(11)
rf <- ranger(factor(highcost) ~ ., data = tr_m,
             num.trees = 500, mtry = 3, min.node.size = 10,
             importance = "impurity", probability = TRUE)
rf                                          # OOB 预测误差
rf$variable.importance                      # 变量重要性
p_rf_va <- predict(rf, data = va_m)$predictions[, "1"]   # 验证集概率（调参用）
p_rf_te <- predict(rf, data = te_m)$predictions[, "1"]   # 测试集概率（仅评估一次）

# ---- XGBoost：xgb.cv 单组参数 + 早停 ----
library(xgboost)
library(Matrix)
mtr <- sparse.model.matrix(highcost ~ . - 1, data = tr_m)
mva <- sparse.model.matrix(highcost ~ . - 1, data = va_m)
mte <- sparse.model.matrix(highcost ~ . - 1, data = te_m)
dtrain <- xgb.DMatrix(mtr, label = tr_m$highcost)
dval   <- xgb.DMatrix(mva, label = va_m$highcost)
dtest  <- xgb.DMatrix(mte, label = te_m$highcost)

set.seed(12)
cvx <- xgb.cv(params = list(objective = "binary:logistic", eval_metric = "auc",
                            eta = 0.05, max_depth = 3,
                            subsample = 0.8, colsample_bytree = 0.8),
              data = dtrain, nrounds = 500, nfold = 5,
              early_stopping_rounds = 20, verbose = 0)
cvx$best_iteration                                   # 最佳轮数
max(cvx$evaluation_log$test_auc_mean)                # CV AUC

# ---- XGBoost：手动小网格（验证集早停选参）----
grid <- expand.grid(eta = c(0.05, 0.1), max_depth = c(2, 3, 4))
res <- lapply(seq_len(nrow(grid)), function(i) {
  p <- list(objective = "binary:logistic", eval_metric = "auc",
            eta = grid$eta[i], max_depth = grid$max_depth[i],
            subsample = 0.8, colsample_bytree = 0.8)
  xgb.train(params = p, data = dtrain, nrounds = 500,
            watchlist = list(val = dval), early_stopping_rounds = 20, verbose = 0)
})
va_auc <- sapply(res, function(m) m$best_score)       # 各组合验证集 AUC
best_i <- which.max(va_auc)
grid[best_i, ]                                        # 最优参数
best_n <- res[[best_i]]$best_iteration                # 最优轮数

# 用最优参数 + 最优轮数在「训练+验证」上重训，测试集只评估一次
full <- xgb.DMatrix(rbind(mtr, mva), label = c(tr_m$highcost, va_m$highcost))
bst <- xgb.train(params = res[[best_i]]$params, data = full, nrounds = best_n)
p_xgb_te <- predict(bst, dtest)
xgb.importance(model = bst)                           # Gain / Cover 重要性

# ---- 等价写法：caret 网格调参（二选一）----
library(caret)
set.seed(13)
cg <- expand.grid(nrounds = 300, max_depth = c(2, 3, 4), eta = c(0.05, 0.1),
                  gamma = 0, colsample_bytree = 0.8,
                  min_child_weight = 1, subsample = 0.8)
ctrl <- trainControl(method = "cv", number = 5, classProbs = TRUE,
                     summaryFunction = twoClassSummary)
fit_caret <- train(x = tr_m[, -ncol(tr_m)], y = factor(tr_m$highcost),
                   method = "xgbTree", trControl = ctrl, tuneGrid = cg,
                   metric = "ROC")
fit_caret$bestTune