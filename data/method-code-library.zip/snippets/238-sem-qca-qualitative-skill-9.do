* Stata：SSC 的 fuzzy 包做模糊集校准与操作（以 help fuzzy 为准）
ssc install fuzzy
fzcalc zy, low(60) cross(75) high(90)