# d: id=字符个人键, year=实际访谈年, y=已核对结局, x=预定协变量
stopifnot(!anyNA(d$id), !anyDuplicated(d[c("id", "year")]))
d <- d[order(d$id, d$year), ]
# 纵向条件关联；不自动等于政策因果效应
m <- fixest::feols(y ~ x | id + year, cluster = ~id, data = d)
summary(m)
# 按复杂抽样作描述应另用对应设计与权重，而非仅cluster=id。