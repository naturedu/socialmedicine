# R：delta 方法 WTP（car::deltaMethod）
library(car)
deltaMethod(coef(m1), "-b/d")               # 按实际系数名替换 b、d