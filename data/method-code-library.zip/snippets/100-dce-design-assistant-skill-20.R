# R：潜类别 logit（gmnl）
library(gmnl)
lc <- gmnl(choice ~ a + b + c + d | 0 | 0 | 0 | 1, data = md,
           model = "lc", panel = TRUE, Q = 3)
summary(lc)