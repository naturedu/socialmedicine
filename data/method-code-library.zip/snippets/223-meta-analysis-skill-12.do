* ---- 亚组（mode：1=个案管理+电话随访，0=单纯电话随访）----
* 官方：subgroup() 森林图 + 分组合并
meta forestplot, subgroup(mode) addoverall
meta esize if mode == 1, random
meta esize if mode == 0, random
* 或 SSC metan 的 by()
metan et nt ec nc, or random by(mode) label(namevar=study, yearvar=year)

* ---- Meta 回归（协变量 year：发表年份趋势）----
meta regress year                     // 官方：REML + Knapp–Hartung（以 help meta regress 为准）
metareg lnOR year, wsse(selnOR) mm    // SSC metareg；REML 用 metareg ..., wsse(selnOR) reml
* metareg 输出含 tau² 与 I²_res；语法细节以 help metareg 为准