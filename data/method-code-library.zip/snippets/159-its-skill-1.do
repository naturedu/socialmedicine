* Stata（联网安装一次）
ssc install actest, replace
ssc install itsa,   replace
ssc install estout, replace