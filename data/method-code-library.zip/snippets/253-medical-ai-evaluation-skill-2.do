* 两位评审、名义分类
kap rater1 rater2
* 该接口是两位评审的Cohen Kappa，不是Fleiss Kappa。