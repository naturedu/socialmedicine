ssc install synth
tsset id time
synth y x1 x2 y(1990(1)1999), trunit(1) trperiod(2000) fig
* 安慰剂检验：对每个对照单元重复 synth 比较效应轨迹（以 help synth 为准）