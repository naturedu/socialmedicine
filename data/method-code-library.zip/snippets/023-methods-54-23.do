* QALY：效用曲线下面积（q 为效用、t 为时点，按 id 与 t 排序）
bysort id (t): gen qaly_step = (q + q[_n-1]) / 2 * (t - t[_n-1]) if _n > 1
bysort id: egen qaly = total(qaly_step)
* DALY：YLL + YLD（yll、yld 按 GBD 公式预先计算）
gen daly = yll + yld