* ============ 4.1 手动分段回归 + Newey-West ============
newey y time_c level trend_after, lag(1) force
* 注：任务书简写 newey y time level trend, lag(1) force；此处 time 为干预时点
*     中心化的 time_c；force 允许未 tsset 的数据仍按时间序列估计（已 tsset 可省略）
estimates store its_manual

* 组合效应（HAC 标准误下的线性组合检验）
lincom time_c + trend_after              // 干预后总斜率（β1+β3）
lincom level + 23*trend_after            // 期末（第 48 月）总效应（β2+23·β3）

* ============ 4.2 itsa 命令（SSC，Ariel Linden）============
* ssc install itsa, replace
itsa y, single treatperiod(25) posttrend
* 注：任务书示例写法 itsa y, single treat(25) 中的选项名，实际对应
*     treatperiod(25)，以 help itsa 为准；itsa 默认 OLS + Newey-West 标准误。
* 带滞后因变量的动态版本：itsa y, single treatperiod(25) lag(1) posttrend
* 出图：itsa y, single treatperiod(25) posttrend figure