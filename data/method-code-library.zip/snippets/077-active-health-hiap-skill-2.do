* Stata：PAF 与可避免负担的情景计算
local p  0.35            // 基线暴露率
local RR 1.45            // 暴露-反应 RR（示例，来自 Meta 分析）
local paf = (`p'*(`RR'-1))/(`p'*(`RR'-1)+1)
di "PAF = " %5.3f `paf'
local B 12000            // 基线年死亡数（示例）
di "基线归因死亡 = " %9.0f (`B'*`paf')
* 干预使暴露率降至 0.25
local p2 0.25
local paf2 = (`p2'*(`RR'-1))/(`p2'*(`RR'-1)+1)
di "干预后可避免死亡 = " %9.0f (`B'*(`paf'-`paf2'))

* 公平性：集中指数（协方差法）
egen r = rank(y)         // y 为健康结局，按经济状况排序后的秩
sum y
gen lhs = 2*y*r/r(mean)
quietly reg lhs r
di "CI = " %5.3f _b[r]