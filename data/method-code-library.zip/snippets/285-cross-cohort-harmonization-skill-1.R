# 标准化层示意；不改变原始ID，不公开对应表。
stopifnot(all(c("study","id","visit_date") %in% names(d)))
d$key <- paste(d$study, d$id, sep=":")
stopifnot(!anyDuplicated(d[c("key","visit_date")]))
# study内真实设计单元与权重需单独核对，key不是PSU。