# ---- 6.1 安慰剂时点：假设干预发生在第 13 个月 ----
dat$time_c13 <- dat$time - 13
dat$level13  <- as.numeric(dat$time >= 13)
dat$trend13  <- dat$time_c13 * dat$level13
m_placebo <- lm(y ~ time_c13 + level13 + trend13, data = dat)
coeftest(m_placebo, vcov = NeweyWest(m_placebo, lag = 1, prewhite = FALSE))
# 期望：level13、trend13 接近 0 且不显著

# ---- 6.2 季节性：加入月度虚拟变量 ----
dat$month <- factor(((dat$time - 1) %% 12) + 1)
m_season <- lm(y ~ time_c + level + trend_after + month, data = dat)
coeftest(m_season, vcov = NeweyWest(m_season, lag = 1, prewhite = FALSE))
# 更平滑的季节建模可用正弦/余弦对（Fourier terms），以数据周期为准

# ---- 6.3 控制组 ITS（CITS）：面板数据交互项 ----
# 面板长表 panel：id、time、y、treat（1 = 干预地区）
panel$t_c  <- panel$time - 25
panel$lev  <- as.numeric(panel$time >= 25)
panel$tr_a <- panel$t_c * panel$lev
m_cits <- lm(y ~ t_c + treat + lev + tr_a + treat:lev + treat:tr_a, data = panel)
coeftest(m_cits, vcov = NeweyWest(m_cits, lag = 1, prewhite = FALSE))
# 政策效应 = treat:lev（即时）与 treat:tr_a（斜率）的系数

# ---- 6.4 异常值敏感性：1%/99% 缩尾 ----
q <- quantile(dat$y, c(0.01, 0.99))
dat$y_w <- pmin(pmax(dat$y, q[1]), q[2])
m_w <- lm(y_w ~ time_c + level + trend_after, data = dat)
coeftest(m_w, vcov = NeweyWest(m_w, lag = 1, prewhite = FALSE))