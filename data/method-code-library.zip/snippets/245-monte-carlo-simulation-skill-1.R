set.seed(20261023)
B <- 2000; n <- 100; truth <- 0.3
one <- function(){
  y0 <- rnorm(n,0,1); y1 <- rnorm(n,truth,1.5)
  z <- t.test(y1,y0) # Welch；估计方向为y1-y0
  c(est=mean(y1)-mean(y0),lo=z$conf.int[1],hi=z$conf.int[2],p=z$p.value)
}
ans <- t(replicate(B,one()))
err <- ans[,"est"]-truth
covered <- ans[,"lo"]<=truth & ans[,"hi"]>=truth
coverage <- mean(covered)
c(bias=mean(err),MCSE_bias=sd(ans[,"est"])/sqrt(B),
  RMSE=sqrt(mean(err^2)),coverage=coverage,
  MCSE_coverage=sqrt(coverage*(1-coverage)/B),
  power=mean(ans[,"p"]<.05))
# 将truth设为0并重新生成数据，才能估计该场景的I类错误率。