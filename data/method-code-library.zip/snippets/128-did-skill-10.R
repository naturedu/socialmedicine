# 事件研究（fixest 的 i() 交互；基准 rel = -1）
library(fixest)
es <- subset(dat, g %in% c(0, 3))
es$treated3 <- as.integer(es$g == 3)
es$rel <- es$t - 3
m_es <- feols(y ~ i(rel, treated3, ref = -1) | id + t, data = es, cluster = ~id)
summary(m_es)
iplot(m_es)                             # 事件研究图：干预前系数应 ≈ 0
# 正式检验：干预前系数（本例为 rel = -2）
coef(m_es)                              # 系数名形如 rel::-2:treated3（以实际输出为准）
wald(m_es, "rel::-2:treated3")          # 名称以 coef(m_es) 输出为准
# 亦可用 coefplot(m_es)（fixest 自带）；选项以 help(coefplot.fixest) 为准
# 交错处理时可用 did::pre.test()（对 CS 估计做干预前联合检验，以 help(pre.test) 为准）