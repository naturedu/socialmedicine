# R：属性水平表与全因子规模
levels <- list(费用 = c(10, 30, 50),   # 元/次
               候诊 = c(1, 3, 7),      # 天
               连续性 = c(0, 1),       # 0=不同医生 1=同一医生
               目录 = c(0, 1))         # 0=基础目录 1=扩展目录
sapply(levels, length)                 # 各属性水平数
full <- expand.grid(levels)            # 全因子组合
nrow(full)                             # 3*3*2*2 = 36