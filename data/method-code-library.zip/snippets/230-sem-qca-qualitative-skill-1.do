* Stata（联网安装一次）
ssc install fuzzy, replace