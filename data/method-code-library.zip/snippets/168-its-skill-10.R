# ============ R：lm + NeweyWest，与 Stata 对照 ============
m <- lm(y ~ time_c + level + trend_after, data = dat)

summary(m)                                                    # 普通 SE（参考）
tab_hac <- coeftest(m, vcov = NeweyWest(m, lag = 1, prewhite = FALSE))
print(tab_hac)                                                # HAC SE
coefci(tab_hac)                                               # 基于 HAC 的 95% CI

# 组合效应（HAC 协方差下的线性组合与 delta 方法）
linearHypothesis(m, "time_c + trend_after = 0",
                 vcov. = NeweyWest(m, lag = 1, prewhite = FALSE))   # 干预后总斜率
deltaMethod(m, "level + 23*trend_after",
            vcov. = NeweyWest(m, lag = 1, prewhite = FALSE))         # 期末总效应