* ---- 各模型预测概率（基线 / LASSO 用各自 predict 产出）----
logit highcost age_s sex comorb_s los_s i.insurance z1-z5 if svar == 1
predict p_base, pr
lasso logit highcost age_s sex comorb_s los_s i.insurance z1-z5 if svar == 1, selection(cv) rseed(7)
predict p_lasso, pr
* （rforest / boosting 的预测变量按各自 postestimation 命令生成）

* ---- 单模型 ROC 与 AUC ----
roctab highcost p_base if svar == 3, graph
* logit 拟合后可用 lroc（含 AUC 与 ROC 图）

* ---- 多模型比较（DeLong 法与 Hanley–McNeil 法，只评估测试集）----
roccomp highcost p_base p_lasso p_rf p_xgb if svar == 3, graph

* ---- 校准：重拟合检验截距/斜率（应接近 0/1）+ Hosmer–Lemeshow + Brier ----
logit highcost p_xgb if svar == 3
estat gof, group(10)
gen b2 = (highcost - p_xgb)^2 if svar == 3
summarize b2                                // r(mean) 即 Brier 分数

* ---- 回归指标：RMSE / MAE（对数费用）----
gen e2 = (lncost - p_lreg)^2 if svar == 3
summarize e2
display "RMSE = " sqrt(r(mean))
gen ae = abs(lncost - p_lreg) if svar == 3
summarize ae
display "MAE = " r(mean)