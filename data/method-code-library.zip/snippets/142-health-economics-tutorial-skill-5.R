# R：评价类型选择决策函数
pick_type <- function(outcome = c("equivalent", "natural", "qaly", "monetary")) {
  outcome <- match.arg(outcome)
  switch(outcome,
    equivalent = "CMA：最小成本分析（结局等效时只比较成本）",
    natural    = "CEA：成本-效果分析（自然单位结局）",
    qaly       = "CUA：成本-效用分析（QALY/DALY 等偏好加权结局）",
    monetary   = "CBA：成本-效益分析（成本与效果均货币化）")
}
pick_type("qaly")     # 本算例用 QALY → CUA