# R：水平平衡、相关矩阵与设计效率
apply(des24, 2, table)                       # 水平平衡
round(cor(as.data.frame(des24)), 3)          # 正交性：非对角应 ≈ 0
eval.design(~ ., dopt$design)                # AlgDesign：方差膨胀、D/G 效率