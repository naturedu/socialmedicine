# R：转移矩阵（策略 A 与 B）
PA <- matrix(c(0.9701987, 0.0198013, 0.0100000,
               0.0000000, 0.9048374, 0.0951626,
               0.0000000, 0.0000000, 1.0000000),
             nrow = 3, byrow = TRUE)
PB <- matrix(c(0.9760975, 0.0139025, 0.0100000,
               0.0000000, 0.9048374, 0.0951626,
               0.0000000, 0.0000000, 1.0000000),
             nrow = 3, byrow = TRUE)
rownames(PA) <- colnames(PA) <- c("无并发症", "卒中后", "死亡")
rownames(PB) <- colnames(PB) <- c("无并发症", "卒中后", "死亡")
rowSums(PA)                     # 1 1 1
rowSums(PB)                     # 1 1 1
# 20 年后分布（循环连乘；也可用 expm::`%^%`）
trace <- c(1, 0, 0)
for (i in 1:20) trace <- trace %*% PA
trace