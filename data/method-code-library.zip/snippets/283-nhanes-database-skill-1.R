library(haven)
library(survey)
dem <- read_xpt("DEMO_I.XPT")
bmx <- read_xpt("BMX_I.XPT")
stopifnot(!anyDuplicated(dem$SEQN), !anyDuplicated(bmx$SEQN))
d <- merge(dem, bmx, by="SEQN", all.x=TRUE, sort=FALSE)
stopifnot(nrow(d)==nrow(dem))
# BMI为MEC测量；此例不含实验室子样本或多周期。
z <- subset(d, !is.na(WTMEC2YR) & WTMEC2YR>0 &
               !is.na(SDMVPSU) & !is.na(SDMVSTRA))
des <- svydesign(ids=~SDMVPSU, strata=~SDMVSTRA,
                 weights=~WTMEC2YR, nest=TRUE, data=z)
adult <- subset(des, RIDAGEYR>=20)
svymean(~BMXBMI, adult, na.rm=TRUE)
confint(svymean(~BMXBMI, adult, na.rm=TRUE))
# 补报未加权人数、BMI缺失率与估计可靠性；不将缺失直接当健康。