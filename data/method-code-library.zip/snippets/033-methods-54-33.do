ssc install conindex, replace
conindex y, rankvar(r)      // r：按经济状况排序的分数秩；选项以 help conindex 为准