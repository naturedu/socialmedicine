isid id wave
xtset id wave
mixed cognition c.time##i.baseline_exposure age0 i.sex || id: time, covariance(unstructured)
* 若目标是复杂抽样总体估计，需另核对设计权重和模型的兼容性。