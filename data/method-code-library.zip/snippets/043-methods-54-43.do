ssc install reghdfe
ssc install coefplot
reghdfe y ib(-1).time#i.treat, absorb(id time) vce(cluster id)
coefplot, keep(*.time#1.treat)          // 事件研究图