# =====================================================================
# 模拟数据（与 Stata 版同参数；随机数实现不同，不影响示例）
# =====================================================================
set.seed(2026)
n           <- 48
time        <- 1:n
time_c      <- time - 25                 # 中心化：干预时点 = 0
level       <- as.numeric(time >= 25)    # 干预指示：第 25 个月起 = 1
trend_after <- time_c * level            # 干预后斜率增量

# AR(1) 误差：rho = 0.3，扰动 sd = 200
e <- as.numeric(arima.sim(model = list(ar = 0.3), n = n, sd = 200))

# 结局：次均住院费用（元），内置真实效应
y <- 12000 - 50*time_c - 600*level - 30*trend_after + e

dat <- data.frame(time, time_c, level, trend_after, y)
plot(y ~ time, data = dat, type = "o", pch = 16, cex = 0.7,
     main = "模拟月度序列：次均住院费用", xlab = "月份", ylab = "元")
abline(v = 24.5, lty = 2, col = "gray50")