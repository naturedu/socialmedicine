* Stata：单因素敏感性分析（基线 ICER ≈ 50003 元/QALY）
scalar dC = 30886.9
scalar dE = 0.6177
display "基线 ICER            = " %9.1f dC / dE
display "ΔE +20% 的 ICER      = " %9.1f dC / (dE * 1.2)
display "ΔE −20% 的 ICER      = " %9.1f dC / (dE * 0.8)
display "ΔC +20% 的 ICER      = " %9.1f (dC * 1.2) / dE
display "ΔC −20% 的 ICER      = " %9.1f (dC * 0.8) / dE

* 干预组年效用取 0.73 / 0.83（其余不变；贴现后 ΔE = Δu × 7.7217）
display "干预效用 0.73 → ICER = " %9.1f dC / (0.03 * 7.7217)
display "干预效用 0.83 → ICER = " %9.1f dC / (0.13 * 7.7217)
* 解读：ICER 范围约 30769–133333 元/QALY，跨过 λ = 100000 →
* 结论对效用参数敏感，报告中须突出说明