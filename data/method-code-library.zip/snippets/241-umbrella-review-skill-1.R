M <- matrix(c(1,1,0, 1,0,1, 0,1,1, 1,1,1), nrow=4, byrow=TRUE)
rownames(M) <- paste0("study",1:4)
colnames(M) <- paste0("review",1:3)
M <- M[rowSums(M)>0,,drop=FALSE]
N <- sum(M); r <- nrow(M); c <- ncol(M)
cca <- if(c>1) (N-r)/(r*c-r) else NA_real_
cca
pair_overlap <- crossprod(M)
pair_overlap