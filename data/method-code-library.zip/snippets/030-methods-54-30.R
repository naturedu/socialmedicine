library(Benchmarking)
r_dea <- dea(X = cbind(x1, x2), Y = y, RTS = "vrs")    # 投入导向 BCC
eff_dea <- r_dea$eff                                    # Farrell 效率 E ∈ (0,1]
library(frontier)
eff_sfa <- efficiencies(sfa(log(y) ~ log(x1) + log(x2), data = dat))