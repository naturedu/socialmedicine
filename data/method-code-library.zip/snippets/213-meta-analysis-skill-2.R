# R
install.packages(c("meta", "metafor"))