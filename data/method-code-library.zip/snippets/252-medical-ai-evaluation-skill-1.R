library(irr)
ratings <- data.frame(r1=c(1,1,0,0,1,0),
                      r2=c(1,0,0,0,1,1),r3=c(1,1,0,1,1,0))
kappam.fleiss(ratings)
# 两分类器在相同病例上正确/错误的配对表
mcnemar.test(matrix(c(30,4,9,13),nrow=2))
# 连续评分ICC需明确模型、绝对一致/一致性、单个/平均评分
# irr::icc(score_matrix, model="twoway",type="agreement",unit="single")