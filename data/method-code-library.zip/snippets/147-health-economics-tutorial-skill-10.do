* Stata：QALY 与增量 QALY（效用 × 生存年数，未贴现）
scalar u0 = 0.70       // 对照年效用
scalar u1 = 0.78       // 干预年效用
scalar years = 10
display "对照 QALY = " u0 * years          // 7.0
display "干预 QALY = " u1 * years          // 7.8
display "ΔQALY     = " (u1 - u0) * years   // 0.8