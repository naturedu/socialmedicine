# R
install.packages(c("glmnet", "ranger", "xgboost", "pROC", "shapviz",
                   "caret", "rms", "mice", "Matrix", "DALEX"))