* 主表：HAC 标准误（esttab，SSC estout）
newey y time_c level trend_after, lag(1)
estimates store its_main
esttab its_main, b(%9.2f) se(%9.2f) p(%9.3f) stats(N r2, fmt(%9.0f %9.3f)) ///
    title("表 1：ITS 分段回归（Newey-West 标准误，lag(1)）") ///
    addnotes("干预时点：第 25 个月；time_c 为干预时点中心化的月份。")