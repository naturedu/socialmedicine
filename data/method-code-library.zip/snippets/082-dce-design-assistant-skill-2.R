# R
install.packages(c("DoE.base", "AlgDesign", "support.CEs", "mlogit", "gmnl"))