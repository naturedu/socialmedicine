# R：结构参数集中定义，供后续各步复用
states       <- c("无并发症", "卒中后", "死亡")
cycle_length <- 1        # 年
T            <- 30       # 时间范围（年）；敏感性情景取 40
init         <- c(1, 0, 0)   # 起始：100% 无并发症
names(init)  <- states