ivregress 2sls y x (a=z), vce(robust)
estat firststage