* d 已在周期内按 SEQN 合并，字段经Doc File核对。
isid SEQN
svyset SDMVPSU [pweight=WTMEC2YR], strata(SDMVSTRA)
gen byte adult = RIDAGEYR>=20 if !missing(RIDAGEYR)
svy, subpop(adult): mean BMXBMI
* 保留完整设计再subpop，不先只保留成人破坏设计方差。