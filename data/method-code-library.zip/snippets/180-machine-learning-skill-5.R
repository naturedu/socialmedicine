# ---- 模型矩阵（glmnet 不接受因子，需 model.matrix；含噪声变量观察收缩效果）----
library(glmnet)
xvars <- c("age_s", "sex", "comorb_s", "los_s", "z1", "z2", "z3", "z4", "z5", "insurance")
f <- as.formula(paste("~", paste(xvars, collapse = " + ")))
x_tr <- model.matrix(f, data = tr)[, -1]
x_va <- model.matrix(f, data = va)[, -1]
x_te <- model.matrix(f, data = te)[, -1]
y_tr <- tr$highcost; y_te <- te$highcost

# ---- 基线 logistic（不收缩，作为及格线）----
base <- glm(highcost ~ age_s + sex + comorb_s + los_s + insurance + z1 + z2 + z3 + z4 + z5,
            data = tr, family = binomial)
summary(base)

# 备选：逐步回归（仅作敏感性分析）
# library(MASS)
# stepAIC(base, direction = "both", trace = FALSE)

# ---- 基线线性回归（连续费用，取对数）----
lm_base <- lm(log(cost) ~ age_s + sex + comorb_s + los_s + insurance, data = tr)
summary(lm_base)

# ---- LASSO（alpha = 1），10 折 CV 选 λ ----
set.seed(7)
cv_lasso <- cv.glmnet(x_tr, y_tr, family = "binomial", alpha = 1, nfolds = 10)
plot(cv_lasso)                                # CV 误差曲线（两条虚线 = lambda.min / 1se）
coef(cv_lasso, s = "lambda.min")              # 噪声变量 z1–z5 应为 0
coef(cv_lasso, s = "lambda.1se")              # 更保守（1-SE 法则，模型更小）

# ---- 弹性网（alpha = 0.5）----
set.seed(8)
cv_en <- cv.glmnet(x_tr, y_tr, family = "binomial", alpha = 0.5, nfolds = 10)
coef(cv_en, s = "lambda.1se")

# ---- λ 路径图（系数随 log(λ) 增大被收缩至 0 的轨迹）----
plot(cv_lasso$glmnet.fit, xvar = "lambda", label = TRUE)
abline(v = log(cv_lasso$lambda.1se), lty = 2)

# ---- 连续结局版：LASSO 回归（对数费用）----
set.seed(9)
cv_lasso_reg <- cv.glmnet(x_tr, log(tr$cost), alpha = 1, nfolds = 10)
coef(cv_lasso_reg, s = "lambda.1se")