* Stata（联网安装一次）
ssc install reghdfe, replace
* 若 ftools 未被自动装上：ssc install ftools, replace