* Stata：ICER、净收益与四象限判断
scalar dC = 30886.9
scalar dE = 0.6177
scalar lambda = 100000
display "ICER = " %9.1f dC / dE                    // ≈ 50003 元/QALY
display "NB(λ=100000) = " %9.1f lambda * dE - dC   // ≈ 30887 元

if dC > 0 & dE > 0 {
    display "东北象限：更贵更有效 → 比较 ICER 与 λ"
    display cond(dC/dE < lambda, "ICER < λ → 具有成本-效果", "ICER ≥ λ → 不具有成本-效果")
}
else if dC < 0 & dE > 0 {
    display "东南象限：更便宜更有效 → 优势策略，直接推荐"
}
else if dC > 0 & dE < 0 {
    display "西北象限：更贵更差 → 劣势策略，拒绝"
}
else {
    display "西南象限：更便宜更差 → 权衡节省与效果损失"
}