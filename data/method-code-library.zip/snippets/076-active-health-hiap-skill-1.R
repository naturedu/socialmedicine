library(quanteda)
docs <- readtext::readtext("policy_texts/*.txt")          # 政策文件目录
corp <- corpus(docs)
toks <- tokens(corp, remove_punct = TRUE)
dfmat <- dfm(toks)
kw <- c("健康", "预防", "公平", "环境", "医疗", "保障")
dfm_select(dfmat, pattern = kw) |> textstat_frequency()    # 政策文本中的健康话语频次