# R：meta 包
library(meta)
m.or <- metagen(TE = lnOR, seTE = selnOR, studlab = study, data = dat,
                sm = "OR", fixed = TRUE, random = TRUE,
                method.tau = "REML", prediction = TRUE)
m.md <- metacont(n.e = nt, mean.e = m_t, sd.e = sd_t,
                 n.c = nc, mean.c = m_c, sd.c = sd_c,
                 studlab = study, data = dat, sm = "MD",
                 fixed = TRUE, random = TRUE, method.tau = "REML")
m.smd <- update(m.md, sm = "SMD")            // 默认 Hedges' g
summary(m.or)

# 也可直接由四格表计数（metabin，参数名注意 event.e/n.e/event.c/n.c）
m.or2 <- metabin(event.e = et, n.e = nt, event.c = ec, n.c = nc,
                 studlab = study, data = dat, sm = "OR", method = "MH",
                 fixed = TRUE, random = TRUE, method.tau = "REML")