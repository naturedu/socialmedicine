* Stata（联网安装一次）
ssc install csdid,    replace    // 交错处理 DID（Callaway-Sant'Anna）
ssc install drdid,    replace    // 双重稳健 DID（csdid 的依赖）
ssc install reghdfe,  replace    // 高维固定效应（事件研究回归用）
ssc install ftools,   replace    // reghdfe 的依赖
ssc install coefplot, replace    // 系数图
ssc install estout,   replace    // 结果表
ssc install ritest,   replace    // 随机化推断（安慰剂检验备选）
ssc install psmatch2, replace    // 倾向得分匹配