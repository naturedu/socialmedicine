# 教学数据：0/1结局且均值>0；fractional rank按收入从低到高
d <- data.frame(income=c(1,2,3,4,5),use=c(0,0,1,0,1))
n <- nrow(d)
d$r <- (rank(d$income,ties.method="average")-.5)/n
mu <- mean(d$use)
cov_pop <- mean((d$use-mu)*(d$r-mean(d$r)))
CI <- 2*cov_pop/mu
Erreygers <- 4*mu*CI # 仅适用于0/1界限；未加权教学表达
c(CI=CI,Erreygers=Erreygers)