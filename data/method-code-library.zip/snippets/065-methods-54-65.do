* 供方诱导需求简化估计式：y = β0 + β1·beds + β2·need + β3·price + ε
* β1 > 0 且在控制需要与价格后仍显著 → 诱导需求的证据
reg visits beds_per1000 chronic lnprice insurance age
* 稳健性：换供给指标（医生密度）重复
reg visits doctors_per1000 chronic lnprice insurance age