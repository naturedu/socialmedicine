* Stata sem：观测题项均值入模（单指标路径模型）
sem (intention <- att sn pbc) (behavior <- intention pbc), standardized
estat gof, stats(all)