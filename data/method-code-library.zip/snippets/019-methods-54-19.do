* 成本均数与 bootstrap 95% CI（成本右偏时优于正态 CI）
bootstrap r(mean), reps(1000) seed(2026): summarize cost
ci means cost