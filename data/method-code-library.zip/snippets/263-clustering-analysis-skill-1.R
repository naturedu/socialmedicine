set.seed(20261023)
X <- scale(iris[,1:4])
km <- kmeans(X,centers=3,nstart=50)
table(km$cluster)
aggregate(iris[,1:4],list(cluster=km$cluster),mean)
library(cluster)
sil <- silhouette(km$cluster,dist(X))
mean(sil[,"sil_width"])
# iris物种标签未参与建模；本例仅示范接口，不作为患者分型依据。