library(quanteda)
# 示例访谈（虚构片段，演示用）
interviews <- data.frame(
  id = 1:6,
  text = c(
    "医保报销比例提高以后，我们村慢病患者愿意按时复诊了，负担轻了很多。",
    "村卫生室药品不全，想开的药经常没有，只能去镇上，路远还要排队。",
    "签约的家庭医生上门测血压，老人觉得被重视，依从性好多了。",
    "镇卫生院设备老化，有些检查做不了，来回县里要一整天。",
    "报销手续以前要跑好几趟，现在村卫生室直接结算，方便多了。",
    "宣传不够，很多老人根本不知道慢病门诊能报销多少。")
)
corp <- corpus(interviews, text_field = "text", docid_field = "id")
toks <- tokens(corp, remove_punct = TRUE)
dfmat <- dfm(toks)
textstat_frequency(dfmat, n = 20)               # 高频词 → 开放编码线索
fcm(toks, context = "window", window = 5) |>    # 词共现 → 主轴编码线索
  textplot_network(min_freq = 2)