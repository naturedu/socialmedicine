library(pROC)

# ---- 各模型在测试集的预测概率（基线 / LASSO 出自 glm 与 glmnet）----
p_base_te  <- predict(base, newdata = te, type = "response")
p_lasso_te <- drop(predict(cv_lasso, newx = x_te, s = "lambda.1se", type = "response"))
# p_rf_te、p_xgb_te 来自第 3 步

roc_base  <- roc(y_te, p_base_te)
roc_lasso <- roc(y_te, p_lasso_te)
roc_rf    <- roc(y_te, p_rf_te)
roc_xgb   <- roc(y_te, p_xgb_te)

auc(roc_base); auc(roc_lasso); auc(roc_rf); auc(roc_xgb)
ci.auc(roc_rf)                                   # bootstrap 95% CI（默认 2000 次）

# ---- 模型比较：DeLong 检验（相关样本）----
roc.test(roc_rf, roc_base, method = "delong")    # RF vs 基线 logistic
roc.test(roc_xgb, roc_rf, method = "delong")     # XGB vs RF

# ---- ROC 曲线叠加 ----
plot(roc_base, col = "grey50", lwd = 2)
plot(roc_lasso, add = TRUE, col = "steelblue", lwd = 2)
plot(roc_rf, add = TRUE, col = "firebrick", lwd = 2)
plot(roc_xgb, add = TRUE, col = "darkgreen", lwd = 2)
legend("bottomright", legend = c("logistic", "LASSO", "RF", "XGBoost"),
       col = c("grey50", "steelblue", "firebrick", "darkgreen"), lwd = 2)

# ---- 阈值（Youden）与敏感性 / 特异性 ----
coords(roc_xgb, "best", ret = c("threshold", "sensitivity", "specificity"))

# ---- 校准：Brier 分数 + 校准曲线（截距≈0、斜率≈1 为校准良好）----
brier <- function(p, y) mean((p - y)^2)
brier(p_base_te, y_te); brier(p_rf_te, y_te); brier(p_xgb_te, y_te)

library(rms)
val.prob(p_xgb_te, y_te, statloc = FALSE)        # 校准图 + Brier + 校准截距/斜率
# 校准差 → Platt scaling / isotonic regression 等再校准，或回退简单模型

# ---- 回归（对数费用）：RMSE / MAE / R² ----
p_lm_te   <- predict(lm_base, newdata = te)
p_lreg_te <- drop(predict(cv_lasso_reg, newx = x_te, s = "lambda.1se"))
y_cont <- log(te$cost)
rmse <- function(p, y) sqrt(mean((p - y)^2))
mae  <- function(p, y) mean(abs(p - y))
rmse(p_lm_te, y_cont);   mae(p_lm_te, y_cont)
rmse(p_lreg_te, y_cont); mae(p_lreg_te, y_cont)
1 - sum((p_lreg_te - y_cont)^2) / sum((y_cont - mean(y_cont))^2)   # R²