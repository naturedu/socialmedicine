# 主回归表：逐步（fixest 的 etable；模型 SE 已在估计时按 id 聚类）
m1 <- feols(y ~ treated + post + group, cluster = ~id, data = dat)
m2 <- feols(y ~ treated*post + treated*group + post*group, cluster = ~id, data = dat)
m3 <- feols(y ~ treated*post*group, cluster = ~id, data = dat)
etable(m1, m2, m3)          # 选项以 ?etable 为准