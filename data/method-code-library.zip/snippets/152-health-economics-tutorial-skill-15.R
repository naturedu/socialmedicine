# R：ICER、净收益与四象限判断
dC <- 30886.9; dE <- 0.6177
lambda <- 100000
ICER <- dC / dE                                    # ≈ 50003 元/QALY
NB   <- lambda * dE - dC                            # ≈ 30887 元（净货币收益）
quadrant <- if (dC > 0 && dE > 0) "NE：更贵更有效（与 λ 比较）" else
            if (dC < 0 && dE > 0) "SE：更便宜更有效（优势）" else
            if (dC > 0 && dE < 0) "NW：更贵更差（劣势）" else
            "SW：更便宜更差（权衡）"
verdict <- ifelse(ICER < lambda, "ICER < λ，具有成本-效果", "ICER ≥ λ，不具有成本-效果")
list(ICER = ICER, NB = NB, quadrant = quadrant, verdict = verdict)