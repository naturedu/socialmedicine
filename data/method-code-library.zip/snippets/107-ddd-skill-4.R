# ============ 第 0 步：模拟面板数据（贯穿全流程） ============
set.seed(2026)
N <- 60                                     # 60 家医院
dat <- expand.grid(id = 1:N, group = c(0, 1), post = c(0, 1))
dat$treated <- as.integer(dat$id <= 30)     # 处理维度：1 = 公立医院
dat$u_i     <- rnorm(N, 0, 4)[dat$id]       # 医院层面随机效应（聚类依据）
dat$time    <- dat$post                     # 供 fixest 吸收固定效应

# 真实参数（内置真实 DDD 效应 delta = -8）
g0 <- 100; g1 <- 10; g2 <- -5; g3 <- 20
g12 <- -6; g13 <- 5; g23 <- -4; delta <- -8

dat$y <- with(dat, g0 + g1*treated + g2*post + g3*group +
                   g12*treated*post + g13*treated*group + g23*post*group +
                   delta*treated*post*group + u_i + rnorm(nrow(dat), 0, 2))

# 稳健性结局：y_qty（相关结局，真实 δ = -3）；y_dev（安慰剂结局，真实 δ = 0）
dat$y_qty <- with(dat, 60 + 8*treated - 4*post + 18*group - 3*treated*post +
                      4*treated*group - 2*post*group - 3*treated*post*group +
                      u_i + rnorm(nrow(dat), 0, 3))
dat$y_dev <- with(dat, 40 + 5*treated - 2*post + 2*group + 1*treated*post -
                      1*treated*group + 0.5*post*group + 0*treated*post*group +
                      0.5*u_i + rnorm(nrow(dat), 0, 5))

# 8 组均值表（应与下方期望值接近）
aggregate(y ~ treated + post + group, data = dat, FUN = mean)