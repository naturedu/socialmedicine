* 虚构参数；此模板尚未在Stata执行，使用前核对版本和路径。
do "scripts/microsimulation_demo.do" "microsimulation-demo-stata"