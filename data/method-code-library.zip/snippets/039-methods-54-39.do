ssc install rdrobust
ssc install rddensity
rdrobust y x, c(0)          // x 为中心化运行变量
rdplot y x, c(0)            // RD 图
rddensity x, c(0)           // 密度操纵检验