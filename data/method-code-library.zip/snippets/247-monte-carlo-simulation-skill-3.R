set.seed(20261023)
B <- 10000
delta_cost <- rnorm(B,1200,300)
delta_qaly <- rnorm(B,.08,.025)
lambda <- seq(0,100000,by=5000) # 教学阈值范围，不是政策推荐
ceac <- sapply(lambda,function(k) mean(k*delta_qaly-delta_cost>0))
data.frame(lambda,Pr_cost_effective=ceac)