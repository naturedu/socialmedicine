# d为已由代码本核实的长表；此处不假定任何数据库原始变量名
stopifnot(!anyDuplicated(d[c("id","wave")]))
with(d,table(wave,is.na(cognition)))
library(lme4)
fit <- lmer(cognition ~ time*baseline_exposure+age0+sex+(1+time|id),data=d)
summary(fit)
# 这是条件均值关联模型；baseline_exposure需先定义，不能直接称因果效应。