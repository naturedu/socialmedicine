# d: cost>=0，a为处理/分组，x为治疗前协变量
d$anycost <- as.integer(d$cost>0)
pmod <- glm(anycost~a+x,family=binomial(),data=d)
cmod <- glm(cost~a+x,family=Gamma(link="log"),data=subset(d,cost>0))
d1 <- d0 <- d; d1$a <- 1; d0$a <- 0
pred_mean <- function(nd) predict(pmod,nd,type="response") *
  predict(cmod,nd,type="response")
mean(pred_mean(d1)-pred_mean(d0))
# 这只是标准化模型差异；因果解释另需识别假设。
# 区间可对整个两部拟合与标准化过程适当重抽样；聚类数据按簇抽样。