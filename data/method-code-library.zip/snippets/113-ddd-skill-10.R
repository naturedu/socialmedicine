# 3.1 两个 2×2 DID（品种类型 DID 在公立/民营切片上）
did1 <- coef(feols(y ~ post*group | id, cluster = ~id, data = dat[dat$treated == 1, ]))["post:group"]
did2 <- coef(feols(y ~ post*group | id, cluster = ~id, data = dat[dat$treated == 0, ]))["post:group"]
c(DID1 = unname(did1), DID2 = unname(did2), DDD = unname(did1 - did2))
# 期望：DID1 ≈ -12，DID2 ≈ -4，DDD ≈ -8 = δ

# 3.2 镜像分解（医院类型 DID 在集采/非集采切片上），期望 ≈ -8
d1 <- coef(feols(y ~ treated*post | id, cluster = ~id, data = dat[dat$group == 1, ]))["treated:post"]
d2 <- coef(feols(y ~ treated*post | id, cluster = ~id, data = dat[dat$group == 0, ]))["treated:post"]
unname(d1 - d2)

# 3.3 与主回归三重交互系数对照（期望 ≈ -8）
coef(m_fe)["treated:post:group"]