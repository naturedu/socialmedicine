# 图形直觉：四组均值线（两条 DID 线的斜率差之差 = DDD）
cell <- aggregate(y ~ treated + post + group, data = dat, FUN = mean)
plot(NA, xlim = c(0, 1), ylim = range(cell$y),
     xlab = "post（0 政策前 / 1 政策后）", ylab = "月均药品费用 y（万元）",
     main = "四组均值线：DDD = 实线斜率差 - 虚线斜率差")
lines(y ~ post, data = cell, subset = treated == 1 & group == 1, type = "b", col = "red",  lty = 1)
lines(y ~ post, data = cell, subset = treated == 1 & group == 0, type = "b", col = "blue", lty = 1)
lines(y ~ post, data = cell, subset = treated == 0 & group == 1, type = "b", col = "red",  lty = 2)
lines(y ~ post, data = cell, subset = treated == 0 & group == 0, type = "b", col = "blue", lty = 2)
legend("topright", c("公立·集采", "公立·非集采", "民营·集采", "民营·非集采"),
       col = c("red", "blue", "red", "blue"), lty = c(1, 1, 2, 2), bty = "n")