# 中心化版本（推荐）
m0 <- lm(y ~ time_c + level + trend_after, data = dat)
summary(m0)
# 预计：level ≈ -600、trend_after ≈ -30（样本有噪声）

# 组合效应（第 3 步换 HAC 协方差后正式报告）
library(car)
linearHypothesis(m0, "time_c + trend_after = 0")   # 干预后总斜率（β1+β3）
deltaMethod(m0, "level + 23*trend_after")          # 期末（time_c=23）总效应