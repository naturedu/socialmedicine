xtset id year
xtreg y x i.year, fe vce(cluster id)
xtreg y x i.year, re vce(cluster id)
bysort id: egen xbar = mean(x)
xtreg y x xbar i.year, re vce(cluster id)