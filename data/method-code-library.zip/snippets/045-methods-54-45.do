* Stata：2×2 DID（交互项系数即效应）
reg y i.treat##i.post, vce(cluster id)