* ATT（Stata称ATET），a为处理，y为结局
teffects psmatch (y) (a age severity, logit), atet nneighbor(1)
tebalance summarize
* 这是内置估计器示例，不与R卡钳匹配的全部细节完全等价。