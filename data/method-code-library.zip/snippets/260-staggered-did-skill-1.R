library(did)
data(mpdta)
att <- att_gt(yname="lemp",tname="year",idname="countyreal",
  gname="first.treat",xformla=~1,data=mpdta,panel=TRUE,
  control_group="nevertreated",est_method="dr",bstrap=TRUE,cband=TRUE)
summary(att)
dyn <- aggte(att,type="dynamic",min_e=-2,max_e=2)
summary(dyn)
ggdid(dyn)
aggte(att,type="group")