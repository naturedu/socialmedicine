# R
install.packages(c("lmtest", "sandwich", "car", "ggplot2", "texreg"))