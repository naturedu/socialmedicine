# R：混合 logit（mlogit rpar）
m2 <- mlogit(choice ~ a + b + c + d | 0, data = md,
             rpar = c(a = "n", b = "n", c = "n"),
             R = 500, halton = NA, panel = TRUE)
summary(m2)