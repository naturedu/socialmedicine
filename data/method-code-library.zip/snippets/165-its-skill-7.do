* ① 残差诊断
regress y time_c level trend_after
predict r, residuals
tsline r, yline(0) title("残差时序图")
ac r, lags(12) title("残差 ACF")

estat dwatson                    // Durbin-Watson（一阶）
actest, lags(4)                  // Cumby-Huizinga 一般检验（SSC；选项以 help actest 为准）
wntestq r, lags(4)               // Ljung-Box Q 检验

* 平稳性检查（结局本身）
dfuller y, trend

* ② Newey-West / HAC 标准误
newey y time_c level trend_after, lag(1)
* 默认滞后 = floor(4*(T/100)^(2/9))（T=48 → 3）；建议对 lag(1)–lag(4) 做敏感性

* ③ 备选：Prais-Winsten AR(1)（选项以 help prais 为准）
prais y time_c level trend_after, rhotype(tscorr)