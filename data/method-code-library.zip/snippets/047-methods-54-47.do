tsset time
gen post = (time >= t0)          // t0 = 政策实施期
gen time_after = (time - t0) * post
newey y time post time_after, lag(1)