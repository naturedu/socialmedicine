* Stata：DDD（三重交互项系数即效应）
reg y i.treat##i.post##i.group, vce(cluster id)