* Stata（联网安装一次）
ssc install mixlogit, replace
ssc install lclogit2, replace
ssc install dcreate,  replace