newey y time_c level trend_after, lag(1)
predict yhat, xb
gen yhat_cf = _b[_cons] + _b[time_c]*time_c       // 反事实：延续干预前趋势

twoway (scatter y time, msize(small) mcolor(gs8)) ///
       (line yhat time, lcolor(navy) lwidth(medthick)) ///
       (line yhat_cf time if time >= 25, lcolor(red) lpattern(dash) lwidth(medthick)) ///
       , xline(24.5, lcolor(gs10) lpattern(dash)) ///
         xtitle("月份") ytitle("次均费用（元）") ///
         title("ITS：DRG 改革对次均住院费用的影响") ///
         legend(order(1 "观测值" 2 "模型拟合" 3 "反事实（无干预）") position(6) rows(1))