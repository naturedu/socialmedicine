* Stata：评价类型选择示意（把结局类型写入 local 后运行）
local outcome "qaly"    // 可选：equivalent / natural / qaly / monetary
if "`outcome'" == "equivalent" {
    display "结局已证明等效 → 用 CMA（最小成本分析）"
}
else if "`outcome'" == "natural" {
    display "结局为自然单位（血压、生命年等）→ 用 CEA（成本-效果分析）"
}
else if "`outcome'" == "qaly" {
    display "结局为偏好加权指标（QALY/DALY）→ 用 CUA（成本-效用分析）"
}
else {
    display "结局已货币化或需跨领域比较 → 用 CBA（成本-效益分析）"
}