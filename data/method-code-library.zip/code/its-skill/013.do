* 教学片段：需结合原技能前置步骤和研究数据；本轮未运行。
* ---- 6.1 安慰剂时点：假设干预发生在第 13 个月（实际无干预）----
gen time_c13 = time - 13
gen level13  = time >= 13
gen trend13  = time_c13 * level13
newey y time_c13 level13 trend13, lag(1)
* 期望：level13、trend13 系数接近 0 且不显著

* ---- 6.2 季节性：加入月度虚拟变量（参考月 = 1 月）----
gen month = mod(time - 1, 12) + 1
tab month, gen(md)                          // 生成 md1–md12
newey y time_c level trend_after md2-md12, lag(1)
* 期望：β2、β3 与主模型接近（以实际结果为准）

* ---- 6.3 控制组 ITS（CITS）：双地区面板示意 ----
* 面板长表：id（地区）、time、y；treat = 1（干预地区，第 25 个月起受干预）
* 多组 itsa（语法与选项以 help itsa 为准）：
*     xtset id time
*     itsa y, treatperiod(25) treatid(treat) posttrend
* 手动 DID 型交互模型（示意）：
gen t_c   = time - 25
gen lev   = time >= 25
gen tr_a  = t_c * lev
gen g_lev = treat * lev        // 水平变化的组间差（政策即时效应，DID）
gen g_tr  = treat * tr_a       // 斜率变化的组间差（政策趋势效应，DID）
newey y t_c treat lev tr_a g_lev g_tr, lag(1)
* 关键系数：g_lev（相对对照组的即时水平变化）、g_tr（相对对照组的斜率变化）

* ---- 6.4 异常值敏感性：1%/99% 缩尾 ----
quietly summarize y, detail
gen y_w = min(max(y, r(p1)), r(p99))
newey y_w time_c level trend_after, lag(1)