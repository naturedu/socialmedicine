* 教学片段：需结合原技能前置步骤和研究数据；本轮未运行。
* 中心化版本（推荐）：β2 直接 = 干预时点即时效应
regress y time_c level trend_after
* 预计：_b[level] ≈ -600、_b[trend_after] ≈ -30（样本有噪声）

* 对照：未中心化版本（time 与 time*level 交互）
gen time_level = time * level
regress y time level time_level
* 此时 level 系数不再等于干预时点效应（是 time=0 处的跃变），须用组合计算