# 教学片段：需结合原技能前置步骤和研究数据；本轮未运行。
# 依赖 did；g 为首次处理年，未处理者为 0
library(did)
fit <- att_gt(yname="y", tname="year", idname="id", gname="g",
              data=df, control_group="notyettreated", panel=TRUE,
              clustervars="id", bstrap=TRUE)
es <- aggte(fit, type="dynamic")
summary(es); ggdid(es)
# 另检查提前反应、样本组成、同期政策与平行趋势；更高政策层级需相应聚类