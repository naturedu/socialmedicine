# 教学片段：需结合原技能前置步骤和研究数据；本轮未运行。
# R：同一计算 + 集中指数 + 情景比较
paf <- function(p, RR) p*(RR-1)/(p*(RR-1)+1)
B <- 12000
base  <- B * paf(0.35, 1.45)
after <- B * paf(0.25, 1.45)
avoid <- base - after
cat(sprintf("基线归因死亡 %.0f；干预后可避免死亡 %.0f\n", base, avoid))

# 集中指数
ci <- function(y, x) 2 * cov(y, rank(x)) / mean(y)
ci(health_y, income_x)