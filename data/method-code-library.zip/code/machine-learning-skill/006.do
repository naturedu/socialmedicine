* 教学片段：需结合原技能前置步骤和研究数据；本轮未运行。
* ---- 基线 logistic（含噪声变量，作为及格线）----
logit highcost age_s sex comorb_s los_s i.insurance z1-z5 if svar == 1
est store base

* ---- 基线线性回归（对数费用）----
regress lncost age_s sex comorb_s los_s i.insurance if svar == 1

* ---- LASSO（Stata 16+），CV 选 λ ----
lasso logit highcost age_s sex comorb_s los_s i.insurance z1-z5 if svar == 1, selection(cv) rseed(7)
cvplot                                     // CV 均方误差曲线
coefpath                                    // λ 路径（系数收缩轨迹）
lassocoef, display(coef, standardized)      // 选后系数：噪声变量应被剔除

* ---- 自适应 LASSO：先 CV 选 λ，再加自适应权重重估 ----
lasso, select(adaptive)
lassocoef, display(coef, standardized)

* ---- 弹性网（Stata 17+）----
elasticnet logit highcost age_s sex comorb_s los_s i.insurance z1-z5 if svar == 1, selection(cv) alpha(0.5) rseed(8)
lassocoef, display(coef, standardized)

* ---- 连续结局版：LASSO 回归 ----
lasso linear lncost age_s sex comorb_s los_s i.insurance z1-z5 if svar == 1, selection(cv) rseed(9)
lassocoef, display(coef, standardized)