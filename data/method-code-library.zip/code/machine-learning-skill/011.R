# 教学片段：需结合原技能前置步骤和研究数据；本轮未运行。
library(shapviz)

# ---- SHAP 值（XGBoost，测试集）----
sv <- shapviz(bst, X_pred = mte)
sv_importance(sv, kind = "both")                 # 平均|SHAP|条形图 + 蜂群图
sv_importance(sv, kind = "beeswarm")             # 蜂群图：颜色 = 特征取值方向
sv_dependence(sv, v = "age_s")                   # 依赖图：年龄的非线性贡献

# ---- 单个患者瀑布图 ----
i_hi <- which.max(p_xgb_te)                      # 测试集中预测风险最高者
sv_waterfall(sv, row_id = i_hi)

# ---- 随机森林置换重要性（比杂质重要性更稳健）----
set.seed(14)
rf_p <- ranger(factor(highcost) ~ ., data = te_m, num.trees = 500,
               importance = "permutation", probability = TRUE)
rf_p$variable.importance

# ---- 备选：DALEX（模型无关解释）----
# library(DALEX)
# ex <- explain(bst, data = as.data.frame(as.matrix(mte)), y = te_m$highcost)
# plot(model_parts(ex))                        # 置换重要性