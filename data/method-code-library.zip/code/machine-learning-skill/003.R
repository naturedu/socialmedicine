# 教学片段：需结合原技能前置步骤和研究数据；本轮未运行。
# ---- R：生成模拟数据（N = 1000，可全程复现）----
set.seed(2026)
n <- 1000
dat <- data.frame(
  id        = 1:n,
  age       = round(rnorm(n, 65, 12)),        # 年龄
  sex       = rbinom(n, 1, 0.52),             # 1 = 女
  comorb    = rpois(n, 1.5),                  # 合并症计数
  insurance = sample(c("城职", "城居", "新农合"), n, replace = TRUE,
                     prob = c(0.4, 0.3, 0.3)),
  los       = rpois(n, 7) + 1                 # 住院天数
)
dat$age    <- pmin(pmax(dat$age, 18), 95)
dat$comorb <- pmin(dat$comorb, 8)
for (k in 1:5) dat[[paste0("z", k)]] <- rnorm(n)   # 纯噪声特征

# 结局：同一套真实信号驱动两个结局（分类 + 连续）
lp <- -5 + 0.03 * dat$age + 0.45 * dat$comorb + 0.12 * dat$los +
      0.40 * (dat$insurance == "城职") + 0.25 * dat$sex
dat$highcost <- rbinom(n, 1, plogis(lp))      # 高费用 yes/no（约 25%）
dat$cost <- exp(7.5 + 0.01 * dat$age + 0.18 * dat$comorb + 0.05 * dat$los +
                0.25 * (dat$insurance == "城职") + 0.9 * dat$highcost +
                rnorm(n, 0, 0.5))             # 总费用（元，右偏）
table(dat$highcost); summary(dat)

# ---- 人为制造 10% MCAR 缺失（演示缺失处理用）----
set.seed(2)
dat$comorb[sample(n, 100)] <- NA

# ---- 70 / 15 / 15 拆分 ----
set.seed(3)
dat$split <- sample(rep(1:3, c(700, 150, 150)))   # 1=训练 2=验证 3=测试
tr <- dat[dat$split == 1, ]; va <- dat[dat$split == 2, ]; te <- dat[dat$split == 3, ]

# ---- 缺失值处理：用训练集中位数插补三组（演示；正式研究用 MICE 且在 CV 折内）----
m_med <- median(tr$comorb, na.rm = TRUE)
tr$comorb <- ifelse(is.na(tr$comorb), m_med, tr$comorb)
va$comorb <- ifelse(is.na(va$comorb), m_med, va$comorb)
te$comorb <- ifelse(is.na(te$comorb), m_med, te$comorb)

# 多重插补示例（正式研究用；注意应在 CV 折内进行）
# library(mice)
# imp <- mice(dat[, c("age","sex","comorb","los","highcost","cost")], m = 5, seed = 4)
# fit <- with(imp, glm(highcost ~ age + sex + comorb + los, family = binomial))
# pool(fit)

# ---- 标准化：只在训练集上计算均值 / SD，再套用到三组 ----
for (v in c("age", "comorb", "los")) {
  m <- mean(tr[[v]]); s <- sd(tr[[v]])
  tr[[paste0(v, "_s")]] <- (tr[[v]] - m) / s
  va[[paste0(v, "_s")]] <- (va[[v]] - m) / s
  te[[paste0(v, "_s")]] <- (te[[v]] - m) / s
}