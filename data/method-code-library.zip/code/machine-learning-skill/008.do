* 教学片段：需结合原技能前置步骤和研究数据；本轮未运行。
* ---- 随机森林（rforest，SSC；不支持因子变量写法，先造虚拟变量）----
tab ins if svar == 1, gen(ins_)
rforest highcost age_s sex comorb_s los_s ins_2 ins_3 z1-z5 if svar == 1, type(class) iterations(500) numvars(3) seed(11) vimp
* 预测概率的变量命名与后处理以 help rforest 为准；
* 调参（numvars / depth / lsize）应在验证集（svar == 2）上比较 AUC 后进行

* ---- 官方替代：梯度提升 boosting（Stata 17+）、svmachines（Stata 18）----
* boosting highcost age_s sex comorb_s los_s ins_2 ins_3 z1-z5 if svar == 1
* 语法与调参选项以 help boosting 为准