* 教学片段：需结合原技能前置步骤和研究数据；本轮未运行。
* ---- Stata 侧可解释性 ----
* rforest 变量重要性：vimp 选项生成的 _rf_v_* 变量（见 help rforest）
* lasso / elasticnet 的标准化系数即一种可解释性输出
lassocoef, display(coef, standardized)
* 局限：Stata 官方目前无 SHAP 实现；完整的 SHAP 分析建议在 R（shapviz）侧完成