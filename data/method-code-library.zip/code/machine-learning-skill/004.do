* 教学片段：需结合原技能前置步骤和研究数据；本轮未运行。
* ---- Stata：生成同一套模拟数据 ----
clear
set seed 2026
set obs 1000
gen id = _n
gen age = round(rnormal(65, 12))
replace age = min(max(age, 18), 95)
gen sex = rbinomial(1, 0.52)
gen comorb = min(rpoisson(1.5), 8)
gen u = runiform()
gen ins = cond(u < 0.4, 1, cond(u < 0.7, 2, 3))   // 1=城职 2=城居 3=新农合
label define inslab 1 "城职" 2 "城居" 3 "新农合"
label values ins inslab
gen los = rpoisson(7) + 1
forvalues k = 1/5 {
    gen z`k' = rnormal()                         // 纯噪声特征
}
gen lp = -5 + 0.03*age + 0.45*comorb + 0.12*los + 0.40*(ins == 1) + 0.25*sex
gen highcost = rbinomial(1, invlogit(lp))
gen cost = exp(7.5 + 0.01*age + 0.18*comorb + 0.05*los + 0.25*(ins == 1) + 0.9*highcost + rnormal(0, 0.5))
gen lncost = ln(cost)
tab highcost

* ---- 人为制造 10% MCAR 缺失 ----
set seed 2026
replace comorb = . if runiform() < 0.10

* ---- 70 / 15 / 15 拆分（1=训练 2=验证 3=测试）----
splitsample, generate(svar, replace) split(0.70 0.15 0.15) rseed(3)
tab svar

* ---- 缺失值处理：训练集中位数插补（演示；正式研究用 mi impute chained）----
summarize comorb if svar == 1, detail
replace comorb = r(p50) if missing(comorb)

* 多重插补示例（正式研究用）
* mi set mlong
* mi register imputed comorb
* mi impute chained (pmm) comorb = age sex los highcost cost, add(5) rseed(4)

* ---- 标准化：以训练集均值 / SD 为基准 ----
foreach v in age comorb los {
    quietly summarize `v' if svar == 1
    gen `v'_s = (`v' - r(mean)) / r(sd)
}