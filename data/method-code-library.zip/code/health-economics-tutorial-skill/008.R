# 教学片段：需结合原技能前置步骤和研究数据；本轮未运行。
# R：直接医疗成本示例数据（贯穿算例：对照组均值 6040、干预组均值 9180）
cost0 <- c(6000, 5500, 6800, 5900, 6200, 6100, 5700, 6400, 5800, 6000)
cost1 <- c(9000, 8800, 9500, 9200, 8900, 9600, 9100, 9300, 9000, 9400)
c(mean0 = mean(cost0), mean1 = mean(cost1))
t.test(cost0)$conf.int          # 对照组 95% CI（正态近似）
t.test(cost1)$conf.int          # 干预组 95% CI

# bootstrap：两组成本之差的 95% 百分位 CI
library(boot)
d <- data.frame(cost = c(cost0, cost1), group = rep(c(0, 1), each = 10))
diff_mean <- function(data, i) {
  g <- data[i, ]
  mean(g$cost[g$group == 1]) - mean(g$cost[g$group == 0])
}
set.seed(2026)
b <- boot(d, diff_mean, R = 1000)
boot.ci(b, type = "perc")       # 差值点估计 ≈ 9180 - 6040 = 3140 元