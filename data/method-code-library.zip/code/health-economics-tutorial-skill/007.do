* 教学片段：需结合原技能前置步骤和研究数据；本轮未运行。
* Stata：直接医疗成本示例数据（元/人/年；与贯穿算例一致：对照均值 6040、干预均值 9180）
clear
input byte group int cost
0 6000
0 5500
0 6800
0 5900
0 6200
0 6100
0 5700
0 6400
0 5800
0 6000
1 9000
1 8800
1 9500
1 9200
1 8900
1 9600
1 9100
1 9300
1 9000
1 9400
end
label define grp 0 "对照" 1 "干预"
label values group grp

* 均数与 95% CI（正态近似）
mean cost, over(group)
ci means cost if group == 0
ci means cost if group == 1

* bootstrap：两组成本之差的 95% 百分位区间与偏差校正（BC）区间
capture program drop diff_cost
program define diff_cost, rclass
    quietly summarize cost if group == 0
    local m0 = r(mean)
    quietly summarize cost if group == 1
    local m1 = r(mean)
    return scalar diff = `m1' - `m0'
end
bootstrap r(diff), reps(1000) seed(2026) nodots: diff_cost
estat bootstrap, percentile bc