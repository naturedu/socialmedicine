* 教学片段：需结合原技能前置步骤和研究数据；本轮未运行。
* Stata（本教程主要用官方命令；结果表导出可选用 estout，putexcel 为官方命令）
ssc install estout, replace