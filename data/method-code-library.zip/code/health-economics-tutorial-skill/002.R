# 教学片段：需结合原技能前置步骤和研究数据；本轮未运行。
# R
install.packages("boot")      # bootstrap 置信区间；其余均为基础 R