# 教学片段：需结合原技能前置步骤和研究数据；本轮未运行。
# R：QALY 与增量 QALY（未贴现）
u0 <- 0.70; u1 <- 0.78; years <- 10
Q0 <- u0 * years        # 7.0
Q1 <- u1 * years        # 7.8
dQ <- Q1 - Q0           # 0.8 QALY
list(QALY_control = Q0, QALY_treat = Q1, dQALY = dQ)

# R：DALY 简算示意：DALY = YLL + YLD
YLL <- 10               # 早亡损失的生命年（示例）
YLD <- 2.5              # 伤残状态生存年 × 伤残权重（示例）
YLL + YLD               # 12.5 DALY

# 提示：EQ-5D 状态（如 21121）须用已发表的中国积分体系系数换算效用值，
# 勿自造系数；换算公式形如 U = 1 −（常数项 + 各维度离差项 + 交互/极端项）