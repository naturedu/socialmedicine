# 教学片段：需结合原技能前置步骤和研究数据；本轮未运行。
# R：导出主要结果表
res <- data.frame(
  指标 = c("贴现后 ΔC（元）", "贴现后 ΔE（QALY）", "ICER（元/QALY）",
           "阈值 λ（元/QALY）", "净收益 NB（元）"),
  数值 = c(30886.9, 0.6177, 50003, 100000, 30887))
res
write.csv(res, "results.csv", row.names = FALSE)