* 教学片段：需结合原技能前置步骤和研究数据；本轮未运行。
* Stata：把主要结果写入 Excel（putexcel，Stata 14+）
putexcel set results.xlsx, replace
putexcel A1 = "指标" B1 = "数值"
putexcel A2 = "贴现后 ΔC（元）"        B2 = 30886.9
putexcel A3 = "贴现后 ΔE（QALY）"      B3 = 0.6177
putexcel A4 = "ICER（元/QALY）"        B4 = 50003
putexcel A5 = "阈值 λ（元/QALY）"      B5 = 100000
putexcel A6 = "净收益 NB（元）"        B6 = 30887