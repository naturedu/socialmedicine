# 教学片段：需结合原技能前置步骤和研究数据；本轮未运行。
# R：概率敏感性分析（PSA）示意——直接从 ΔC、ΔE 的分布抽样；
# 正式研究应从参数层面抽样（成本 gamma、概率 beta、RR lognormal），
# 完整实现见《Markov 模型助手》skill。
set.seed(2026)
n <- 1000
dC <- rnorm(n, mean = 30886.9, sd = 3200)     # 增量成本（元）
dE <- rnorm(n, mean = 0.6177, sd = 0.05)      # 增量 QALY

# 成本-效果平面散点图（λ = 100000 元/QALY 的斜率线）
plot(dE, dC, xlab = "ΔE（QALY）", ylab = "ΔC（元）", pch = 20,
     cex = 0.5, col = rgb(0, 0, 0, 0.3), main = "PSA 成本-效果平面散点图")
abline(h = 0, v = 0, lty = 2)
abline(a = 0, b = 100000, col = "red")        # 斜率 = λ

# 各象限模拟点占比
quad <- ifelse(dE > 0, ifelse(dC > 0, "NE", "SE"),
               ifelse(dC > 0, "NW", "SW"))
table(quad) / n

# 成本-效果可接受曲线（CEAC）：P(NMB(λ) > 0)
lam  <- seq(0, 300000, by = 5000)
ceac <- sapply(lam, function(x) mean(x * dE - dC > 0))
plot(lam, ceac, type = "l", xlab = "支付意愿阈值 λ（元/QALY）",
     ylab = "具有成本-效果的概率", ylim = c(0, 1))
abline(h = 0.5, lty = 3)