* 教学片段：需结合原技能前置步骤和研究数据；本轮未运行。
logit y i.exposure c.age, vce(robust)
margins exposure
margins, dydx(exposure)
* 优势比不等于风险比；设计、混杂控制和聚类层级需先确定