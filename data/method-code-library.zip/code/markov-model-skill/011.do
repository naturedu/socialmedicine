* 教学片段：需结合原技能前置步骤和研究数据；本轮未运行。
* ============ 第 5 步：队列模拟（Stata 纯循环） ============
local T = 30                     // 时间范围（年/周期）
* 策略 A：常规治疗
local p_hs1 = 1 - exp(-0.02)     // 无并发症→卒中（率 0.02/年）
local p_hd1 = 0.010              // 无并发症→死亡
local p_sd1 = 1 - exp(-0.10)     // 卒中后→死亡（率 0.10/年）
local c_well1 = 3000             // 无并发症年成本
local c_sick1 = 20000            // 卒中后年成本
local u_well1 = 0.85             // 效用
local u_sick1 = 0.62
* 策略 B：干预（卒中风险降 30%）
local p_hs2 = 1 - exp(-0.02*0.70)
local p_hd2 = 0.010
local p_sd2 = 1 - exp(-0.10)
local c_well2 = 3500             // 无并发症年成本 + 500 元药费
local c_sick2 = 20000
local u_well2 = 0.85
local u_sick2 = 0.62

matrix R = J(0, 4, .)            // 收集两策略结果：成本/QALY × (5%, 3%)

forvalues s = 1/2 {
    * ---- 状态占位（行 1..T+1；行 1 为起始分布） ----
    clear
    set obs `=`T'+1'
    gen healthy = .
    gen sick    = .
    gen dead    = .
    replace healthy = 1 in 1       // 起始：100% 无并发症
    replace sick    = 0 in 1
    replace dead    = 0 in 1
    * ---- 转移循环：trace(t+1) = trace(t) × P ----
    forvalues t = 2/`=`T'+1' {
        replace healthy = healthy[`t'-1]*(1-`p_hs`s''-`p_hd`s'') in `t'
        replace sick    = healthy[`t'-1]*`p_hs`s'' + sick[`t'-1]*(1-`p_sd`s'') in `t'
        replace dead    = dead[`t'-1] + healthy[`t'-1]*`p_hd`s'' + sick[`t'-1]*`p_sd`s'' in `t'
    }
    * ---- 每周期成本与 QALY（期初状态） ----
    gen cost_cyc = healthy*`c_well`s'' + sick*`c_sick`s''
    gen qaly_cyc = healthy*`u_well`s'' + sick*`u_sick`s''
    * ---- 贴现 5%：半周期校正权重 1/(1+d)^(n-0.5)，只累加第 1..T 周期 ----
    gen w05 = 1/(1+0.05)^(_n-0.5) if _n <= `T'
    gen cost05 = cost_cyc*w05
    gen qaly05 = qaly_cyc*w05
    qui sum cost05
    local c05_`s' = r(sum)
    qui sum qaly05
    local q05_`s' = r(sum)
    * ---- 贴现 3%（敏感性情景） ----
    gen w03 = 1/(1+0.03)^(_n-0.5) if _n <= `T'
    gen cost03 = cost_cyc*w03
    gen qaly03 = qaly_cyc*w03
    qui sum cost03
    local c03_`s' = r(sum)
    qui sum qaly03
    local q03_`s' = r(sum)
    * ---- 30 年死亡比例（行 T+1 的 dead） ----
    local d30_`s' = dead[`=`T'+1']
    matrix R = R \ (`c05_`s'', `q05_`s'', `c03_`s'', `q03_`s'')
}
matrix rownames R = A B
matrix colnames R = cost5 qaly5 cost3 qaly3
matrix list R, format(%12.2f)
display "30 年死亡比例：A = " %6.4f `d30_1' "；B = " %6.4f `d30_2'
* 期望输出：A: cost5≈63186.10, qaly5≈10.7716；B: cost5≈63913.00, qaly5≈11.1113
*           A: cost3≈80062.67, qaly3≈13.1935；B: cost3≈80588.47, qaly3≈13.6758
*           30 年死亡比例：A≈0.4894，B≈0.4314