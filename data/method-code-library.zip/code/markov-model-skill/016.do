* 教学片段：需结合原技能前置步骤和研究数据；本轮未运行。
* ============ 第 7.1 步：tornado（Stata/Mata） ============
* 把第 5 步的循环封装成 Mata 函数（敏感性分析需反复调用，Mata 更快）
capture mata mata drop markov_ce()
mata:
real colvector markov_ce(real scalar phs, real scalar phd, real scalar psd,
                         real scalar cw, real scalar cs,
                         real scalar uw, real scalar us,
                         real scalar d, real scalar T)
{
    real matrix  P, trace, cyc
    real colvector w, c, q
    P = ((1-phs-phd, phs, phd) \ (0, 1-psd, psd) \ (0, 0, 1))
    trace = J(T+1, 3, 0)
    trace[1, 1] = 1
    for (t = 1; t <= T; t++) trace[t+1, .] = trace[t, .] * P
    w   = 1 :/ (1+d) :^ ((1::T) :- 0.5)
    cyc = trace[1..T, .]
    c   = colsum((cyc[,1]*cw + cyc[,2]*cs) :* w)
    q   = colsum((cyc[,1]*uw + cyc[,2]*us) :* w)
    return((c \ q))
}
end

mata:
phsA = 1-exp(-0.02)
phsB = 1-exp(-0.014)
phd  = 0.010
psd  = 1-exp(-0.10)
bA = (phsA, phd, psd, 3000, 20000, 0.85, 0.62)    // 对照臂基线（1×7）
bB = (phsB, phd, psd, 3500, 20000, 0.85, 0.62)    // 干预臂基线
nm = ("对照卒中率", "干预卒中率", "背景死亡", "卒中后死亡",
      "无并发症成本", "卒中后成本", "效用-无并发症", "效用-卒中后")
pair = J(0, 3, .)                                  // 参数序号、低值 ICER、高值 ICER
for (i = 1; i <= 8; i++) {
    loA = bA; loB = bB; hiA = bA; hiB = bB
    if (i == 1) {
        loA[1] = bA[1]*0.8; hiA[1] = bA[1]*1.2      // 仅对照臂变
    }
    else if (i == 2) {
        loB[1] = bB[1]*0.8; hiB[1] = bB[1]*1.2      // 仅干预臂变
    }
    else {
        j = i - 1                                    // 共用参数：两臂同变
        loA[j] = bA[j]*0.8; loB[j] = bB[j]*0.8
        hiA[j] = bA[j]*1.2; hiB[j] = bB[j]*1.2
    }
    ra = markov_ce(loA[1], loA[2], loA[3], loA[4], loA[5], loA[6], loA[7], 0.05, 30)
    rb = markov_ce(loB[1], loB[2], loB[3], loB[4], loB[5], loB[6], loB[7], 0.05, 30)
    icer_lo = (rb[1]-ra[1]) / (rb[2]-ra[2])
    ra = markov_ce(hiA[1], hiA[2], hiA[3], hiA[4], hiA[5], hiA[6], hiA[7], 0.05, 30)
    rb = markov_ce(hiB[1], hiB[2], hiB[3], hiB[4], hiB[5], hiB[6], hiB[7], 0.05, 30)
    icer_hi = (rb[1]-ra[1]) / (rb[2]-ra[2])
    pair = pair \ (i, icer_lo, icer_hi)
}
ra = markov_ce(bA[1], bA[2], bA[3], bA[4], bA[5], bA[6], bA[7], 0.05, 30)
rb = markov_ce(bB[1], bB[2], bB[3], bB[4], bB[5], bB[6], bB[7], 0.05, 30)
icer0 = (rb[1]-ra[1]) / (rb[2]-ra[2])
(nm, pair[,2], pair[,3])                           // 打印结果表
st_matrix("TOR", (pair[,2], pair[,3]))
st_numscalar("r_icer0", icer0)
end
* 期望输出（基例 ICER ≈ 2140）：对照卒中率变化最大（ICER 约 -4734 ~ 37574）；
* 负值表示该情景下干预占优或落入其他象限，绘图与报告需注明。

* ---- tornado 图（横条 + 基线竖线；y 轴序号对应上述参数顺序） ----
svmat TOR
gen y = _n
twoway (rcap TOR1 TOR2 y, horizontal lcolor(navy)) ///
    (scatter y TOR1) (scatter y TOR2), ///
    xline(`=scalar(r_icer0)', lpattern(dash) lcolor(red)) ///
    ylabel(1(1)8) xtitle("ICER（元/QALY）") ytitle("参数序号") ///
    legend(off) name(tornado, replace)