# 教学片段：需结合原技能前置步骤和研究数据；本轮未运行。
# ============ 第 5 步：队列模拟（R 从头写） ============
T <- 30
p_hsA <- 1 - exp(-0.02)          # 无并发症→卒中（对照）
p_hsB <- 1 - exp(-0.02*0.70)     # 无并发症→卒中（干预）
p_hd  <- 0.010                   # 背景死亡
p_sd  <- 1 - exp(-0.10)          # 卒中后死亡
PA <- matrix(c(1-p_hsA-p_hd, p_hsA, p_hd,
               0,           1-p_sd, p_sd,
               0,           0,      1), nrow = 3, byrow = TRUE)
PB <- matrix(c(1-p_hsB-p_hd, p_hsB, p_hd,
               0,           1-p_sd, p_sd,
               0,           0,      1), nrow = 3, byrow = TRUE)

# 队列模拟：trace(t+1) = trace(t) %*% P；奖励按周期期初状态、权重 1/(1+d)^(t-0.5)
sim <- function(P, c_well, c_sick, u_well, u_sick, dr, T = 30) {
  trace <- matrix(0, nrow = T + 1, ncol = 3)
  trace[1, ] <- c(1, 0, 0)                      # 起始：100% 无并发症
  for (t in seq_len(T)) trace[t + 1, ] <- trace[t, ] %*% P
  w   <- 1 / (1 + dr)^(seq_len(T) - 0.5)        # 半周期校正 + 贴现权重
  cyc <- trace[seq_len(T), ]                    # 第 1..T 周期的期初分布
  cost <- sum((cyc[, 1] * c_well + cyc[, 2] * c_sick) * w)
  qaly <- sum((cyc[, 1] * u_well + cyc[, 2] * u_sick) * w)
  c(cost = cost, qaly = qaly, p_dead = trace[T + 1, 3])
}

resA5 <- sim(PA, 3000, 20000, 0.85, 0.62, 0.05, T)
resB5 <- sim(PB, 3500, 20000, 0.85, 0.62, 0.05, T)
resA3 <- sim(PA, 3000, 20000, 0.85, 0.62, 0.03, T)
resB3 <- sim(PB, 3500, 20000, 0.85, 0.62, 0.03, T)
round(rbind("A(5%)" = resA5, "B(5%)" = resB5,
            "A(3%)" = resA3, "B(3%)" = resB3), 2)
# 期望输出（与 5.1 的 Stata 结果一致）：
#   A(5%): cost=63186.10, qaly=10.77, p_dead=0.4894
#   B(5%): cost=63913.00, qaly=11.11, p_dead=0.4314
#   A(3%): cost=80062.67, qaly=13.19；B(3%): cost=80588.47, qaly=13.68