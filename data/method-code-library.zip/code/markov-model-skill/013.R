# 教学片段：需结合原技能前置步骤和研究数据；本轮未运行。
# ============ 第 5 步（heemod 等价实现，heemod ≥ 1.0 API） ============
library(heemod)

p_hsA <- 1 - exp(-0.02); p_hsB <- 1 - exp(-0.02*0.70)
p_hd  <- 0.010; p_sd <- 1 - exp(-0.10)

# 转移矩阵：C = 行内其余概率的补数（1 - 其他项之和），行和自动为 1
matA <- define_transition(
  C, p_hsA, p_hd,
  0, C,     p_sd,
  0, 0,     C)
matB <- define_transition(
  C, p_hsB, p_hd,
  0, C,     p_sd,
  0, 0,     C)

# 状态值：discount() 在模型内按周期贴现；dispatch_strategy 区分策略成本
# （策略名 std / intv 须与 run_model 中的名字一致）
state_well <- define_state(
  cost    = discount(dispatch_strategy(std = 3000, intv = 3500), .05),
  utility = 0.85)
state_sick <- define_state(
  cost    = discount(20000, .05),
  utility = 0.62)
state_dead <- define_state(
  cost    = 0,
  utility = 0)

stratA <- define_strategy(transition = matA,
                          state_well, state_sick, state_dead)
stratB <- define_strategy(transition = matB,
                          state_well, state_sick, state_dead)

res <- run_model(
  std  = stratA,
  intv = stratB,
  cycles = 30,
  init   = c(1, 0, 0),      # 按 1 人队列（默认 1000 人）
  cost   = cost,            # 成本取状态值 cost
  effect = utility,         # 效果取状态值 utility（QALY）
  method = "life-table")    # 半周期校正；默认 "beginning" 不做半周期校正

summary(res, threshold = c(100000, 300000))  # 阈值：1–3 倍人均 GDP（元/QALY）
get_counts(res)                              # 各周期各状态人数
plot(res, type = "counts", panels = "by_strategy")   # 状态分布图
plot(res, type = "ce")                       # 成本-效果平面与效率前沿
# 注：heemod 的贴现时点约定（discount() 默认首周期不打折）与 5.1/5.2 的
# (t-0.5) 约定略有差异，结果会有小幅出入；报告时统一约定并注明实现。
# heemod 1.0 起 run_model 已无 discount 参数，贴现写在 define_state 的
# discount() 中（旧版 API 见 help(run_model)）。