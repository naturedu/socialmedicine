# 教学片段：需结合原技能前置步骤和研究数据；本轮未运行。
# ============ 第 7.2 步：PSA（R：基础循环 + 绘图） ============
set.seed(2026)
N <- 1000
psa <- matrix(NA, nrow = N, ncol = 4,
              dimnames = list(NULL, c("cA", "qA", "cB", "qB")))
for (i in 1:N) {
  r_hs <- rlnorm(1, meanlog = log(0.02), sdlog = 0.20)   # 卒中发生率
  rr   <- rlnorm(1, meanlog = log(0.70), sdlog = 0.10)   # 干预 RR
  p_hsA <- 1 - exp(-r_hs)
  p_hsB <- 1 - exp(-r_hs * rr)
  p_hd  <- rbeta(1, 24.74, 2449.26)                      # 背景死亡概率
  p_sd  <- 1 - exp(-rlnorm(1, meanlog = log(0.10), sdlog = 0.15))
  cA0   <- rgamma(1, shape = 25, scale = 120)            # 注意：scale= 必须显式
  cB0   <- cA0 + rgamma(1, shape = 25, scale = 20)       #（默认第二参数是 rate）
  cS    <- rgamma(1, shape = 25, scale = 800)
  uW    <- rbeta(1, 119.6, 21.1)
  uS    <- rbeta(1, 57.8, 35.4)
  PAi <- matrix(c(1-p_hsA-p_hd, p_hsA, p_hd,
                  0, 1-p_sd, p_sd,
                  0, 0, 1), nrow = 3, byrow = TRUE)
  PBi <- matrix(c(1-p_hsB-p_hd, p_hsB, p_hd,
                  0, 1-p_sd, p_sd,
                  0, 0, 1), nrow = 3, byrow = TRUE)
  rA <- sim(PAi, cA0, cS, uW, uS, 0.05, 30)              # 复用第 5.2 步的 sim()
  rB <- sim(PBi, cB0, cS, uW, uS, 0.05, 30)
  psa[i, ] <- c(rA["cost"], rA["qaly"], rB["cost"], rB["qaly"])
}
head(psa)

dC <- psa[, "cB"] - psa[, "cA"]
dE <- psa[, "qB"] - psa[, "qA"]

# 成本-效果散点图（含象限线与阈值线）
plot(dE, dC, xlab = "增量 QALY", ylab = "增量成本（元）",
     main = "PSA 成本-效果散点图 (n = 1000)",
     pch = 16, col = rgb(0, 0, 0, 0.25))
abline(h = 0, lty = 2); abline(v = 0, lty = 2)
abline(a = 0, b = 100000, col = "red")   # λ = 100000 元/QALY 阈值线
text(quantile(dE, 0.05), quantile(dC, 0.95),
     paste0("P(占优) = ", round(mean(dC < 0 & dE > 0), 3)))

# CEAC
lam_grid <- seq(0, 300000, by = 5000)
ceac <- sapply(lam_grid, function(l) mean(dC - l*dE < 0))
plot(lam_grid, ceac, type = "l", xlab = "阈值 λ（元/QALY）",
     ylab = "具有成本效果的概率", main = "CEAC")
abline(h = 0.5, lty = 3); abline(h = 0.95, lty = 3)
# 期望（示意）：本示例各阈值下 P(CE) > 0.99，P(占优) ≈ 0.36；
# heemod 集成版 PSA 见 vignette("e-probabilistic", "heemod")（define_psa + run_psa）