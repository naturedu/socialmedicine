* 教学片段：需结合原技能前置步骤和研究数据；本轮未运行。
* Stata：由均值 / 区间反推 PSA 分布参数（矩法）
* beta：效用 0.85、sd 0.03 → alpha、beta
display 0.85*(0.85*(1-0.85)/0.03^2 - 1)          // alpha ≈ 119.57
display (1-0.85)*(0.85*(1-0.85)/0.03^2 - 1)      // beta  ≈ 21.10
* gamma：成本 3000、sd 600 → shape、scale
display 3000^2/600^2                              // shape = 25
display 600^2/3000                                // scale = 120
* lognormal：率 95% CI [0.015, 0.03] → sdlog
display (ln(0.03) - ln(0.015)) / (2*1.96)         // sdlog ≈ 0.177