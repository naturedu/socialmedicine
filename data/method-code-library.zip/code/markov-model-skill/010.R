# 教学片段：需结合原技能前置步骤和研究数据；本轮未运行。
# R：同上（矩法）
beta_mom  <- function(m, sd) { k <- m*(1-m)/sd^2 - 1; c(alpha = m*k, beta = (1-m)*k) }
gamma_mom <- function(m, sd) c(shape = m^2/sd^2, scale = sd^2/m)
beta_mom(0.85, 0.03)                     # alpha 119.57, beta 21.10
gamma_mom(3000, 600)                     # shape 25, scale 120
(log(0.03) - log(0.015)) / (2*1.96)      # sdlog 0.177