* 教学片段：需结合原技能前置步骤和研究数据；本轮未运行。
* WTP 与置信区间（clogit，delta 方法）
nlcom wtp_b: -_b[b] / _b[d], post
estimates store wtp_b

* 三模型并列输出
estimates table clogit mixl lc3, b(%9.3f) se stats(N aic bic)