# 教学片段：需结合原技能前置步骤和研究数据；本轮未运行。
# R：同一检查
library(dplyr)
dat |> group_by(id) |>
  summarise(n_optout = sum(choice == 1 & alt == 3),
            n_A      = sum(choice == 1 & alt == 1),
            n_total  = n_distinct(choice_set))