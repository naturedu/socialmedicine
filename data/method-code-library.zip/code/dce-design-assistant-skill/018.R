# 教学片段：需结合原技能前置步骤和研究数据；本轮未运行。
# R：混合 logit（mlogit rpar）
m2 <- mlogit(choice ~ a + b + c + d | 0, data = md,
             rpar = c(a = "n", b = "n", c = "n"),
             R = 500, halton = NA, panel = TRUE)
summary(m2)