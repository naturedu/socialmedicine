# 教学片段：需结合原技能前置步骤和研究数据；本轮未运行。
# R：delta 方法 WTP（car::deltaMethod）
library(car)
deltaMethod(coef(m1), "-b/d")               # 按实际系数名替换 b、d