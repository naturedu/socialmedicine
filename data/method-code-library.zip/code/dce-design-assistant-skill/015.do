* 教学片段：需结合原技能前置步骤和研究数据；本轮未运行。
clogit choice a b c d, group(choice_set) vce(cluster id)
est store clogit

* WTP：d 为费用属性时的属性 b 的 WTP（delta 方法，含 95% CI）
nlcom wtp_b: -_b[b] / _b[d]

* IIA 直觉检验：删除 opt-out 后系数应大体稳定
clogit choice a b c d if alt != 3, group(choice_set) vce(cluster id)