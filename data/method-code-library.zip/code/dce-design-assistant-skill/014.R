# 教学片段：需结合原技能前置步骤和研究数据；本轮未运行。
# R：dfidx 构造选择数据（mlogit 用）
library(mlogit)
md <- dfidx(dat, idx = c("id", "alt"), choice = "choice")