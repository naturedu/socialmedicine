* 教学片段：需结合原技能前置步骤和研究数据；本轮未运行。
* Stata：水平平衡 + 两两相关
tab1 a b c d
pwcorr a b c d