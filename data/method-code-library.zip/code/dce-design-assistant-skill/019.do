* 教学片段：需结合原技能前置步骤和研究数据；本轮未运行。
lclogit2 choice a b c d, group(choice_set) id(id) nclasses(2) seed(2026)
lclogit2, nclasses(3) seed(2026)            // 比较 BIC/AIC 选类别数
est store lc3
lclogitprob, cpprob(3)                      // 各类别平均成员概率
estat lcmean, post                          // 各类别协变量均值（刻画类别特征）

* 类成员协变量模型（membership 方程放入 age、income）
lclogitml choice a b c d, group(choice_set) id(id) nclasses(3) membership(age income)

* WTP：lcwtp（lclogit2 附带），语法以 help lcwtp 为准；
* 或手工取各类别系数比值并配合 delta 方法