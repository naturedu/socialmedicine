# 教学片段：需结合原技能前置步骤和研究数据；本轮未运行。
m <- lm(y ~ time + post + time_after, data = dat)
lmtest::coeftest(m, vcov = sandwich::NeweyWest(m, lag = 1))