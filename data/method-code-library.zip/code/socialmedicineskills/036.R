# 教学片段：需结合原技能前置步骤和研究数据；本轮未运行。
## R：fixest 双向固定效应 DID
feols(y ~ treat*post | id + time, data = dat, cluster = ~id)