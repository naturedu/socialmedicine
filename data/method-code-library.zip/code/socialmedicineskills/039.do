* 教学片段：需结合原技能前置步骤和研究数据；本轮未运行。
* Stata：DDD（三重交互项系数即效应）
reg y i.treat##i.post##i.group, vce(cluster id)