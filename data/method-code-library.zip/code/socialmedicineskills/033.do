* 教学片段：需结合原技能前置步骤和研究数据；本轮未运行。
ssc install reghdfe
ssc install coefplot
reghdfe y ib(-1).time#i.treat, absorb(id time) vce(cluster id)
coefplot, keep(*.time#1.treat)          // 事件研究图