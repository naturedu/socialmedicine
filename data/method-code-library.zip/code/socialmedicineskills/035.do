* 教学片段：需结合原技能前置步骤和研究数据；本轮未运行。
* Stata：2×2 DID（交互项系数即效应）
reg y i.treat##i.post, vce(cluster id)