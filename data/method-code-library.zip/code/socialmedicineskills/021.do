* 教学片段：需结合原技能前置步骤和研究数据；本轮未运行。
* DRG 权重：病组例均费用 ÷ 全样本例均费用
bysort drg: egen fee_drg = mean(fee)
egen fee_all = mean(fee)
gen rw = fee_drg / fee_all
* DIP 点值：区域基金总额 ÷ Σ(病种分值 × 病例数)
gen point_amt = dip_score * n_cases
sum point_amt
di "每分值金额 = " fund_budget / r(sum)