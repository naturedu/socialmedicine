* 教学片段：需结合原技能前置步骤和研究数据；本轮未运行。
* 逐年预算影响 = 目标人群 × 渗透率 ×（新方案 − 现行方案）人均年费用
gen bi = pop * uptake * (c_new - c_cur)
list year bi
sum bi                         // 研究期内合计