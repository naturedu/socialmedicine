# 教学片段：需结合原技能前置步骤和研究数据；本轮未运行。
library(QCA)
dat2 <- data.frame(成效 = calibrate(score, c(60, 75, 90)),
                   资源 = calibrate(res, c(10, 20, 30)),
                   人员 = calibrate(staff, c(5, 10, 15)),
                   激励 = calibrate(inc, c(0.2, 0.5, 0.8)),
                   信息化 = calibrate(it, c(1, 3, 5)))
tt <- truthTable(dat2, outcome = "成效", n.cut = 1, incl.cut = 0.8)
minimize(tt, include = "?")            # 中间解