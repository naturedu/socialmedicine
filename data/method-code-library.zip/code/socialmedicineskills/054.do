* 教学片段：需结合原技能前置步骤和研究数据；本轮未运行。
* 结构层：ses 教育年限/收入/职业 | 中间层：housing 居住条件、smoke 吸烟、stress 心理压力 | 结局：health
* Oaxaca-Blinder 分解：高/低 SES 组健康差距分解为「禀赋效应 + 系数效应」
ssc install oaxaca
oaxaca health housing smoke stress, by(ses_group)