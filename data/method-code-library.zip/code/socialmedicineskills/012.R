# 教学片段：需结合原技能前置步骤和研究数据；本轮未运行。
dC <- with(dat, mean(c[arm == 1]) - mean(c[arm == 0]))
dE <- with(dat, mean(e[arm == 1]) - mean(e[arm == 0]))
set.seed(2026)
icers <- replicate(1000, with(dat[sample(nrow(dat), replace = TRUE), ],
              (mean(c[arm==1]) - mean(c[arm==0])) / (mean(e[arm==1]) - mean(e[arm==0]))))
quantile(icers, c(.025, .975))   # bootstrap ICER 置信区间