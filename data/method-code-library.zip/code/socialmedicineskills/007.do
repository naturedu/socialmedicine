* 教学片段：需结合原技能前置步骤和研究数据；本轮未运行。
* ===== Stata =====
ttest score, by(group)                 // 定量侧比较
tab theme group, chi2                  // 定性主题（编码后）与分组交叉：量化整合

* ===== R =====
library(quanteda)
dfm <- dfm(tokens(interview_text), remove_punct = TRUE)   # 定性文本：词频辅助主题
topfeatures(dfm, 20)
t.test(score ~ group, data = d)                           # 定量侧
chisq.test(table(d$theme, d$group))                       # 主题×分组整合