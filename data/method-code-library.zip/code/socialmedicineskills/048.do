* 教学片段：需结合原技能前置步骤和研究数据；本轮未运行。
* 健康需求简化式：H = f(工资率 w, 教育 E, 年龄 t, 医疗服务价格 p)
* 预期：教育、工资系数为正（效率与投资回报），年龄为负（折旧），价格为负
reg health lnwage edu age age2 lnprice
* 教育→健康的机制检验：加入知识/行为中介后看 edu 系数变化
reg health edu age
reg health edu age knowl healthbehavior