* 教学片段：需结合原技能前置步骤和研究数据；本轮未运行。
tsset time
gen post = (time >= t0)          // t0 = 政策实施期
gen time_after = (time - t0) * post
newey y time post time_after, lag(1)