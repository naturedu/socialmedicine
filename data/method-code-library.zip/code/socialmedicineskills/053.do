* 教学片段：需结合原技能前置步骤和研究数据；本轮未运行。
* 集中指数 CI（便利回归法）：按收入排序后，2*σ²_rank*(h/μ) 对 rank 回归
sort income
gen rank = _n / _N
quietly summarize h
local mu = r(mean)
quietly summarize rank
gen lhs = 2 * r(Var) * (h / `mu')
reg lhs rank
* _b[rank] 即 CI（正=亲富，负=亲穷）；SSC 版：ssc install conindex; conindex h, rankvar(income)