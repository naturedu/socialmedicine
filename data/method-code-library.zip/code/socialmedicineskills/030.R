# 教学片段：需结合原技能前置步骤和研究数据；本轮未运行。
library(rdrobust)
rdrobust(y = dat$y, x = dat$x, c = 0)
rddensity::rddensity(dat$x, c = 0)   # 操纵检验