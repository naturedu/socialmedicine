* 教学片段：需结合原技能前置步骤和研究数据；本轮未运行。
* PSA 决策判断：净货币效益 NMB = λ·ΔE − ΔC，λ 为阈值（如 1–3 倍人均 GDP）
gen nmb = lambda * (e_new - e_cur) - (c_new - c_cur)
count if nmb > 0
di "成本-效果概率 = " r(N) / _N