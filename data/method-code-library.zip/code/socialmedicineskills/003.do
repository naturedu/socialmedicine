* 教学片段：需结合原技能前置步骤和研究数据；本轮未运行。
* ===== Stata =====
cs disease exposed, exact                  // 2×2：RR 及 CI
ir disease exposed                         // 发病密度比 IRR
stset time, failure(disease)               // 人时/生存数据
strate exposed                             // 各组人时与发病率
poisson disease exposed, exposure(time) irr
stcox exposed age                          // 校正 HR

* ===== R =====
library(epiR)
epi.2by2(matrix(c(45, 955, 20, 980), nrow = 2), method = "cohort.count")
glm(disease ~ exposed + offset(log(time)), family = poisson(), data = d)  # IRR
library(survival)
coxph(Surv(time, disease) ~ exposed + age, data = d)                      # HR