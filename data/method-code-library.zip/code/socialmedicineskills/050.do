* 教学片段：需结合原技能前置步骤和研究数据；本轮未运行。
* Stata sem：观测题项均值入模（单指标路径模型）
sem (intention <- att sn pbc) (behavior <- intention pbc), standardized
estat gof, stats(all)