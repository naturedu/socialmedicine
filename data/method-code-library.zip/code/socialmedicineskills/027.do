* 教学片段：需结合原技能前置步骤和研究数据；本轮未运行。
* Stata：2SLS（核心命令）
ivregress 2sls y (t = z), first vce(robust)
estat firststage            // 一阶段 F，>10 为强工具变量
* 多工具变量：ivregress 2sls y (t = z1 z2), first，再用 estat overid 做过度识别检验