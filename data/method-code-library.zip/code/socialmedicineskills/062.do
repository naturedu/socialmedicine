* 教学片段：需结合原技能前置步骤和研究数据；本轮未运行。
* Stata：SSC 的 fuzzy 包做校准等（以 help fuzzy 为准）
ssc install fuzzy
fzcalc zy, low(60) cross(75) high(90)