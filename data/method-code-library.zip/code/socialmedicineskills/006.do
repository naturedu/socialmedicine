* 教学片段：需结合原技能前置步骤和研究数据；本轮未运行。
* ===== Stata =====
regress rate exposure [aweight = pop]           // 按地区人口加权
corr rate exposure
dstdize deaths pop, by(agegrp) using(stdpop)    // 直接标化；stdpop.dta 含 agegrp 与 pop

* ===== R =====
m <- lm(rate ~ exposure, data = d, weights = pop)
cor(d$rate, d$exposure)
library(epitools)
ageadjust.direct(count = d$deaths, pop = d$pop, stdpop = ref$stdpop)  # 直接标化