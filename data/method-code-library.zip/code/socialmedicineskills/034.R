# 教学片段：需结合原技能前置步骤和研究数据；本轮未运行。
library(fixest)
m <- feols(y ~ i(time, treat, ref = -1) | id + time, data = dat)
coefplot(m)                              // 事件研究图