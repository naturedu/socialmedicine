* 教学片段：需结合原技能前置步骤和研究数据；本轮未运行。
* Stata：三潜变量 SEM
sem (HL -> x1 x2 x3) (SE -> y1 y2 y3) (AD -> z1 z2 z3) (HL -> SE) (SE -> AD), method(mlmv)
estat gof