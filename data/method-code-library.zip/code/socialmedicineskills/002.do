* 教学片段：需结合原技能前置步骤和研究数据；本轮未运行。
* ===== Stata =====
tabulate exposed case, chi2
cci 40 20 30 70          // 病例暴露/非暴露=40/20，对照暴露/非暴露=30/70 → OR 与 CI
logistic case exposed age, or              // 不匹配：多因素校正 OR
clogit case exposed, group(pairid) or      // 1:1 匹配：条件 logistic

* ===== R =====
m <- matrix(c(40, 20, 30, 70), nrow = 2)   # 病例暴露/非暴露、对照暴露/非暴露
fisher.test(m)                             # 精确 OR 与 CI
glm(case ~ exposed + age, family = binomial(), data = d)   # 校正 OR
library(survival)
clogit(case ~ exposed + strata(pairid), data = d)          # 匹配条件 logistic