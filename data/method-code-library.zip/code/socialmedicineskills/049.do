* 教学片段：需结合原技能前置步骤和研究数据；本轮未运行。
* HBM 维度量表（Likert 1-5，各维度多题取均值）与预防行为模型
* perc_sus 感知易感性 | perc_sev 感知严重性 | perc_ben 感知收益 | perc_bar 感知障碍
* cue 行动线索(0/1) | selfeff 自我效能
logit vaccinate perc_sus perc_sev perc_ben perc_bar cue selfeff, or