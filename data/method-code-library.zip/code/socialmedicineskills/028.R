# 教学片段：需结合原技能前置步骤和研究数据；本轮未运行。
library(AER)
m_iv <- ivreg(y ~ t | z, data = dat)
summary(m_iv, diagnostics = TRUE)   # 含弱工具变量诊断