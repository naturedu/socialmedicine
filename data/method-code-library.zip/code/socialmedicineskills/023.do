* 教学片段：需结合原技能前置步骤和研究数据；本轮未运行。
ssc install conindex, replace
conindex y, rankvar(r)      // r：按经济状况排序的分数秩；选项以 help conindex 为准