# 教学片段：需结合原技能前置步骤和研究数据；本轮未运行。
nmb <- lambda * (e_new - e_cur) - (c_new - c_cur)
mean(nmb > 0)                  # NMB > 0 的比例 → CEAC 上阈值 λ 处的接受概率