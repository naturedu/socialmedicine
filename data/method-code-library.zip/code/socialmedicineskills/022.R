# 教学片段：需结合原技能前置步骤和研究数据；本轮未运行。
library(dplyr)
rw <- dat |> group_by(drg) |> summarise(rw = mean(fee) / mean(dat$fee))
dip_value <- fund_budget / sum(dat$dip_score * dat$n_cases)   # DIP 点值