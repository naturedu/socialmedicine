* 教学片段：需结合原技能前置步骤和研究数据；本轮未运行。
* ===== Stata =====
* Stata 无内置实现；可经 PyStata 调用 Python（sklearn/xgboost）
* ===== R =====
library(randomForest); library(xgboost); set.seed(2026)
rf <- randomForest(y ~ ., data = train, ntree = 500, importance = TRUE)   # 分类/回归自动识别
bst <- xgboost(data = xgb.DMatrix(as.matrix(train_x), label = train_y),
               nrounds = 100, eta = 0.1, max_depth = 3, objective = "binary:logistic")