# 教学片段：需结合原技能前置步骤和研究数据；本轮未运行。
dp <- Synth::dataprep(foo = dat, predictors = c("x1", "x2"), dependent = "y",
                      unit.variable = "id", time.variable = "time",
                      treatment.identifier = 1, controls.identifier = 2:20,
                      time.predictors.prior = 1990:1999, time.optimize.ssr = 1990:1999)
s1 <- Synth::synth(dp)