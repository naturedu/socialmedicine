* 教学片段：需结合原技能前置步骤和研究数据；本轮未运行。
* Stata：gsem 多层（医院随机截距）；语法细节以 help gsem 为准
gsem (HL -> x1 x2 x3) (SE -> y1 y2 y3) (SE <- HL M1[hospital]), vce(cluster hospital)
estat icc