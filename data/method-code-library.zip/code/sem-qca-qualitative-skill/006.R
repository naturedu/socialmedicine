# 教学片段：需结合原技能前置步骤和研究数据；本轮未运行。
library(lavaan)
set.seed(2026)
H <- 30; m <- 20; n <- H * m
d <- data.frame(hospital = rep(1:H, each = m))
d$ueff <- rnorm(H, 0, 0.5)[d$hospital]          # 医院随机效应
d$HL <- 0.4 * d$ueff + rnorm(n)
d$SE <- 0.5 * d$HL + 0.3 * d$ueff + rnorm(n)
d$x1 <- 0.7 * d$HL + rnorm(n, 0, 0.7); d$x2 <- 0.8 * d$HL + rnorm(n, 0, 0.6); d$x3 <- 0.75 * d$HL + rnorm(n, 0, 0.65)
d$y1 <- 0.7 * d$SE + rnorm(n, 0, 0.7); d$y2 <- 0.8 * d$SE + rnorm(n, 0, 0.6); d$y3 <- 0.75 * d$SE + rnorm(n, 0, 0.65)

model2 <- '
  level: 1
    HLw =~ x1 + x2 + x3
    SEw =~ y1 + y2 + y3
    SEw ~ HLw
  level: 2
    HLb =~ x1 + x2 + x3
    SEb =~ y1 + y2 + y3
    SEb ~ HLb
'
fit2 <- sem(model2, data = d, cluster = "hospital")
summary(fit2)