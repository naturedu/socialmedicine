# 教学片段：需结合原技能前置步骤和研究数据；本轮未运行。
library(lavaan)
set.seed(2026)
n <- 300
HL <- rnorm(n); SE <- 0.6 * HL + rnorm(n, 0, sqrt(1 - 0.36)); AD <- 0.5 * SE + rnorm(n, 0, sqrt(1 - 0.25))
d <- data.frame(
  x1 = 0.7 * HL + rnorm(n, 0, 0.7), x2 = 0.8 * HL + rnorm(n, 0, 0.6), x3 = 0.75 * HL + rnorm(n, 0, 0.65),
  y1 = 0.7 * SE + rnorm(n, 0, 0.7), y2 = 0.8 * SE + rnorm(n, 0, 0.6), y3 = 0.75 * SE + rnorm(n, 0, 0.65),
  z1 = 0.7 * AD + rnorm(n, 0, 0.7), z2 = 0.8 * AD + rnorm(n, 0, 0.6), z3 = 0.75 * AD + rnorm(n, 0, 0.65))

model <- '
  HL =~ x1 + x2 + x3
  SE =~ y1 + y2 + y3
  AD =~ z1 + z2 + z3
  SE ~ HL
  AD ~ SE
'
fit <- sem(model, data = d)
summary(fit, standardized = TRUE, fit.measures = TRUE)
fitMeasures(fit, c("chisq", "df", "cfi", "tli", "rmsea", "srmr"))