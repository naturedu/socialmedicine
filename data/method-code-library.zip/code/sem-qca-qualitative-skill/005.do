* 教学片段：需结合原技能前置步骤和研究数据；本轮未运行。
* Stata：等价写法（数据需先导入）
sem (HL -> x1 x2 x3) (SE -> y1 y2 y3) (AD -> z1 z2 z3) ///
    (SE <- HL) (AD <- SE), method(mlmv) standardized
estat gof, stats(all)