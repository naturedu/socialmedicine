# 教学片段：需结合原技能前置步骤和研究数据；本轮未运行。
# 接第 4 步
agg_dyn <- aggte(out, type = "dynamic", min_e = -3, max_e = 2)
summary(agg_dyn)                    # 事件研究系数表（含各期置信区间）
ggdid(agg_dyn)                      # 事件研究图（需 ggplot2）
ggdid(agg_dyn, ylim = c(-300, 60), xlab = "相对处理期",
      title = "动态处理效应：集采对次均药品费用")
# ggdid 的图形选项以 help(ggdid) 为准