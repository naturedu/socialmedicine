* 教学片段：需结合原技能前置步骤和研究数据；本轮未运行。
* 干预前基线平衡表（t=1 期）
tabstat y adm x1 x2 if t == 1, by(treated) stat(n mean sd)
* 各期结局均值图（第一道识别直觉：干预前两组路径应平行）
egen ybar = mean(y), by(treated t)
twoway (line ybar t if treated == 1) (line ybar t if treated == 0), ///
    legend(order(1 "处理组" 2 "对照组")) xline(2.5, lp(dash)) ///
    title("各期次均药品费用：处理组 vs 对照组（干预前应平行）")
drop ybar