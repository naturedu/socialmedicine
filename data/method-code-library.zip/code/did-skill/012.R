# 教学片段：需结合原技能前置步骤和研究数据；本轮未运行。
# Callaway-Sant'Anna（官方 R 实现）
library(did)
out <- att_gt(yname = "y", tname = "t", idname = "id", gname = "g",
              data = dat, control_group = "notyettreated")
summary(out)                            # ATT(g,t) 表：队列 g × 时期 t
agg_simple <- aggte(out, type = "simple")    # 总体 ATT ≈ -150
summary(agg_simple)
agg_group  <- aggte(out, type = "group")     # 按队列
agg_cal    <- aggte(out, type = "calendar")  # 按日历期
# 对照组设定、估计方法（est_method = "dr"/"reg"/"ipw"）等选项以 help(att_gt) 为准

# 替代：Sun & Abraham（fixest）
feols(y ~ sunab(g, t) | id + t, data = dat, cluster = ~id)