* 教学片段：需结合原技能前置步骤和研究数据；本轮未运行。
* ============================================================
* 模拟面板：60 地区 × 4 期；30 个处理组交错入组；真实 ATT = -150
* ============================================================
clear all
set seed 2026
set obs 60
gen id = _n
* 处理时点 g（0 = 永不受理）
gen g = 0
replace g = 2 if inrange(id, 1, 10)
replace g = 3 if inrange(id, 11, 20)
replace g = 4 if inrange(id, 21, 30)
gen treated = (g > 0)
* 地区特征（时不变）：固定效应、自身趋势、可观测协变量
gen alpha = rnormal(900, 50)        // 地区平均次均费用水平
gen beta  = rnormal(-8, 4)          // 地区自身趋势（元/期）
gen x1 = rnormal(0.3*treated, 1)    // 协变量 1：与入选相关
gen x2 = rnormal(0, 1)              // 协变量 2
* 4 期面板
expand 4
bysort id: gen t = _n
gen lambda = -30 * (t - 1)          // 共同时间趋势
gen D = (t >= g & g > 0)            // 处理指示
gen y   = alpha + beta*(t-1) + lambda + (-150)*D + rnormal(0, 40)           // 次均药品费用
gen adm = 0.20 - 0.01*(t-1) + (alpha-900)/3000 + (-0.02)*D + rnormal(0, 0.04)  // 住院率
xtset id t
save "did_demo.dta", replace
* 数据体检
xtdes                               // 面板结构：60 个地区 × 4 期、无缺失
tab g                               // 队列规模：g=2/3/4 各 10，g=0 共 30
tabstat y if t == 1, by(treated) stat(n mean sd)   // 干预前基线比较