# 教学片段：需结合原技能前置步骤和研究数据；本轮未运行。
# 结果表（fixest::etable 或 modelsummary）
etable(list(m_2x2, m_psm, m_adm), cluster = ~id, fitstat = ~n)
# library(modelsummary)
# modelsummary(list("2x2" = m_2x2, "PSM-DID" = m_psm, "住院率" = m_adm), stars = TRUE)