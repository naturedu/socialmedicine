# 教学片段：需结合原技能前置步骤和研究数据；本轮未运行。
library(fixest)
d2 <- subset(dat, t %in% 1:2)
d2$post <- as.integer(d2$t == 2)
d2$treated2 <- as.integer(d2$g == 2)

# 双向固定效应 DID：组/期主效应被 FE 吸收，交互项 = ATT
m_2x2 <- feols(y ~ treated2 * post | id + t, data = d2, cluster = ~id)
summary(m_2x2)                       # treated2:post ≈ -150

# 等价：不含 FE 的经典 2×2（两期时系数相同，方便逐项解释）
m_ols <- feols(y ~ treated2 * post, data = d2, cluster = ~id)
summary(m_ols)
# 系数：treated2 = 基线差异；post = 共同时间变化；treated2:post = ATT