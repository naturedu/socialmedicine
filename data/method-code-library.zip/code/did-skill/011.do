* 教学片段：需结合原技能前置步骤和研究数据；本轮未运行。
* Stata 18+：官方 csdid；Stata 17 及更早：ssc install csdid, replace + ssc install drdid, replace
* 全样本：30 个处理组在 t=2/3/4 交错入组（g=2/3/4），30 个永不受理（g=0）
csdid y, ivar(id) time(t) gvar(g)
* 聚合（官方 18：estat simple/event/group/calendar；SSC 版：csdid_estat simple ...）
estat simple                  // 总体 ATT ≈ -150
estat event                   // 事件时间聚合（供第 5 步作图）
estat group                   // 按队列聚合
* 选项（method、对照组选择、权重自举等）以 help csdid 为准

* 官方替代（Stata 18+）：xthdidregress，处理时点由 D 自动识别
xthdidregress ra (y) (D), group(id) time(t)
* 聚合与作图：estat aggregation / estat atetplot；语法以 help xthdidregress postestimation 为准