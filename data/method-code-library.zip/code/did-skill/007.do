* 教学片段：需结合原技能前置步骤和研究数据；本轮未运行。
* 两期子样本：t=1 干预前、t=2 干预后；处理组 = t=2 期入组队列
preserve
keep if inlist(t, 1, 2)
gen post = (t == 2)
gen treated2 = (g == 2)                // 10 个处理组；g=3/4 在 t<=2 尚未处理，作为对照
* 经典 2×2（OLS + 交互项）
reg y i.treated2##i.post, vce(cluster id)
est store m_2x2
* 系数解释：1.treated2 = 基线差异；1.post = 共同时间变化；
*           1.treated2#1.post = ATT ≈ -150（集采使次均药品费用下降约 150 元）

* 等价：双向固定效应（系数相同）
reg y i.treated2#i.post i.id i.t, vce(cluster id)

* 官方命令（Stata 17+）：didregress（自动 FE 与 ATET 报告）
didregress (y) (treated2), group(id) time(t) vce(cluster id)
* 注：didregress 假设处理组单一入组时点；交错处理请用第 4 步的 csdid
restore