* 教学片段：需结合原技能前置步骤和研究数据；本轮未运行。
* 事件研究（手工交互虚拟变量，基准 = 干预前一期 rel = -1）
preserve
keep if inlist(g, 0, 3)
gen treated3 = (g == 3)
gen rel = t - 3                         // rel = -2,-1,0,1
gen ev_m2 = (rel == -2 & treated3 == 1)
gen ev_m1 = (rel == -1 & treated3 == 1) // 基准（回归中省略）
gen ev_0  = (rel ==  0 & treated3 == 1)
gen ev_1  = (rel ==  1 & treated3 == 1)
reghdfe y ev_m2 ev_0 ev_1, absorb(id t) vce(cluster id)
test ev_m2 = 0                          // 正式检验：干预前系数 = 0
coefplot, keep(ev_*) vertical yline(0, lcolor(red)) xline(1.5, lcolor(gs8) lp(dash))
* 图：ev_m2（干预前）应 ≈ 0；ev_0、ev_1（干预后）应 ≈ -150
* 注：本例受 4 期数据限制只有 1 个前趋势系数；真实研究应有 3 期以上干预前数据，
*     并联合检验全部前趋势系数（test ev_m2 ev_m3 ... = 0）

* 官方替代（Stata 17+）：didregress + 预趋势检验
didregress (y) (treated3), group(id) time(t) vce(cluster id)
estat trendplots                        // 各期处理-对照差异图（含置信区间）
estat ptrends                           // 平行趋势联合检验（H0：干预前各期系数均为 0）
restore