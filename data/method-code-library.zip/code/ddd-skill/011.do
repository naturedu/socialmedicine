* 教学片段：需结合原技能前置步骤和研究数据；本轮未运行。
* ---------- 动态检验思路（示意，需多期数据；本模拟两期无法执行） ----------
* 假设 time = -2..2，政策时点 = 0，基准期 = -1：
* reghdfe y ib(-1).time##i.treated##i.group, absorb(id) vce(cluster id)
* 关注各期 1.time#1.treated#1.group 系数（政策前应 ≈ 0）
* 画图：ssc install coefplot; coefplot, keep(*.time#1.treated#1.group) vertical yline(0)
* 具体 keep 匹配规则以 help coefplot 为准

* ---------- 安慰剂 1：伪第三维度（Stata permute，200 次） ----------
* 随机置换 group，破坏品种维度结构；真实 δ = -8 应落在置换分布左尾之外
permute group delta = _b[1.treated#1.post#1.group], ///
        reps(200) seed(2026): reg y i.treated##i.post##i.group, vce(cluster id)

* ---------- 安慰剂 2：伪时点（示意，需 time = 0..3 的多期数据） ----------
* gen post_fake = (time == 1)        // 把政策提前到 t=1，只用真政策前数据
* reg y i.treated##i.post_fake##i.group if time < 2, vce(cluster id)  // 期望 δ ≈ 0

* ---------- 替换结局 ----------
reghdfe y_qty i.treated##i.post##i.group, absorb(id time) vce(cluster id)  // 相关结局：期望 δ ≈ -3
reghdfe y_dev i.treated##i.post##i.group, absorb(id time) vce(cluster id)  // 安慰剂结局：期望 δ ≈ 0

* ---------- 聚类层级敏感性：多向聚类（reghdfe 支持） ----------
reghdfe y i.treated##i.post##i.group, absorb(id time) vce(cluster id time)