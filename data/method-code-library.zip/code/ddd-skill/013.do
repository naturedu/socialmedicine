* 教学片段：需结合原技能前置步骤和研究数据；本轮未运行。
* 主回归表：逐步（仅主效应 → +两两交互 → +三重交互）
reg y i.treated i.post i.group, vce(cluster id)
est store m1
reg y i.treated i.post i.group i.treated#i.post i.treated#i.group i.post#i.group, vce(cluster id)
est store m2
reg y i.treated##i.post##i.group, vce(cluster id)
est store m3
estimates table m1 m2 m3, b(%9.2f) se stats(N)
* 报告时另附 95% CI（reg 输出自带）与聚类数（60 家医院）