* 教学片段：需结合原技能前置步骤和研究数据；本轮未运行。
* ---------- 模型 A：pooled OLS + 医院聚类稳健标准误 ----------
reg y i.treated##i.post##i.group, vce(cluster id)
est store ddd_ols

* ---------- 模型 B：医院 + 时间固定效应（reghdfe） ----------
reghdfe y i.treated##i.post##i.group, absorb(id time) vce(cluster id)
est store ddd_fe
* 说明：treated、post 主效应被吸收（与 id / time 固定效应共线，输出中标注）；
*       两两交互与三重交互仍可估，δ 与模型 A 相同