* 教学片段：需结合原技能前置步骤和研究数据；本轮未运行。
* ============ 第 0 步：模拟面板数据（贯穿全流程） ============
clear all
set seed 2026

* 60 家医院：id 1-30 公立（treated = 1），31-60 民营（treated = 0）
set obs 60
gen id = _n
gen treated = (id <= 30)          // 处理维度：1 = 公立医院（受集采约束）
gen u_i = rnormal(0, 4)           // 医院层面随机效应（制造院内相关，聚类依据）

* 每家医院 2 类药品：group = 1 集采品种，0 非集采品种
expand 2
bysort id: gen group = _n - 1

* 每个（医院 × 品种）2 期：post = 0 政策前，1 政策后
expand 2
bysort id group: gen post = _n - 1
gen time = post                   // 供 reghdfe absorb() 使用

* ---------- 真实数据生成过程（DGP，内置真实 DDD 效应 δ = -8） ----------
* y = γ0 + γ1·treated + γ2·post + γ3·group
*     + γ12·treated×post + γ13·treated×group + γ23·post×group
*     + δ·treated×post×group + u_i + ε
local g0 100                        // 基组均值（民营 × 非集采 × 政策前）
local g1 10                         // 公立医院整体费用水平更高
local g2 -5                         // 全体时间趋势（普遍控费）
local g3 20                         // 集采品种用量大、费用更高
local g12 -6                        // 偏误 1：公立医院特有趋势（DRG / 取消加成等）
local g13 5                         // 公立医院对集采品种的固定偏好
local g23 -4                        // 偏误 2：集采品种特有趋势（专利到期等）
local delta -8                      // 真实 DDD 效应：集采使公立医院集采品种额外下降 8 万元/月

gen y = `g0' + `g1'*treated + `g2'*post + `g3'*group + ///
        `g12'*treated*post + `g13'*treated*group + `g23'*post*group + ///
        `delta'*treated*post*group + u_i + rnormal(0, 2)

* ---------- 稳健性结局（第 4 步用） ----------
* y_qty：集采品种采购数量（相关结局，真实效应较小 δ = -3）
gen y_qty = 60 + 8*treated - 4*post + 18*group - 3*treated*post + ///
            4*treated*group - 2*post*group - 3*treated*post*group + ///
            u_i + rnormal(0, 3)
* y_dev：与药品无关的耗材费用（安慰剂结局，真实 δ = 0）
gen y_dev = 40 + 5*treated - 2*post + 2*group + 1*treated*post - ///
            1*treated*group + 0.5*post*group + 0*treated*post*group + ///
            0.5*u_i + rnormal(0, 5)

* 数据体检：8 组均值表（Stata 17+；16 及更早用 bysort treated post group: summarize y）
table treated post group, stat(mean y) stat(sd y) nototals
* 期望组均值（噪声平均掉后）：民营 非集采 前 100 / 后 95；民营 集采 前 120 / 后 111；
*                             公立 非集采 前 110 / 后 99；公立 集采 前 135 / 后 112