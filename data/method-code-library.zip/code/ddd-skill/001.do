* 教学片段：需结合原技能前置步骤和研究数据；本轮未运行。
* Stata（联网安装一次）
ssc install reghdfe, replace
* 若 ftools 未被自动装上：ssc install ftools, replace