* 教学片段：需结合原技能前置步骤和研究数据；本轮未运行。
* 图形直觉：四组均值线（先平均到 8 个单元格）
preserve
collapse (mean) y, by(treated post group)
twoway (connected y post if treated==1 & group==1, sort) ///
       (connected y post if treated==1 & group==0, sort) ///
       (connected y post if treated==0 & group==1, sort) ///
       (connected y post if treated==0 & group==0, sort), ///
       legend(order(1 "公立·集采" 2 "公立·非集采" 3 "民营·集采" 4 "民营·非集采")) ///
       xtitle("post（0 政策前 / 1 政策后）") ytitle("月均药品费用（万元）")
restore