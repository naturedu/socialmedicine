* 教学片段：需结合原技能前置步骤和研究数据；本轮未运行。
* ---------- 3.1 两个 2×2 DID（品种类型 DID，在公立/民营切片上） ----------
reg y i.post##i.group if treated == 1, vce(cluster id)
local did1 = _b[1.post#1.group]          // 期望 ≈ -12（= γ23 + δ）
reg y i.post##i.group if treated == 0, vce(cluster id)
local did2 = _b[1.post#1.group]          // 期望 ≈ -4（= γ23）

* ---------- 3.2 分解：DDD = DID1 - DID2 ----------
display "DID1(品种|公立) = " %5.2f `did1'
display "DID2(品种|民营) = " %5.2f `did2'
display "DDD = DID1 - DID2 = " %5.2f (`did1' - `did2')

* ---------- 3.3 镜像分解（医院类型 DID，在集采/非集采切片上） ----------
reg y i.treated##i.post if group == 1, vce(cluster id)
local did1b = _b[1.treated#1.post]       // 期望 ≈ -14（= γ12 + δ）
reg y i.treated##i.post if group == 0, vce(cluster id)
local did2b = _b[1.treated#1.post]       // 期望 ≈ -6（= γ12）
display "镜像分解：DID(医院|集采) - DID(医院|非集采) = " %5.2f (`did1b' - `did2b')

* ---------- 3.4 与主回归三重交互系数对照（期望 ≈ -8） ----------
reg y i.treated##i.post##i.group, vce(cluster id)
display "主回归三重交互系数 δ = " %5.2f _b[1.treated#1.post#1.group]