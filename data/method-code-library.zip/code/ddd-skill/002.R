# 教学片段：需结合原技能前置步骤和研究数据；本轮未运行。
# R
install.packages("fixest")