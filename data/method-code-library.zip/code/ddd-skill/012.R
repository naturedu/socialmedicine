# 教学片段：需结合原技能前置步骤和研究数据；本轮未运行。
# ---------- 安慰剂 1（R 版）：伪第三维度，医院内随机交换品种标签，200 次 ----------
set.seed(2026)
perm_delta <- replicate(200, {
  d <- dat
  d$group_p <- ave(d$group, d$id, FUN = sample)      # 每家医院内部重排，保留医院结构
  coef(feols(y ~ treated*post*group_p | id + time, data = d))["treated:post:group_p"]
})
hist(perm_delta, main = "伪第三维度：δ 的置换分布（200 次）")
abline(v = -8, col = "red", lwd = 2)                 # 真实 δ = -8 应落在左尾之外
mean(perm_delta <= -8)                               # 置换单侧 p 值（期望接近 0）

# ---------- 替换结局 ----------
coef(feols(y_qty ~ treated*post*group | id + time, cluster = ~id, data = dat))["treated:post:group"]  # 期望 ≈ -3
coef(feols(y_dev ~ treated*post*group | id + time, cluster = ~id, data = dat))["treated:post:group"]  # 期望 ≈ 0

# 伪时点（示意，需 ≥3 期数据）：把政策时点前移后用真政策前数据估计 δ，期望 ≈ 0；
# 写法同上，仅替换 post 变量与子样本（以 fixest 帮助文档为准）