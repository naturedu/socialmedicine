# 教学片段：需结合原技能前置步骤和研究数据；本轮未运行。
# 教学模拟；参数不来自真实疾病，禁止直接作临床或政策结论
set.seed(2026)
N <- 10000; T <- 20
state <- rep(1L, N) # 1健康、2患病、3死亡
age <- runif(N, 40, 60); qaly <- numeric(N)
for (t in seq_len(T)) {
  old <- state
  pdeath <- pmin(0.20, 0.005 * exp(0.06 * (age + t - 40)))
  for (s in 1:2) {
    ids <- which(old == s); u <- runif(length(ids))
    pd <- pdeath[ids] * ifelse(s == 2, 1.5, 1)
    psick <- if (s == 1) 0.03 else 0
    stopifnot(all(pd + psick <= 1))
    state[ids[u < pd]] <- 3L
    state[ids[u >= pd & u < pd + psick]] <- 2L
  }
  # 半周期近似；贴现率仅为教学输入，实际需依据指南
  utility <- c(1, 0.7, 0)
  qaly <- qaly + (utility[old] + utility[state])/2 / 1.03^(t-0.5)
}
print(table(state)); print(mean(qaly))
# 政策比较需共同随机数、多次重复、参数与一阶不确定性分开评估