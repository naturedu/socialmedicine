# 教学片段：需结合原技能前置步骤和研究数据；本轮未运行。
# R：一键提取汇总表关键数字（meta 包）
with(m.or, c(Q = Q, df.Q = df.Q, p.Q = pval.Q, I2_pct = I2*100,
             tau2 = tau2, tau = tau, OR_rand = exp(TE.random),
             lo_rand = exp(lower.random), hi_rand = exp(upper.random),
             p_rand = pval.random))
m.or$w.random                            // 各研究随机效应权重（%）