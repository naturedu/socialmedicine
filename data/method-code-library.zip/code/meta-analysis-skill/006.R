# 教学片段：需结合原技能前置步骤和研究数据；本轮未运行。
# R：手工计算（与 Stata 公式一致）
dat$a <- dat$et; dat$b <- dat$nt - dat$et
dat$c <- dat$ec; dat$d <- dat$nc - dat$ec
dat$lnOR   <- with(dat, log((a*d)/(b*c)))
dat$selnOR <- with(dat, sqrt(1/a + 1/b + 1/c + 1/d))
dat$MD   <- dat$m_t - dat$m_c
dat$seMD <- with(dat, sqrt(sd_t^2/nt + sd_c^2/nc))
sp <- with(dat, sqrt(((nt-1)*sd_t^2 + (nc-1)*sd_c^2)/(nt+nc-2)))
J  <- with(dat, 1 - 3/(4*(nt+nc) - 9))
dat$g   <- dat$MD/sp*J
dat$seg <- with(dat, sqrt((nt+nc)/(nt*nc) + g^2/(2*(nt+nc))))

# R：metafor::escalc（由原始数据直接计算，推荐；结果 yi/vi 与手工一致）
library(metafor)
dat.or  <- escalc(measure = "OR",  ai = et, n1i = nt, ci = ec, n2i = nc,
                  data = dat, slab = study)
dat.rr  <- escalc(measure = "RR",  ai = et, n1i = nt, ci = ec, n2i = nc,
                  data = dat, slab = study)
dat.md  <- escalc(measure = "MD",  m1i = m_t, sd1i = sd_t, n1i = nt,
                  m2i = m_c, sd2i = sd_c, n2i = nc, data = dat, slab = study)
dat.smd <- escalc(measure = "SMD", m1i = m_t, sd1i = sd_t, n1i = nt,
                  m2i = m_c, sd2i = sd_c, n2i = nc, data = dat, slab = study)
# 注：escalc 的 "SMD" 默认即 Hedges' g（含小样本校正）；参数名以 ?escalc 为准