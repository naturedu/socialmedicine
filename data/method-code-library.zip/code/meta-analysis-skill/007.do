* 教学片段：需结合原技能前置步骤和研究数据；本轮未运行。
* ---- 官方 meta 命令族（Stata 16+；fixed 为 common 的兼容旧称）----
meta set lnOR selnOR, studylabel(study) esize(OR)
meta summarize, fixed random                 // Q、I²、tau² + 合并估计
meta esize, fixed random(dlaird)             // 合并估计；REML 用 random(reml)
meta esize, random(reml)                     // 方法子选项以 help meta esize 为准

* ---- SSC metan（经典）----
* 二分类四变量顺序 = 试验组事件 试验组总数 对照组事件 对照组总数（不是四格表 a b c d！）
metan et nt ec nc, or fixed random label(namevar=study, yearvar=year) sortby(year)

* 连续六变量 = n1 mean1 sd1 n2 mean2 sd2；md 或 hedges（选项以 help metan 为准）
metan nt m_t sd_t nc m_c sd_c, md fixed random label(namevar=study, yearvar=year)
metan nt m_t sd_t nc m_c sd_c, hedges fixed random label(namevar=study, yearvar=year)