* 教学片段：需结合原技能前置步骤和研究数据；本轮未运行。
* 官方
meta forestplot, esrefline(1) fixed random          // OR 无效线 = 1
* 连续结局：先 meta set g seg, studylabel(study) esize(hedgesg)，无效线 = 0
meta forestplot, esrefline(0) random
graph export forest_or.png, replace width(2000)     // 导出高清图

* metan 自带森林图（lcols/rcols 控制列；favours 以 # 分隔左右文字）
metan et nt ec nc, or random label(namevar=study, yearvar=year) sortby(year) ///
    forestplot(lcols(study year) rcols(OR loOR hiOR) favours(慢病管理降低住院 # 常规照护降低住院))