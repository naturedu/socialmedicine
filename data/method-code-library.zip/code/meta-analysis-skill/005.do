* 教学片段：需结合原技能前置步骤和研究数据；本轮未运行。
* ---- 手工计算（先核对，再交给批量命令）----
gen a = et                      // 试验组事件
gen b = nt - et                 // 试验组非事件
gen c = ec                      // 对照组事件
gen d = nc - ec                 // 对照组非事件
gen lnOR   = ln((a*d)/(b*c))
gen selnOR = sqrt(1/a + 1/b + 1/c + 1/d)
gen OR     = exp(lnOR)
gen loOR   = exp(lnOR - 1.96*selnOR)
gen hiOR   = exp(lnOR + 1.96*selnOR)
gen lnRR   = ln((a/nt)/(c/nc))
gen selnRR = sqrt(1/a - 1/nt + 1/c - 1/nc)
* 零单元处理：a b c d 各 +0.5 后按上式重算（或 metan ..., peto）

* ---- 连续：MD 与 Hedges' g ----
gen MD    = m_t - m_c
gen seMD  = sqrt(sd_t^2/nt + sd_c^2/nc)
gen sp    = sqrt(((nt-1)*sd_t^2 + (nc-1)*sd_c^2)/(nt+nc-2))
gen J     = 1 - 3/(4*(nt+nc) - 9)
gen g     = MD/sp*J
gen seg   = sqrt((nt+nc)/(nt*nc) + g^2/(2*(nt+nc)))
list study year OR loOR hiOR MD seMD g seg

* 单研究核对：esize 逐条 immediate 形式（语法以 help esize 为准）
esize twosample 150 -1.0 0.7 150 -0.3 0.8, hedgesg