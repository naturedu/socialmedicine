# 教学片段：需结合原技能前置步骤和研究数据；本轮未运行。
# R：meta 包
forest(m.or, sortvar = year, leftcols = c("studlab", "year"),
       rightcols = c("effect", "ci"), test.overall = TRUE)

# R：metafor（atransf = exp 把对数尺度还原为 OR；refline = 1 为无效线）
res <- rma(yi, vi, data = dat.or, method = "REML")
forest(res, slab = dat.or$study, atransf = exp, refline = 1,
       xlab = "OR（对数尺度）")