* 教学微模拟；虚构参数，年度周期
clear
set seed 2026
set obs 10000
gen id = _n
gen age = 40 + 20*runiform()
gen state = 1
gen qaly = 0
forvalues t = 1/20 {
  gen old = state
  gen pd = min(.20, .005*exp(.06*(age+`t'-40)))
  replace pd = 1.5*pd if old==2
  gen u = runiform()
  replace state = 3 if old<3 & u<pd
  replace state = 2 if old==1 & u>=pd & u<pd+.03
  gen u0 = cond(old==1,1,cond(old==2,.7,0))
  gen u1 = cond(state==1,1,cond(state==2,.7,0))
  replace qaly = qaly + (u0+u1)/2/1.03^(`t'-.5)
  drop old pd u u0 u1
}
tab state
summarize qaly