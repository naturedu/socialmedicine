* id time y group；先检查时间尺度与重复记录
isid id time
xtset id time
mixed y c.time##i.group || id: time, covariance(unstructured)
margins group, at(time=(0 1 2 3))
marginsplot
* 非正态结局可考虑GEE：xtgee y c.time##i.group, family(binomial) link(logit) corr(exchangeable) vce(robust)