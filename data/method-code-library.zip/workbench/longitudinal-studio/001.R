# 依赖 lme4 / ggplot2；df包含id time y group
library(lme4); library(ggplot2)
fit <- lmer(y ~ time * group + (1 + time | id), data=df)
summary(fit)
ggplot(df, aes(time,y,group=id,colour=factor(group))) +
 geom_line(alpha=.10) +
 stat_summary(aes(group=group),fun=mean,geom="line",linewidth=1.2) +
 theme_classic()
# 检查非线性、缺失机制及随机效应结构；均值轨迹不等同潜在类别