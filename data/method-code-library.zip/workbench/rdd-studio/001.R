# 依赖 rdrobust / rddensity；df 包含 y、running
library(rdrobust)
library(rddensity)
cutoff <- 0 # 替换为真实制度阈值
fit <- rdrobust(y=df$y, x=df$running, c=cutoff, p=1)
summary(fit)
summary(rddensity(X=df$running, c=cutoff))
rdplot(y=df$y, x=df$running, c=cutoff)
# 模糊断点需另传 fuzzy=df$treatment；不得用高阶全局多项式代替局部识别