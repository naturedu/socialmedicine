* 依赖：ssc install rdrobust / rddensity（自行确认安装）
* 数据含 y running；阈值 0 仅为模板
rdrobust y running, c(0) p(1)
rddensity running, c(0)
rdplot y running, c(0)
* 模糊断点：rdrobust y running, c(0) fuzzy(treatment)