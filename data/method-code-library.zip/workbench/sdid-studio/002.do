* 依赖 sdid；balanced panel，treated为实际受处理的单位-时间状态
sdid outcome unit time treated, vce(placebo) seed(2026)
* 检查对照池、处理前拟合、同期冲击和推断方法有效性