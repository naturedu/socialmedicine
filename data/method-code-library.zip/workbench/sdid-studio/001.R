# 依赖 synthdid；df: unit,time,outcome,treated（处理后为1）
library(synthdid)
pm <- panel.matrices(df, unit="unit", time="time",
                     outcome="outcome", treatment="treated")
tau <- synthdid_estimate(pm$Y, pm$N0, pm$T0)
print(tau); plot(tau)
se <- sqrt(vcov(tau, method="placebo"))
print(se)
# 此模板针对包支持的块状处理，不能直接套用任意交错实施