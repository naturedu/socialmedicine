* ===== Stata =====
power twomeans 100 110, sd(20) power(0.8)    // 两组均数 100 vs 110、SD 20 → 每组 n
power twomeans 100 110, sd(20) n(64)         // 固定每组 n=64 → 检验效能
power twoproportions 0.30 0.20, power(0.8)   // 两率 0.30 vs 0.20 → 每组 n
power oneproportion 0.20 0.25                // 单组率 0.20 对目标 0.25
power twomeans 100 110, sd(20) power(0.8) nratio(2)   // 组间比 1:2 设计
* ===== R =====
library(pwr)
pwr.t.test(d = 0.5, sig.level = 0.05, power = 0.8, type = "two.sample")  // 每组 n
pwr.t.test(d = 0.5, sig.level = 0.05, n = 64, type = "two.sample")       // 固定 n → 效能
pwr.2p.test(h = ES.h(0.3, 0.2), sig.level = 0.05, power = 0.8)           // 两率
pwr.anova.test(k = 3, f = 0.25, sig.level = 0.05, power = 0.8)           // 多组方差分析
pwr.chisq.test(w = 0.1, df = 1, sig.level = 0.05, power = 0.8)           // 卡方检验