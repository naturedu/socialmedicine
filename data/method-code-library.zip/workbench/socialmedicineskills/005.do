* ===== Stata =====
gen did = treat * post
regress y treat post did, vce(cluster id)        // did 系数即 DID 估计
xtset id time
xtreg y ib0.time#i.treat i.time, fe vce(cluster id)   // 事件研究：检验平行趋势
gen time_after = max(0, time - t0)               // ITS 分段回归（t0 = 干预时点）
newey y time post time_after, lag(1)             // Newey-West 处理自相关

* ===== R =====
m <- lm(y ~ treat * post, data = d)              # 交互项系数即 DID
library(sandwich); library(lmtest)
coeftest(m, vcov = vcovCL(m, cluster = ~id))     # 聚类稳健标准误
d$time_after <- pmax(0, d$time - t0)
its <- lm(y ~ time + post + time_after, data = d)   # ITS 分段回归