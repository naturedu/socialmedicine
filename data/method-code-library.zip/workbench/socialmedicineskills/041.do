* ===== Stata =====
mi set mlong                                  // 声明多重插补 long 格式
mi register imputed y x                       // 登记含缺失的待插补变量
mi impute chained (regress) y (logit) x = z age, add(20) rseed(2026)
                                              // y 连续用 regress、x 二分类用 logit；z age 为完整辅助变量
mi estimate: regress y x age                  // 逐集估计 + Rubin 规则合并
* ===== R =====
library(mice)
imp <- mice(data, m = 20, seed = 2026)        # 链式方程多重插补
densityplot(imp)                              # 检查插补值分布
fit <- with(imp, glm(y ~ x + age, family = binomial()))   # 逐集估计
pool(fit)                                     # Rubin 规则合并