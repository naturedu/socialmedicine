* ===== Stata =====
lasso linear y x1-x200, selection(cv) nolog    // 连续结局，CV 选 λ
lasso logit y x1-x200, selection(cv)           // 二分类结局
* ===== R =====
cvfit <- glmnet::cv.glmnet(x, y, family = "binomial", alpha = 0.5)   // 弹性网
coef(cvfit, s = "lambda.1se")                  // 1-SE λ 的系数