* ===== Stata =====
bayes, mcmcsize(10000) rseed(2026): regress y x   // 默认弱信息先验的贝叶斯回归
bayesgraph diagnostics {y:x}                      // 轨迹/自相关/R-hat 收敛诊断
bayesstats ess                                   // 有效样本量
bayesstats summary, credible                     // 后验均值与 95% 可信区间
bayes, prior({y:x}, normal(0, 10)) rseed(2026): regress y x   // 自定义先验 → 敏感性分析
* ===== R =====
library(brms)
fit <- brm(y ~ x, data = d, chains = 4, iter = 2000, warmup = 1000, seed = 2026)
summary(fit)                                 # 后验均值、95% CI、R-hat、ESS
plot(fit)                                    # 链轨迹与后验密度
hypothesis(fit, "x > 0")                     # 后验概率 P(x > 0)