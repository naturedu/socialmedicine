* ===== Stata =====
cluster kmeans x1 x2, k(3) start(krandom(2026)) name(k3)   // K-means（x1 x2 宜先标准化）
cluster stop, rule(duda)                      // 肘部指标辅助选 K（Duda-Hart）
cluster wardslinkage x1 x2, name(hc)          // 层次聚类（Ward 法）
cluster dendrogram hc, labels(id)             // 树状图
cluster generate g = groups(k3)               // 保存 K-means 分组结果
* ===== R =====
set.seed(2026); km <- kmeans(scale(x), centers = 3, nstart = 25)   # K-means（scale 标准化）
d <- dist(scale(x)); hc <- hclust(d, method = "ward.D2")           # 层次聚类（Ward 法）
plot(hc); table(cutree(hc, k = 3), km$cluster)                     # 树状图；两法结果交叉
library(cluster)
mean(silhouette(km$cluster, dist(scale(x)))[, 3])                  # 平均轮廓系数（选 K）