* ===== Stata =====
set obs 120
set seed 2026
egen block = seq(), to(30) block(4)       // 30 个区组、组内 4 人
gen treat = rbinomial(1, 0.5)             // 简单随机（严格 2:2 区组需再抽样）
tab treat
csi 20 10 25 5                            // 干预组事件/非事件=20/10，对照组=25/5 → RD、RR 及 CI；NNT=1/RD
ttest y, by(treat)                        // 连续结局：MD
regress y treat, vce(robust)

* ===== R =====
set.seed(2026)
d$treat <- sample(rep(0:1, 60))           # 120 人简单随机（可用 blockrand 做区组）
library(epiR)
epi.2by2(table(d$treat, d$outcome), method = "cohort.count")   # RR/RD/NNT
t.test(y ~ treat, data = d)
lm(y ~ treat, data = d)