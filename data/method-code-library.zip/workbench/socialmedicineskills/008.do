* ===== Stata =====
egen mean_score = mean(score), by(item)
egen sd_score = sd(score), by(item)
gen cv = sd_score / mean_score
list item mean_score cv if mean_score >= 3.5 & cv <= 0.25   // 示例筛选阈值
ssc install concord
concord score1-score15                       // 各专家评分变量 → 肯德尔 W

* ===== R =====
library(dplyr)
d |> group_by(item) |>
  summarise(m = mean(score), cv = sd(score)/mean(score)) |>
  filter(m >= 3.5 & cv <= 0.25)              # 示例筛选阈值
library(irr)
w <- kendall(t(as.matrix(xtabs(score ~ expert + item, data = d))))   # 行为条目、列为专家
w$value                                      # 肯德尔和谐系数 W