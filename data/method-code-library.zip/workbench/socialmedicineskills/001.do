* ===== Stata =====
proportion disease                       // 患病率及 CI（默认 Wald）
ci proportions disease, wilson           // Wilson CI，小样本更稳
glm disease exposed, family(binomial) link(log) eform   // PR；不收敛时换 poisson disease exposed, irr vce(robust)

* ===== R =====
x <- 45; n <- 300                        # 患病人数与调查人数
prop.test(x, n, correct = FALSE)         # 患病率及近似 CI
binom.test(x, n)                         # 精确 Clopper-Pearson CI
m <- glm(disease ~ exposed, family = binomial(link = "log"), data = d)
exp(cbind(PR = coef(m), confint.default(m)))   # 患病率比 PR