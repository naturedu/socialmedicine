library(survival)
# event: 1事件 0删失；df为研究者数据
fit <- coxph(Surv(time,event) ~ exposure + age, data=df)
summary(fit); cox.zph(fit)
plot(survfit(Surv(time,event) ~ exposure,data=df))
# 竞争事件用累积发生函数/适当竞争风险模型，不将1-KM当作累积发生率