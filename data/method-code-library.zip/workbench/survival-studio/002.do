stset time, failure(event==1)
sts graph, by(exposure)
stcox exposure age
estat phtest, detail
* 若 event==2 为竞争事件，明确目标后考虑：
* stcrreg exposure age, compete(event==2)