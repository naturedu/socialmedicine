# df包含二元y、exposure、age
fit <- glm(y ~ exposure + age, family=binomial(), data=df)
summary(fit)
exp(cbind(OR=coef(fit), confint(fit)))
df0 <- transform(df,exposure=0); df1 <- transform(df,exposure=1)
mean(predict(fit,df1,type="response")-predict(fit,df0,type="response"))
# 上式为模型标准化差异，因果解释需额外识别假设；区间另用适当bootstrap