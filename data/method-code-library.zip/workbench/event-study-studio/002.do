* 需 csdid 与 drdid；g=首次处理年份，未处理为0
csdid y, ivar(id) time(year) gvar(g) notyet method(dripw)
estat event
csdid_plot
* 聚类层级、控制组与协变量需按具体政策分配结构设置