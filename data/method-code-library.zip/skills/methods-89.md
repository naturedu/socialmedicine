---
name: socialmedicineskills
description: 社医卫管方法学手册：89种方法、10大类，含研究设计、计量模型、因果推断、证据综合、模拟和AI评价。按逻辑框架选择与解释方法。
---

# Skill：socialmedicineskills —— 社医卫管方法学速查手册（89 条）

**版本** 1.0 · **作者** 杜思娴 (Du Sixian) · **许可** MIT · **更新** 2026-10-23

## 用途

面向社会医学与卫生事业管理 / 卫生经济学研究者的一份**方法学速查手册**：89 个常用方法，每个方法给出「适用 / 要点 / Stata 与 R 核心代码 / 报告要点 / 常见错误」。适合选题阶段选方法、写方法学部分时查口径、上课与组会速查。**深度教程**见本目录配套专题 Skill（DCE、Markov、卫生经济学教程、机器学习、DID、ITS、DDD、Meta、定性方法与结构方程专题）。

## 如何使用

- 按「类目 + 编号」定位（如 B5 = 二元 logistic 回归）；类目：A 研究设计、B 统计与计量、C 卫生经济、D 因果推断、E 数据科学、F 理论与实施、G 定性/SEM、H 证据综合、I 模拟决策、J 政策文本与AI评价。
- 代码为**教学示例或核心接口**，实际运行需要相应数据、依赖及版本核对；标注「ssc install」的 Stata 第三方命令与 R 包需先安装。
- 所有命令请以 `help` / 帮助文档为准；本手册的数值仅作演示。

## A 类：研究设计与偏倚控制（9个方法）

> 方法学速查手册 A 类条目片段（A1–A8）。每个方法按「适用 / 要点 / 代码（Stata + R）/ 报告要点 / 常见错误」展开；代码为可运行核心命令，示例数据与阈值仅作演示。

### A1 横断面研究

**适用**：在某一时点同时测量暴露与结局，描述疾病分布或探索暴露-结局关联（如国家卫生服务调查、体检数据、居民健康素养调查）。

**要点**：核心是一次性调查，暴露与结局同时收集、无时间先后，只能得关联不能定因果。患病率 = 现患病例数 / 调查人口数（时点患病率）；关联指标推荐患病率比 PR（log-binomial）或暴露患病比值比 POR，结局常见时 OR 会高估关联。抽样常为多阶段/分层抽样，需加权估计总体；典型偏倚有奈曼偏倚（病程长短影响入选，长病程者过度代表）、无应答偏倚与回忆偏倚。

**代码**：

```stata
* ===== Stata =====
proportion disease                       // 患病率及 CI（默认 Wald）
ci proportions disease, wilson           // Wilson CI，小样本更稳
glm disease exposed, family(binomial) link(log) eform   // PR；不收敛时换 poisson disease exposed, irr vce(robust)

* ===== R =====
x <- 45; n <- 300                        # 患病人数与调查人数
prop.test(x, n, correct = FALSE)         # 患病率及近似 CI
binom.test(x, n)                         # 精确 Clopper-Pearson CI
m <- glm(disease ~ exposed, family = binomial(link = "log"), data = d)
exp(cbind(PR = coef(m), confint.default(m)))   # 患病率比 PR
```

**报告要点**：报告调查时点、抽样设计与加权方法；患病率须附 95% CI（注明方法），关联指标用 PR/POR 并说明为何不选 OR。

**常见错误**：用 OR 解读高患病率结局、忽略复杂抽样权重直接做点估计。

### A2 病例对照研究

**适用**：结局已发生、回顾比较病例与对照的既往暴露，适合罕见病、长潜伏期结局的病因探索（如肿瘤、罕见不良反应）。

**要点**：按结局状态选病例组与对照组（来自同一源人群），回顾收集暴露史；指标 OR = (a×d)/(b×c) = 病例组暴露比值 / 对照组暴露比值，罕见病时近似 RR。匹配设计（个体/频数匹配）提高效率并控制混杂，但必须用条件 logistic 回归；不能直接估计发病率。典型偏倚：回忆偏倚、选择偏倚（如 Berkson 偏倚）、暴露测量偏倚。

**代码**：

```stata
* ===== Stata =====
tabulate exposed case, chi2
cci 40 20 30 70          // 病例暴露/非暴露=40/20，对照暴露/非暴露=30/70 → OR 与 CI
logistic case exposed age, or              // 不匹配：多因素校正 OR
clogit case exposed, group(pairid) or      // 1:1 匹配：条件 logistic

* ===== R =====
m <- matrix(c(40, 20, 30, 70), nrow = 2)   # 病例暴露/非暴露、对照暴露/非暴露
fisher.test(m)                             # 精确 OR 与 CI
glm(case ~ exposed + age, family = binomial(), data = d)   # 校正 OR
library(survival)
clogit(case ~ exposed + strata(pairid), data = d)          # 匹配条件 logistic
```

**报告要点**：报告病例/对照来源、匹配变量与匹配比、应答率；报告 OR 与 95% CI、校正变量与模型类型（条件/非条件）。

**常见错误**：匹配数据用非条件 logistic（偏倚）、结局不罕见时把 OR 当 RR 解释。

### A3 队列研究

**适用**：按暴露状态分组、随访观察结局，用于验证病因或评估暴露效应，可直接计算发病率、同时观察多个结局（如出生队列、职业队列）。

**要点**：暴露组与非暴露组前瞻（或回顾）随访；核心指标：累积发病率 CI = 发病数/期初人数、发病密度 ID = 发病数/人时。关联：RR = 暴露组发病率/非暴露组发病率（2×2 数据），人时数据用 Poisson 回归得 IRR，含删失的生存数据用 Cox 回归得 HR。典型偏倚：失访偏倚、健康工人效应、暴露/结局测量偏倚，混杂用分层 MH 或多变量模型控制。

**代码**：

```stata
* ===== Stata =====
cs disease exposed, exact                  // 2×2：RR 及 CI
ir disease exposed                         // 发病密度比 IRR
stset time, failure(disease)               // 人时/生存数据
strate exposed                             // 各组人时与发病率
poisson disease exposed, exposure(time) irr
stcox exposed age                          // 校正 HR

* ===== R =====
library(epiR)
epi.2by2(matrix(c(45, 955, 20, 980), nrow = 2), method = "cohort.count")
glm(disease ~ exposed + offset(log(time)), family = poisson(), data = d)  # IRR
library(survival)
coxph(Surv(time, disease) ~ exposed + age, data = d)                      # HR
```

**报告要点**：报告随访起止、人时、失访率与删失规则；报告累积发病率/发病密度及 RR/IRR/HR 的 95% CI 与校正模型。

**常见错误**：忽略人时把发病密度当累积发病率，或随访长短不一却不用生存分析。

### A4 随机对照试验 RCT

**适用**：评价干预效果的金标准，随机分配均衡已知与未知混杂，用于药物、诊疗方案与卫生服务干预的效果评价。

**要点**：要素为随机分配（简单/区组/分层）、对照（安慰剂/标准治疗）、盲法（单盲/双盲），平行组为主，另有交叉与整群设计。首要分析人群为 ITT（意向性分析）；效应量：二分类结局用 RR、RD 与 NNT（NNT = 1/RD），连续结局用均数差 MD。报告遵循 CONSORT（注册号、随机序列、分配隐藏、盲法、流程图）。整群 RCT 需按设计效应 DE = 1 + (m−1)×ICC 扩大样本量。

**代码**：

```stata
* ===== Stata =====
set obs 120
set seed 2026
egen block = seq(), to(30) block(4)       // 30 个区组、组内 4 人
gen treat = rbinomial(1, 0.5)             // 简单随机（严格 2:2 区组需再抽样）
tab treat
csi 20 10 25 5                            // 干预组事件/非事件=20/10，对照组=25/5 → RD、RR 及 CI；NNT=1/RD
ttest y, by(treat)                        // 连续结局：MD
regress y treat, vce(robust)

* ===== R =====
set.seed(2026)
d$treat <- sample(rep(0:1, 60))           # 120 人简单随机（可用 blockrand 做区组）
library(epiR)
epi.2by2(table(d$treat, d$outcome), method = "cohort.count")   # RR/RD/NNT
t.test(y ~ treat, data = d)
lm(y ~ treat, data = d)
```

**报告要点**：报告注册号、随机方法与分配隐藏、盲法、CONSORT 流程图；同时报告 ITT（与 PP）结果、效应量及 95% CI（NNT 须附 CI）。

**常见错误**：用 PP 替代 ITT 下结论、未报告分配隐藏，或整群随机忽略设计效应。

### A5 准实验设计

**适用**：无法随机分配时评价政策/干预效果的次优选择，如自然实验、政策评估（医改前后比较、地区间政策差异）。

**要点**：常见类型：前后对照、非等同对照组（DID）、间断时间序列 ITS、断点回归 RDD。DID =（干预组前后差）−（对照组前后差），以组×时间交互项系数估计，前提是平行趋势；ITS 用分段回归，干预后水平变化与斜率变化分开估计。典型威胁：历史因素、向均数回归、霍桑效应与选择偏倚，须做平行趋势/安慰剂检验。

**代码**：

```stata
* ===== Stata =====
gen did = treat * post
regress y treat post did, vce(cluster id)        // did 系数即 DID 估计
xtset id time
xtreg y ib0.time#i.treat i.time, fe vce(cluster id)   // 事件研究：检验平行趋势
gen time_after = max(0, time - t0)               // ITS 分段回归（t0 = 干预时点）
newey y time post time_after, lag(1)             // Newey-West 处理自相关

* ===== R =====
m <- lm(y ~ treat * post, data = d)              # 交互项系数即 DID
library(sandwich); library(lmtest)
coeftest(m, vcov = vcovCL(m, cluster = ~id))     # 聚类稳健标准误
d$time_after <- pmax(0, d$time - t0)
its <- lm(y ~ time + post + time_after, data = d)   # ITS 分段回归
```

**报告要点**：报告设计类型与可比性证据（基线平衡、平行趋势图、安慰剂检验）；报告 DID 系数或 ITS 水平/斜率变化及 95% CI 与稳健标准误类型。

**常见错误**：不检验平行趋势就下因果结论，或 ITS 忽略自相关直接用 OLS 标准误。

### A6 生态学研究

**适用**：以群体（国家/地区/年份）为分析单位探索宏观暴露与结局关联，用于跨国比较、政策环境因素分析与假说生成，数据易得、成本低。

**要点**：分析单位是群体，暴露与结局均为群体汇总值，关联指标为相关系数、加权回归斜率或标化率比；比较地区率前须标准化年龄结构。核心局限是生态学谬误——群体关联不能推论到个体（跨层推论需多水平模型）；典型混杂为未测量的群体因素（医疗可及性、经济水平）。

**代码**：

```stata
* ===== Stata =====
regress rate exposure [aweight = pop]           // 按地区人口加权
corr rate exposure
dstdize deaths pop, by(agegrp) using(stdpop)    // 直接标化；stdpop.dta 含 agegrp 与 pop

* ===== R =====
m <- lm(rate ~ exposure, data = d, weights = pop)
cor(d$rate, d$exposure)
library(epitools)
ageadjust.direct(count = d$deaths, pop = d$pop, stdpop = ref$stdpop)  # 直接标化
```

**报告要点**：报告分析单位与群体指标定义、是否加权/标化；明确“生态学谬误”局限，结论限定在群体层面。

**常见错误**：把群体关联外推为个体因果（生态学谬误），或不标化年龄结构直接比较地区率。

### A7 混合方法研究（定性+定量）

**适用**：单一方法不足以回答研究问题时，定性（机制、体验、实施障碍）与定量（测量、检验）互补，常见于卫生服务研究、实施科学与量表开发。

**要点**：核心设计：聚敛（并行）、解释性顺序（先量后质）、探索性顺序（先质后量）、嵌入式；须明确整合点与整合方式（如 joint display 联合展示）。抽样上定量用概率抽样、定性用目的抽样（最大变异/典型/极端案例），定性样本量以信息饱和为原则。质量报告：定性遵循 COREQ，整体遵循 GRAMMS/MMARS，三角互证提升效度。

**代码**：

```stata
* ===== Stata =====
ttest score, by(group)                 // 定量侧比较
tab theme group, chi2                  // 定性主题（编码后）与分组交叉：量化整合

* ===== R =====
library(quanteda)
dfm <- dfm(tokens(interview_text), remove_punct = TRUE)   # 定性文本：词频辅助主题
topfeatures(dfm, 20)
t.test(score ~ group, data = d)                           # 定量侧
chisq.test(table(d$theme, d$group))                       # 主题×分组整合
```

**报告要点**：报告设计类型（顺序/并行）与整合点、两部分抽样与分析方法；定性部分附 COREQ 清单，整合结果用 joint display 呈现。

**常见错误**：两部分平行发表而无真正整合，或定性样本套用概率抽样逻辑、未报告理论视角与反思性。

### A8 德尔菲法（Delphi）

**适用**：证据不足或意见分歧时，通过多轮匿名专家咨询收敛共识，用于指标筛选、指南推荐、评价体系构建（如卫生管理指标体系）。

**要点**：匿名多轮问卷（通常 2–3 轮），每轮反馈统计汇总（均数、变异系数 CV、满分比），专家据反馈修改意见直至收敛。指标：专家积极系数（回收率）、权威系数 Cr = (Ca + Cs)/2（Ca 判断依据、Cs 熟悉程度）、协调度（肯德尔和谐系数 W、CV）。专家一般 15–50 人；条目筛选常用均数 ≥ 3.5 且 CV ≤ 0.25（阈值因研究而异）。

**代码**：

```stata
* ===== Stata =====
egen mean_score = mean(score), by(item)
egen sd_score = sd(score), by(item)
gen cv = sd_score / mean_score
list item mean_score cv if mean_score >= 3.5 & cv <= 0.25   // 示例筛选阈值
ssc install concord
concord score1-score15                       // 各专家评分变量 → 肯德尔 W

* ===== R =====
library(dplyr)
d |> group_by(item) |>
  summarise(m = mean(score), cv = sd(score)/mean(score)) |>
  filter(m >= 3.5 & cv <= 0.25)              # 示例筛选阈值
library(irr)
w <- kendall(t(as.matrix(xtabs(score ~ expert + item, data = d))))   # 行为条目、列为专家
w$value                                      # 肯德尔和谐系数 W
```

**报告要点**：报告轮数、每轮专家数与积极系数、权威系数、筛选标准与保留/删除条目清单、协调系数及其显著性检验。

**常见错误**：轮间无统计反馈直接计分、只看均数忽略离散度与协调度检验，专家过于同质却称“共识”。

---


### A9 复杂抽样与调查权重

**适用**：分层整群调查的总体估计；区分横断面与纵向权重。

**逻辑与操作**：先定义目标与数据单位，再核对假设、执行诊断并解释结果。完整步骤、代码和边界见 [复杂抽样与调查权重专题](longitudinal-public-data-skill.md)。

**报告要点**：抽样层级、PSU、分层、权重版本、目标总体和方差估计。

**常见错误**：直接把全国调查当简单随机样本，或把调查权重与因果权重混用。

## B 类：统计分析核心方法（18个方法）

条目统一采用「适用 / 要点 / 代码 / 报告要点 / 常见错误」模板；**代码**为单个代码块，内部以 `* Stata` 与 `# R` 注释分隔，各给出核心命令。

---

### B1 描述统计与正态性检验

**适用**：任何连续型变量的分布描述与正态性判断，是选择后续参数或非参数方法的起点。

**要点**：连续资料先报 n、均值±SD（正态）或中位数（P25–P75，偏态）与最小–最大值，`summarize, detail` 还给出偏度/峰度。正态性判断不能只看 Shapiro-Wilk 检验（大样本时几乎总拒绝），要结合直方图与 Q-Q 图，并参考 |偏度|<2、|峰度|<7 等经验界值。偏态明显时报告并分析中位数（IQR），可先尝试对数/平方根变换，或直接改用非参数方法。

**代码**：

```stata+r
* Stata
summarize y, detail              // n、均值、百分位数、偏度峰度
swilk y                          // Shapiro-Wilk 正态性检验
histogram y, normal              // 直方图叠加正态密度曲线
qnorm y                          // 分位-分位（Q-Q）图

# R
summary(df$y)                    // 五数概括
shapiro.test(df$y)               // Shapiro-Wilk 检验
hist(df$y, prob = TRUE); lines(density(df$y))
qqnorm(df$y); qqline(df$y)       // Q-Q 图
```

**报告要点**：正态资料报均值±SD，偏态资料报中位数（P25, P75）；写明正态性检验方法与结论，以及是否做了变量变换。

**常见错误**：只看 Shapiro-Wilk 的 p 值、不看直方图/Q-Q 图与偏度峰度，或对严重偏态数据仍报均值±SD。

---

### B2 t 检验与方差分析

**适用**：两组（t 检验）或三组及以上（方差分析）连续结局的组间比较。

**要点**：两组独立样本用独立样本 t 检验，方差齐性不满足时用 Welch 校正（`unequal`）；同一对象前后两次测量用配对 t 检验。三组及以上用单因素方差分析（ANOVA），F 显著后再做两两比较并用 Bonferroni/Tukey 校正多重性。多组反复做两两 t 检验会膨胀 I 类错误。

**代码**：

```stata+r
* Stata
ttest y, by(group) unequal       // Welch t 检验（不假定方差齐）
ttest y1 == y2                   // 配对 t 检验
oneway y group, bonferroni       // 单因素 ANOVA + Bonferroni 两两比较
anova y group                    // 方差分析表

# R
t.test(y ~ group, data = df)              // 默认 Welch t 检验
t.test(df$y1, df$y2, paired = TRUE)       // 配对 t 检验
fit <- aov(y ~ group, data = df)
summary(fit); TukeyHSD(fit)               // ANOVA + Tukey 两两比较
```

**报告要点**：报各组均值±SD、统计量（t 或 F）、自由度与 p 值，差值或组间差异附 95% CI；ANOVA 两两比较注明校正方法与校正后 p。

**常见错误**：多组间重复做两两 t 检验不校正；把配对数据当独立样本（或反之）分析。

---

### B3 卡方检验与非参数检验

**适用**：分类结局的组间比较，以及不满足正态/方差齐性条件的连续或等级资料的组间比较。

**要点**：四格表先看期望频数：n≥40 且所有期望频数≥5 用 Pearson 卡方，否则用 Fisher 精确检验。等级资料或严重偏态的连续资料，两独立组用 Mann-Whitney U（`ranksum`），配对用 Wilcoxon 符号秩（`signrank`），多组用 Kruskal-Wallis（`kwallis`）。非参数检验比较的是分布/秩次而非均数，结论措辞要相应调整。

**代码**：

```stata+r
* Stata
tab a b, chi2 exact              // Pearson 卡方 + Fisher 精确检验
ranksum y, by(group)             // Mann-Whitney U（Wilcoxon 秩和）
signrank y1 = y2                 // 配对 Wilcoxon 符号秩检验
kwallis y, by(group)             // Kruskal-Wallis 检验

# R
chisq.test(table(df$a, df$b))    // Pearson 卡方
fisher.test(table(df$a, df$b))   // Fisher 精确检验
wilcox.test(y ~ group, data = df)
kruskal.test(y ~ group, data = df)
```

**报告要点**：卡方报 χ²、df、p（或 Fisher 精确 p），并说明方法选择依据；非参数检验报中位数（IQR）与检验统计量，不报均数±SD。

**常见错误**：期望频数<5 仍用 Pearson 卡方；把秩和检验结果描述为「两组均数差异」。

---

### B4 相关与简单线性回归

**适用**：两个连续变量间线性关联的方向与强度描述（相关），及一个变量预测另一个变量的简单线性回归。

**要点**：双变量均近正态时用 Pearson r，否则用 Spearman ρ；r 只衡量线性关联强度，不表示因果。回归分析前必须画散点图确认线性趋势并识别离群点，回归系数 β 报告 95% CI，R² 表示结局方差被解释的比例。拟合后应检查残差的正态性、独立性与方差齐性。

**代码**：

```stata+r
* Stata
scatter y x                     // 先画散点图判断线性
pwcorr x y, sig                 // Pearson r 及 p 值
spearman x y                    // Spearman ρ
regress y x                     // 简单线性回归

# R
plot(df$x, df$y)
cor.test(df$x, df$y, method = "pearson")
cor.test(df$x, df$y, method = "spearman")
fit <- lm(y ~ x, data = df); summary(fit)
```

**报告要点**：相关报 r（或 ρ）、p 与样本量；回归报 β（95% CI）与 R²，并附散点图与回归线。

**常见错误**：不画散点图直接算 Pearson 相关（被非线性或离群值误导）；把相关性解读为因果关系。

---

### B5 二元 logistic 回归

**适用**：二分类结局（患病与否、是否就诊、是否满意）的影响因素分析，结果以比值比 OR 解释。

**要点**：模型为 logit(p)=β₀+Σβᵢxᵢ，OR=exp(β) 表示自变量每增加 1 个单位时结局「发生/不发生」比值的变化倍数；分类自变量必须设参照组（虚拟变量）。报告整体模型的似然比检验、区分度（AUC）与校准（Hosmer-Lemeshow）。结局事件数太少（每自变量不足约 10 个事件，EPV<10）时模型不稳定，应减少自变量。

**代码**：

```stata+r
* Stata
logit y x1 x2, or               // 二元 logistic，报告 OR
estat gof, group(10)            // Hosmer-Lemeshow 校准检验
lroc                            // ROC 曲线与 AUC

# R
fit <- glm(y ~ x1 + x2, data = df, family = binomial)
exp(cbind(OR = coef(fit), confint(fit)))   // OR 与 95% CI
summary(fit)
```

**报告要点**：逐变量报 OR（95% CI）与 p，注明参照组与连续变量的单位；附模型整体检验、AUC 与校准检验结果。

**常见错误**：把 OR 当 RR（风险比）解释（结局常见时严重高估）；连续变量 OR 不注明「每 1 单位」。

---

### B6 有序/多项 logistic 回归

**适用**：等级结局（Likert 量表、疾病分期等有序分类）与无序多分类结局（就医机构类型、职业类别等）的影响因素分析。

**要点**：有序结局用有序 logistic（比例优势模型），前提是比例优势假设（各切点回归系数相同），用 Brant 检验验证；满足时报一个公共 OR，不满足改用广义有序 logit（`gologit2`）或多项模型。无序多分类用多项 logistic，选定一类为参照，其余各类分别与参照类比较，系数指数化后为相对风险比 RRR。

**代码**：

```stata+r
* Stata
ologit y x1 x2, or              // 有序 logistic（比例优势模型）
brant, detail                   // 比例优势/平行线假设检验（SSC 安装）
mlogit y x1 x2, rrr base(1)     // 多项 logistic，参照组=1，报 RRR

# R
library(MASS)
fit <- polr(y ~ x1 + x2, data = df, Hess = TRUE)   // y 需为有序因子
exp(cbind(coef(fit), confint(fit)))                // 公共 OR
library(nnet)
mfit <- multinom(y ~ x1 + x2, data = df)           // 多项模型，exp(coef)=RRR
```

**报告要点**：有序模型报公共 OR（95% CI）并注明 Brant 检验结果；多项模型按类别报 RRR（95% CI）并注明参照类别。

**常见错误**：不检验比例优势假设就解释 ologit 结果；把多项 logit 的 RRR 误称为 OR。

---

### B7 Poisson 与负二项回归

**适用**：计数结局（就诊次数、住院天数、跌倒次数、处方数等）的回归建模。

**要点**：Poisson 回归假设均数=方差；存在过度离散（方差明显大于均数）时标准误被低估，改用负二项回归（`nbreg`/`glm.nb`）或 Poisson+稳健标准误。随访/暴露时间不等时必须加 `exposure()`（Stata）或 `offset(log(t))`（R）按人时调整。结果以发病率比 IRR=exp(β) 解释；零计数过多可考虑零膨胀模型（zip/zinb）。

**代码**：

```stata+r
* Stata
poisson y x1 x2, irr vce(robust)          // Poisson + 稳健标准误
nbreg y x1 x2, irr                        // 负二项回归
poisson y x1 x2, irr exposure(t)          // 随访时间不等：按 t 调整

# R
glm(y ~ x1 + x2, data = df, family = poisson)
library(MASS)
fit <- glm.nb(y ~ x1 + x2, data = df)     // 负二项
exp(cbind(IRR = coef(fit), confint(fit)))
```

**报告要点**：报 IRR（95% CI）与 p，说明过度离散检验与模型选择依据，并注明是否按随访/暴露时间调整。

**常见错误**：存在过度离散仍用普通 Poisson 且不加稳健标准误；随访时间不等却不加 exposure/offset。

---

### B8 生存分析（Kaplan-Meier 与 Cox）

**适用**：事件发生时间结局（再入院时间、死亡时间、并发症出现时间等），数据含删失。

**要点**：先用 `stset` 定义随访时间与事件指示变量（0=删失、1=事件），编码弄反会使 KM 曲线与风险集全部出错。Kaplan-Meier 法估计生存函数并画曲线，log-rank 检验比较组间差异；Cox 模型估计风险比 HR 并做多变量调整。必须用 Schoenfeld 残差（`estat phtest`/`cox.zph`）检验比例风险（PH）假设，违反时改用分层 Cox 或时依协变量模型。

**代码**：

```stata+r
* Stata
stset time, failure(event)               // event=1 事件，0 删失
sts graph, by(group)                     // Kaplan-Meier 生存曲线
sts test group                           // log-rank 检验
stcox x1 x2                              // Cox 比例风险模型（HR）
estat phtest, detail                     // PH 假设检验

# R
library(survival)
fit <- survfit(Surv(time, event) ~ group, data = df)
plot(fit); survdiff(Surv(time, event) ~ group, data = df)
cfit <- coxph(Surv(time, event) ~ x1 + x2, data = df)
summary(cfit); cox.zph(cfit)             // PH 假设检验
```

**报告要点**：KM 报告中位生存时间与 log-rank p；Cox 报 HR（95% CI）与 p，并注明 PH 假设检验结果。

**常见错误**：事件/删失编码弄反；不检验 PH 假设就直接解释 Cox 的 HR。

---

### B9 重复测量与混合效应模型

**适用**：同一对象多次随访的重复测量数据，或患者嵌套于医院/村等层级（聚类）数据的建模。

**要点**：重复测量数据各次观测彼此相关，不能当独立样本处理；球形假设满足时可用重复测量 ANOVA，否则用线性混合效应模型。混合模型以随机截距/随机斜率刻画个体轨迹差异，报告重点是固定效应 β 及其 95% CI，随机效应与协方差结构的选择用 AIC/BIC 或似然比检验判断。二分类结局改用广义混合模型（`melogit`/`glmer`）。

**代码**：

```stata+r
* Stata
xtset id time
mixed y x##c.time || id: time, reml      // 随机截距 + 随机斜率
mixed y x##c.time || id:                 // 仅随机截距（供比较）
estat ic                                 // AIC/BIC 比较
* 二分类结局改用：melogit y x || id:

# R
library(lme4); library(lmerTest)         // lmerTest 提供 p 值
fit <- lmer(y ~ x*time + (1 + time | id), data = df)
summary(fit)
ranova(fit)                              // 随机效应结构的似然比检验
```

**报告要点**：报固定效应 β（95% CI）与 p，说明随机效应/协方差结构及其选择依据（AIC、LRT），并注明估计方法（REML）。

**常见错误**：把重复测量当独立样本分析（标准误低估、I 类错误膨胀）；不交代随机效应结构设定。

---

### B10 主成分分析与因子分析

**适用**：多个指标降维合成综合得分（主成分分析），或探索量表/问卷的潜在结构（探索性因子分析）。

**要点**：先做适用性检验：KMO>0.6 可接受（>0.8 好）、Bartlett 球形检验 p<0.05，不满足则不适合因子分析。主成分数按特征值>1、碎石图肘点或累计方差解释率（如≥60–80%）确定；因子分析定因子数优先用平行分析，并选择旋转方法（正交 varimax 或斜交 promax）。载荷 |λ|≥0.4 视为有实际意义，量表类结果还应报告 Cronbach's α。

**代码**：

```stata+r
* Stata
pca x1-x10                          // 主成分分析
factor x1-x10, pcf                  // 因子分析（主成分因子法）
estat kmo                           // KMO（Bartlett 检验：ssc install factortest）
rotate, varimax                     // 正交旋转后看载荷
alpha x1-x10                        // Cronbach's α

# R
library(psych)
KMO(df); cortest.bartlett(df)       // 适用性检验
fa.parallel(df)                     // 平行分析定因子数
fa(df, nfactors = 3, rotate = "varimax")   // 探索性因子分析
alpha(df)                           // Cronbach's α
```

**报告要点**：报 KMO 与 Bartlett 检验结果、因子/主成分数及确定依据、方差解释率与旋转后载荷矩阵，量表附 Cronbach's α。

**常见错误**：未做 KMO/球形检验就做因子分析；把 PCA 与因子分析混为一谈；仅凭特征值>1 定因子数。

---

---


### B11 一致性评价：Kappa / ICC

**适用**：名义、等级或连续评分的评审者一致性；与准确性分开。

**逻辑与操作**：先定义目标与数据单位，再核对假设、执行诊断并解释结果。完整步骤、代码和边界见 [一致性评价：Kappa / ICC专题](medical-ai-evaluation-skill.md)。

**报告要点**：评分者结构、量表类型、Kappa/ICC定义、区间及类别分布。

**常见错误**：用相关性代替一致性，或将高一致性等同于高准确性。

### B12 竞争风险与累积发生率

**适用**：死亡等事件阻止目标结局发生时，估计原因别风险或实际累积风险。

**逻辑与操作**：先定义目标与数据单位，再核对假设、执行诊断并解释结果。完整步骤、代码和边界见 [竞争风险与累积发生率专题](longitudinal-public-data-skill.md)。

**报告要点**：事件定义、竞争事件、估计目标、时间点与绝对风险。

**常见错误**：把竞争死亡作为无信息删失，直接用1-KM解释实际发生风险。

### B13 广义线性模型 GLM

**适用**：依据结局支持集与均值-方差关系选择分布和链接。

**逻辑与操作**：先定义目标与数据单位，再核对假设、执行诊断并解释结果。完整步骤、代码和边界见 [广义线性模型 GLM专题](econometric-modeling-skill.md)。

**报告要点**：分布、链接、支持集、方差、诊断、边际预测与区间。

**常见错误**：对含零费用直接用Gamma，或把链接尺度系数当原尺度差异。

### B14 费用两部模型

**适用**：分别估计发生费用概率与正费用均值，再合成人群费用。

**逻辑与操作**：先定义目标与数据单位，再核对假设、执行诊断并解释结果。完整步骤、代码和边界见 [费用两部模型专题](econometric-modeling-skill.md)。

**报告要点**：两部分样本/模型、合成预测、区间及因果假设。

**常见错误**：只报告正费用模型，忽略使用概率和整个估计流程的不确定性。

### B15 面板 FE / RE / CRE

**适用**：区分组内变化、组间差异及个体效应与协变量的关系。

**逻辑与操作**：先定义目标与数据单位，再核对假设、执行诊断并解释结果。完整步骤、代码和边界见 [面板 FE / RE / CRE专题](econometric-modeling-skill.md)。

**报告要点**：单位/时间效应、组内变异、假设、聚类层级与动态偏误。

**常见错误**：把FE当作全部内生性的解决方案，或仅凭Hausman选择模型。

### B16 分位数回归

**适用**：研究条件分布不同位置的费用或健康结局关联。

**逻辑与操作**：先定义目标与数据单位，再核对假设、执行诊断并解释结果。完整步骤、代码和边界见 [分位数回归专题](econometric-modeling-skill.md)。

**报告要点**：条件/无条件目标、分位点、区间和模型支持。

**常见错误**：把条件分位数系数直接解释为同一群个体的因果效应。

### B17 零膨胀与 hurdle 计数模型

**适用**：依据零产生机制区分结构性零与计数过程。

**逻辑与操作**：先定义目标与数据单位，再核对假设、执行诊断并解释结果。完整步骤、代码和边界见 [零膨胀与 hurdle 计数模型专题](econometric-modeling-skill.md)。

**报告要点**：零机制、两部分模型、过度离散、拟合和边际效应。

**常见错误**：仅因零很多就选择零膨胀，不核对两过程机制与可识别性。

### B18 空间计量与溢出

**适用**：分析地区间依赖并在合适模型中解释直接/间接效应。

**逻辑与操作**：先定义目标与数据单位，再核对假设、执行诊断并解释结果。完整步骤、代码和边界见 [空间计量与溢出专题](econometric-modeling-skill.md)。

**报告要点**：空间权重、尺度、依赖结构、直接/间接效应与敏感性。

**常见错误**：把空间自相关直接当作政策溢出因果证据。

## 方法学速查手册 · C 类：卫生经济与卫生政策（8个方法）

> 片段文件，每条目采用统一模板：**适用 / 要点 / 代码（Stata + R）/ 报告要点 / 常见错误**。命令与选项随软件版本更新，正式运行前以 `help <cmd>`（Stata）或 `?<fn>`（R）为准。

### C1 成本测算
**适用**：测算某一疾病、干预或服务在特定视角与时间段内消耗的资源总量（货币化成本），为成本分析、CEA/BIA 提供成本输入。
**要点**：先明确测算视角（社会 / 卫生体系 / 医保 / 患者）与时间范围，视角决定纳入范围。
成本分直接成本（直接医疗 + 直接非医疗）与间接成本（生产力损失，常用人力资本法按工资估算）。
按「识别—测量—估值」三步：识别资源项目 → 测量消耗数量 → 以单位成本估值（数量 × 单价）。
微观成本法（bottom-up）逐项自下而上加总，自上而下法（top-down）用总费用分摊，二者结果应交叉校验；跨年度成本须按医疗 CPI 等调整价格并按贴现率折现。
**代码**：

```stata
* 成本均数与 bootstrap 95% CI（成本右偏时优于正态 CI）
bootstrap r(mean), reps(1000) seed(2026): summarize cost
ci means cost
```

```r
set.seed(2026)
boot <- replicate(1000, mean(sample(cost, replace = TRUE)))
mean(cost)                       # 点估计
quantile(boot, c(.025, .975))    # 95% 百分位置信区间
```

**报告要点**：报告测算视角、时间范围、数据与单价来源（年份）、贴现率与价格调整方式；均数附 95% CI。
**常见错误**：混淆视角（把患者自负费用计入医保视角成本），或把不同年份未经价格调整的成本直接相加。

---

### C2 成本-效果分析 CEA 与成本-效用分析 CUA
**适用**：比较两种及以上干预的成本与健康产出，产出为自然单位（CEA）或 QALY（CUA）。
**要点**：核心指标 ICER = ΔC/ΔE = (C₁−C₀)/(E₁−E₀)，与支付意愿阈值（国内常用 1–3 倍人均 GDP/QALY，口径须注明）比较判断经济性。
不确定性用 bootstrap 或概率敏感性分析（PSA）刻画，绘制成本-效果平面与成本-效果可接受曲线（CEAC）；净货币效益 NMB = λ·ΔE − ΔC > 0 等价于在阈值 λ 下可接受。
增量必须基于同一人群、同一时间范围计算，不能简单用两组均值相除代替统计推断。
**代码**：

```stata
* ICER 增量计算（arm：1 = 干预，0 = 对照；ttest 按组值升序，组 2 为 arm=1）
ttest c, by(arm)
scalar dC = r(mu_2) - r(mu_1)
ttest e, by(arm)
scalar dE = r(mu_2) - r(mu_1)
di "ICER = " dC / dE
```

```r
dC <- with(dat, mean(c[arm == 1]) - mean(c[arm == 0]))
dE <- with(dat, mean(e[arm == 1]) - mean(e[arm == 0]))
set.seed(2026)
icers <- replicate(1000, with(dat[sample(nrow(dat), replace = TRUE), ],
              (mean(c[arm==1]) - mean(c[arm==0])) / (mean(e[arm==1]) - mean(e[arm==0]))))
quantile(icers, c(.025, .975))   # bootstrap ICER 置信区间
```

**报告要点**：并列报告两组成本与效果均数（含 95% CI）、ICER 及 bootstrap/PSA 结果（CEAC 上阈值处的接受概率），并注明阈值来源。
**常见错误**：增量效果趋近 0 时 ICER 数值爆炸仍直接解读，或不做不确定性分析即断言结论稳健。

---

### C3 QALY 与 DALY 计算
**适用**：把生存时间与生命质量合成为单一健康产出（QALY），或按死亡与伤残损失合成疾病负担（DALY），用于 CUA 与负担比较。
**要点**：QALY = Σ 生存年 × 效用权重（0–1），效用来自 EQ-5D-5L（使用中国效用值集）、SF-6D 或 TTO/SG，纵向数据用曲线下面积法按时间区间加总。
DALY = YLL + YLD：YLL = 死亡数 × 标准期望寿命，YLD = 患病人数 × 伤残权重 × 病程（权重查 GBD 表）。
DALY 常用 GBD 参数（3% 贴现、年龄权重）；QALY 与 DALY 互为近似镜像但不能直接互换。
**代码**：

```stata
* QALY：效用曲线下面积（q 为效用、t 为时点，按 id 与 t 排序）
bysort id (t): gen qaly_step = (q + q[_n-1]) / 2 * (t - t[_n-1]) if _n > 1
bysort id: egen qaly = total(qaly_step)
* DALY：YLL + YLD（yll、yld 按 GBD 公式预先计算）
gen daly = yll + yld
```

```r
dat <- dat[order(dat$id, dat$t), ]
qaly <- tapply(seq_len(nrow(dat)), dat$id, function(i) {
  t <- dat$t[i]; q <- dat$q[i]
  sum(diff(t) * (head(q, -1) + tail(q, -1)) / 2)     # 梯形面积法
})
```

**报告要点**：报告效用工具、值集来源与测量时点，说明 QALY 加总方法（AUC/梯形法）与 DALY 的伤残权重、贴现参数。
**常见错误**：把疾病严重度评分当效用权重，或直接混用 QALY 与 DALY 做比较。

---

### C4 预算影响分析 BIA
**适用**：从预算持有人（医保基金、医院或政府）视角，估计采纳新干预后 3–5 年内逐年及累计的财务影响。
**要点**：预算影响 =（新干预下目标人群总费用）−（现行干预下总费用），按「目标人群规模 × 渗透/替代率 × 人均年费用」逐年滚动测算。
需设定市场吸纳曲线（uptake）、替代与增量使用比例、人群自然增长与价格变化；ISPOR 建议按年度现金流报告、不做贴现，且与 CEA 分开呈现。
**代码**：

```stata
* 逐年预算影响 = 目标人群 × 渗透率 ×（新方案 − 现行方案）人均年费用
gen bi = pop * uptake * (c_new - c_cur)
list year bi
sum bi                         // 研究期内合计
```

```r
bia <- data.frame(year = 1:5, pop = 1e5, uptake = c(.2, .4, .6, .8, .9))
bia$bi <- bia$pop * bia$uptake * (c_new - c_cur)
bia                            # 逐年预算影响；sum(bia$bi) 为合计
```

**报告要点**：报告视角、时间范围、目标人群与 uptake/替代假设，并给出单因素与情景（乐观/悲观）敏感性分析。
**常见错误**：把预算影响结果当作成本-效果结论，或漏报 uptake 与人群增长假设。

---

### C5 卫生技术评估 HTA 流程
**适用**：为新技术（药品、器械、诊断、服务包）的准入、定价与报销决策整合临床与经济证据的规范化评估。
**要点**：标准流程：明确评估问题（PICO 与决策问题）→ 系统检索与证据评价 → 临床效果（必要时间接比较/网状 Meta）→ 经济评价（CEA/CUA + BIA）→ 伦理、组织、公平等非经济维度 → 综合报告供委员会决策。
核心产出是相对阈值的经济性判断与预算影响估计；国内对应医保谈判/准入的申报与专家评审流程。
**代码**：

```stata
* PSA 决策判断：净货币效益 NMB = λ·ΔE − ΔC，λ 为阈值（如 1–3 倍人均 GDP）
gen nmb = lambda * (e_new - e_cur) - (c_new - c_cur)
count if nmb > 0
di "成本-效果概率 = " r(N) / _N
```

```r
nmb <- lambda * (e_new - e_cur) - (c_new - c_cur)
mean(nmb > 0)                  # NMB > 0 的比例 → CEAC 上阈值 λ 处的接受概率
```

**报告要点**：写明评估视角、关键参数来源与假设、模型结构及不确定性，并独立核验申办方提交的参数与模型。
**常见错误**：直接采信申办方模型结论而不做独立校验，或把 HTA 简化为只看 ICER 的经济评价。

---

### C6 随机前沿分析 SFA 与数据包络分析 DEA（效率评价）
**适用**：评价医院、科室、疾控机构等决策单元（DMU）的技术效率及其影响因素。
**要点**：DEA 为非参数确定性前沿：CCR（规模报酬不变）与 BCC（可变），允许多投入多产出、无需函数形式，但对离群值敏感且不区分随机误差与无效率。
SFA 为参数随机前沿：把误差分解为统计噪声 v 与无效率 u（半正态/截断正态等分布假设），可检验影响因素，但一般仅处理单一产出。
两者常组合使用：DEA 得效率得分，再以 Tobit/截断回归或 SFA 分析效率影响因素。
**代码**：

```stata
* SFA：Cobb-Douglas 随机前沿，半正态无效率
sfcross y x1 x2, distribution(hnormal)
predict te_sfa, te
* DEA：投入导向 BCC（先 ssc install dea）
dea x1 x2 = y, rts(vrs) ort(in)   // 效率得分；选项以 help dea 为准
```

```r
library(Benchmarking)
r_dea <- dea(X = cbind(x1, x2), Y = y, RTS = "vrs")    # 投入导向 BCC
eff_dea <- r_dea$eff                                    # Farrell 效率 E ∈ (0,1]
library(frontier)
eff_sfa <- efficiencies(sfa(log(y) ~ log(x1) + log(x2), data = dat))
```

**报告要点**：报告前沿模型设定（方向、规模报酬、分布假设）、效率得分分布（均值/四分位）与影响因素回归结果。
**常见错误**：样本量相对投入产出维度过小导致多数 DMU 效率 = 1 仍做解释，或 SFA 无效率分布假设未检验。

---

### C7 医保支付标准测算（DRG/DIP 权重与点值测算思路）
**适用**：为 DRG/DIP 付费改革测算病组权重、费率与病种分值、点值，作为医保基金按病种结算的支付标准。
**要点**：DRG：权重 RW = 该病组例均费用 ÷ 全部病例例均费用（基于历史住院费用数据，再经临床论证与成本校正）；费率 = 住院基金预算总额 ÷ Σ(RW × 组病例数)，支付标准 = RW × 费率 × 调整系数。
DIP：病种分值 = 该病种例均费用 ÷ 基准例均费用（或相对点数），点值 = 区域基金总额 ÷ Σ(病种分值 × 病例数)，总量控制下按年度清算校正。
权重/分值应剔除不合理费用结构影响（药品耗材占比、人次人头比）并建立动态调整机制。
**代码**：

```stata
* DRG 权重：病组例均费用 ÷ 全样本例均费用
bysort drg: egen fee_drg = mean(fee)
egen fee_all = mean(fee)
gen rw = fee_drg / fee_all
* DIP 点值：区域基金总额 ÷ Σ(病种分值 × 病例数)
gen point_amt = dip_score * n_cases
sum point_amt
di "每分值金额 = " fund_budget / r(sum)
```

```r
library(dplyr)
rw <- dat |> group_by(drg) |> summarise(rw = mean(fee) / mean(dat$fee))
dip_value <- fund_budget / sum(dat$dip_score * dat$n_cases)   # DIP 点值
```

**报告要点**：报告测算数据年份与费用口径、权重/分值校正方法（专家论证、费用结构剔除）及点值年度清算与校正规则。
**常见错误**：直接使用未校正的历史例均费用当权重/分值，或忽略总额控制下点值年终清算的浮动风险。

---

### C8 卫生服务利用公平性（集中指数 CI 与不平等分解）
**适用**：量化卫生服务利用（或健康结局、费用）随经济状况分布的不平等程度及其来源。
**要点**：集中指数 CI = 2·cov(y, R)/ȳ，R 为按经济状况（收入/财富）排序的分数秩（(rank−0.5)/n），CI ∈ [−1, 1]，负值表示利用偏向较穷人群，0 为绝对平等；标准误用回归法或专门命令计算，跨人群比较时建议先做年龄性别标化。
不平等分解：CI = Σ(βk·x̄k/ȳ)·CIk + 残差，即每个影响因素按「弹性 × 该变量的集中指数」贡献，用于定位不平等的主要驱动因素。
**代码**：

```stata
ssc install conindex, replace
conindex y, rankvar(r)      // r：按经济状况排序的分数秩；选项以 help conindex 为准
```

```r
r  <- (rank(ses) - 0.5) / length(ses)   # 按经济状况排序的分数秩
ci <- 2 * cov(y, r) / mean(y)           # 协方差法集中指数
```

**报告要点**：报告 CI 及其标准误/置信区间（是否显著偏离 0），分解表给出各因素的弹性、集中指数与贡献占比。
**常见错误**：分数秩按 y 自身而非经济状况排序，或不做标化直接跨人群比较 CI。

---

## 方法学速查手册 · D 类：因果推断与政策评估（16个方法）

> 片段文件，每条目采用统一模板：**适用 / 要点 / 代码（Stata + R）/ 报告要点 / 常见错误**；D1–D5 为完整速查，D6–D8 为压缩速查（详见对应 skill）。命令与选项随软件版本更新，正式运行前以 `help <cmd>`（Stata）或 `?<fn>`（R）为准。

### D1 倾向得分匹配（PSM）

> 深入阅读：[PSM设计、权重、重叠与平衡](propensity-score-skill.md)。
**适用**：观察性数据中处理（治疗/政策暴露）分配非随机、但可观测混杂充分时，用倾向得分匹配估计平均处理效应（ATT/ATE）。
**要点**：核心思想是用协变量 X 估计倾向得分 p(X) = P(T=1|X)，将处理组与对照组按得分匹配，使两组在可观测协变量上可比，近似「准随机化」。
匹配前须检查**共同支撑**（common support）：两组 p(X) 分布应充分重叠，可画密度重叠图或用 `teffects overlap`。
匹配后须检验**平衡性**：各协变量标准化均值差 SMD，|SMD| < 0.1 视为平衡，否则调整模型设定或更换匹配算法。
PSM 只控制可观测混杂，不能解决未观测混杂。
**代码**：

```stata
* Stata：1:1 近邻匹配估计 ATT（y 结局、t 处理、x1 x2 协变量）
teffects psmatch (y) (t x1 x2), atet
tebalance summarize          // 平衡性：SMD 与方差比
tebalance density            // 共同支撑：倾向得分重叠图
```

```r
library(MatchIt)
m <- matchit(t ~ x1 + x2, data = dat, method = "nearest")
md <- match.data(m)
lm(y ~ t + x1 + x2, data = md, weights = weights)
cobalt::love.plot(m, abs = TRUE)   # SMD 平衡图
```

**报告要点**：报告匹配算法与卡尺、匹配前后样本量与 SMD 平衡表，效应量附稳健标准误与 95% CI，并声明结果仅对可观测混杂成立。
**常见错误**：把匹配后结果当作随机对照试验证据，或不报告共同支撑与平衡性检查。

---

### D2 工具变量（IV）
**适用**：处理变量存在内生性（遗漏变量、反向因果、测量误差）且能找到有效工具变量 Z 时，用工具变量法估计因果效应（2SLS）。
**要点**：有效 IV 需满足：①相关性——Z 与内生处理 T 强相关，一阶段 F 统计量 > 10（弱 IV 会放大偏误）；②排他性——Z 仅通过 T 影响 Y，不可直接检验，需靠研究设计论证；③同质性或单调性假设下，2SLS 识别的是依从者平均处理效应（LATE）。
多工具变量时可用过度识别检验（Sargan/Hansen J）检验工具变量的有效性。
工具变量的有效性首先取决于研究设计与背景论证，而非统计检验本身。
2SLS 分两阶段：第一阶段 T 对 Z（及外生协变量）回归得拟合值，第二阶段 Y 对拟合值回归；标准误由 `ivregress`/`ivreg` 自动校正。
弱 IV 时除 F 统计量外，可加做对弱工具变量稳健的推断（如 Anderson–Rubin 检验）。
R 公式 y ~ t | z 中，`|` 右侧为工具变量，t 为内生处理。
**代码**：

```stata
* Stata：2SLS（核心命令）
ivregress 2sls y (t = z), first vce(robust)
estat firststage            // 一阶段 F，>10 为强工具变量
* 多工具变量：ivregress 2sls y (t = z1 z2), first，再用 estat overid 做过度识别检验
```

```r
library(AER)
m_iv <- ivreg(y ~ t | z, data = dat)
summary(m_iv, diagnostics = TRUE)   # 含弱工具变量诊断
```

**报告要点**：报告一阶段 F、工具变量的相关性与排他性论证、2SLS 系数及稳健标准误，并把效应解读为对依从者成立的 LATE。
**常见错误**：弱工具变量（一阶段 F<10）仍下强因果结论，或把排他性假设当作可检验。

---

### D3 断点回归（RDD）
**适用**：处理由连续运行变量是否越过临界值决定（如分数线录取、年龄阈值报销）时，估计断点附近的局部因果效应。
**要点**：RDD 依据「断点附近个体近似随机落入两侧」，比较临界值两侧的局部平均结果之差。
须做三类检验：①运行变量密度在断点处连续（无操纵，McCrary 检验）；②前定协变量在断点处平衡；③结果对带宽选择稳健。
主流做法为局部线性回归 + 三角核权重，带宽按 MSE 最优或 Calonico–Cattaneo–Titiunik (2014) 方法选择，并报告 RD 图。
效应是断点处的 LATE，向远离断点的人群外推需谨慎。
模糊断点（fuzzy RD）以「是否越线」为工具变量估计：Stata `rdrobust y x, c(0) fuzzy(t)`，R `rdrobust` 加 `fuzzy = "t"`。
**代码**：

```stata
ssc install rdrobust
ssc install rddensity
rdrobust y x, c(0)          // x 为中心化运行变量
rdplot y x, c(0)            // RD 图
rddensity x, c(0)           // 密度操纵检验
```

```r
library(rdrobust)
rdrobust(y = dat$y, x = dat$x, c = 0)
rddensity::rddensity(dat$x, c = 0)   # 操纵检验
```

**报告要点**：报告带宽选择方法与不同带宽下的稳健性、RD 图（断点两侧拟合线 + 置信区间）、操纵检验与协变量连续性检验。
**常见错误**：不做密度与协变量连续性检验、不报带宽敏感性就下因果结论。

---

### D4 合成控制法（SCM）
**适用**：政策只影响一个（或少数）处理单元、且有较长政策前后面板与多个未处理对照单元时，估计政策对处理单元的效应。
**要点**：用对照组单元的加权组合构造「合成对照」，权重在政策前时期最小化处理单元与合成对照在结局及预测协变量上的差异；政策后两者的差距即政策效应轨迹。
推断依靠**安慰剂检验**：把每个对照单元依次当作「假处理」单元重复估计，看真实效应是否显著大于假效应分布（可换算置换 p 值）。
要求政策前时期足够长、合成拟合良好（政策前 RMSPE 小）。
权重通常非负且和为 1；Stata `synth` 的 `nested` 选项与 R 侧嵌套求解参数（如 `optimxmethod`）控制权重求解（以帮助文档为准）。
**代码**：

```stata
ssc install synth
tsset id time
synth y x1 x2 y(1990(1)1999), trunit(1) trperiod(2000) fig
* 安慰剂检验：对每个对照单元重复 synth 比较效应轨迹（以 help synth 为准）
```

```r
dp <- Synth::dataprep(foo = dat, predictors = c("x1", "x2"), dependent = "y",
                      unit.variable = "id", time.variable = "time",
                      treatment.identifier = 1, controls.identifier = 2:20,
                      time.predictors.prior = 1990:1999, time.optimize.ssr = 1990:1999)
s1 <- Synth::synth(dp)
```

**报告要点**：报告合成对照的权重构成与政策前拟合优度（RMSPE）、政策后效应轨迹图，以及安慰剂/置换检验结果。
**常见错误**：政策前拟合差（RMSPE 大）仍解读效应，或不做安慰剂检验。

---

### D5 事件研究法
**适用**：政策冲击时点明确、需考察效应随时间的动态变化（事前趋势与事后轨迹）时使用，适用于面板或重复截面数据。
**要点**：以相对事件时间（relative time）生成各期虚拟变量并与处理组交互，取政策前一期（-1）为参照。
**事前系数应不显著**（平行趋势检验），事后系数轨迹刻画效应的动态演化；事件研究图（系数 + 置信区间）是标准呈现。
基准设定为双向固定效应 + 聚类稳健标准误；交错采用（异质性处理时点）时双向固定效应估计可能有偏，应加做 Sun–Abraham (2021) 或 Callaway–Sant'Anna (2021) 稳健性。
各期系数均相对 -1 期解读（-1 期系数被吸收进常数项）。
正式平行趋势检验可对事前交互项做联合检验（`reghdfe` 后用 `test` 联合检验事前系数）。
若为重复截面而非面板，个体固定效应不可用，改用群组固定效应并按群组聚类。
**代码**：

```stata
ssc install reghdfe
ssc install coefplot
reghdfe y ib(-1).time#i.treat, absorb(id time) vce(cluster id)
coefplot, keep(*.time#1.treat)          // 事件研究图
```

```r
library(fixest)
m <- feols(y ~ i(time, treat, ref = -1) | id + time, data = dat)
coefplot(m)                              // 事件研究图
```

**报告要点**：报告事件研究图（事前系数应为零、事后轨迹与显著性）、参照期与聚类层级；交错采用时说明稳健性检验。
**常见错误**：只看平均效应不看动态轨迹，或事前趋势不平行仍解读为因果。

---

### D6 双重差分（DID）

> 深入阅读：[交错DID的ATT(g,t)与合格对照](staggered-did-skill.md)。
**适用**：政策在某时点只冲击处理组、且有政策前后数据时，比较两组变化之差估计处理效应。
**要点**：识别假设为**平行趋势**（无政策时两组结局变化相同）；交互项 treat × post 的系数即 DID 估计量；交错采用时注意异质性处理效应偏误（见 D5 稳健性建议）。
**代码**：
```stata
* Stata：2×2 DID（交互项系数即效应）
reg y i.treat##i.post, vce(cluster id)
```
```r
# R：fixest 双向固定效应 DID
feols(y ~ treat*post | id + time, data = dat, cluster = ~id)
```
**报告要点**：报告 DID 系数与聚类稳健标准误，附平行趋势检验（事件研究图）与安慰剂检验。
**常见错误**：标准误不聚类或聚类层级错误，或不检验平行趋势。
> 详见 DID skill：完整流程、平行趋势检验与稳健性设计。

---

### D7 间断时间序列（ITS）
**适用**：单一单元（或合并总体）有政策前后多期连续时间序列时，检验政策的水平与斜率改变。
**要点**：分段回归 Y = β0 + β1·time + β2·post + β3·time_after；β2 为水平（即时）改变，β3 为斜率（长期）改变；须用 Newey–West 或 Prais–Winsten 校正自相关（季节性需处理）。
**代码**：
```stata
tsset time
gen post = (time >= t0)          // t0 = 政策实施期
gen time_after = (time - t0) * post
newey y time post time_after, lag(1)
```
```r
m <- lm(y ~ time + post + time_after, data = dat)
lmtest::coeftest(m, vcov = sandwich::NeweyWest(m, lag = 1))
```
**报告要点**：报告 β2、β3 与自相关校正方法，并画拟合线与无政策反事实对照。
**常见错误**：忽略自相关导致标准误低估，或政策前观测点太少无法识别趋势。
> 详见 ITS skill：完整流程、自相关诊断与季节性处理。

---

### D8 三重差分（DDD）
**适用**：DID 中处理组与对照组存在不同时间趋势或额外混淆时，加入第三个维度（地区/人群/结果）作双重对照。
**要点**：DDD = 处理 × 时间 × 第三维度的三重交互项系数，通过「差异中的差异的差异」消除两组各自时间趋势与第三维度的共同冲击。
应同时报告各双重交互项，并说明第三维度剔除何种混淆。
**代码**：
```stata
* Stata：DDD（三重交互项系数即效应）
reg y i.treat##i.post##i.group, vce(cluster id)
```
```r
# R：DDD 三重交互（主效应被固定效应吸收时仅保留三重交互）
feols(y ~ treat:post:group | id + time, data = dat, cluster = ~id)
```
**报告要点**：报告三重交互系数与各双重交互项，解释第三维度如何剔除混淆。
**常见错误**：只报三重交互不报双重交互，或交互显著即强行因果解读而忽视机制。
> 详见 DDD skill：完整流程、识别假设与稳健性设计。

---


### D9 目标试验模拟 TTE

**适用**：把观察性数据分析对应到明确的假想试验协议。

**逻辑与操作**：先定义目标与数据单位，再核对假设、执行诊断并解释结果。完整步骤、代码和边界见 [目标试验模拟 TTE专题](target-trial-emulation-skill.md)。

**报告要点**：七要素协议、time zero、estimand、识别假设、诊断及TARGET。

**常见错误**：资格、治疗分配和随访起点错位，或用未来依从性定义基线治疗组。

### D10 IPW与边际结构模型 MSM

**适用**：基线或时间变化治疗的加权因果估计。

**逻辑与操作**：先定义目标与数据单位，再核对假设、执行诊断并解释结果。完整步骤、代码和边界见 [IPW与边际结构模型 MSM专题](advanced-causal-inference-skill.md)。

**报告要点**：概率模型、稳定化、截尾、平衡、有效样本量与删失机制。

**常见错误**：忽略极端权重、正值性或受既往治疗影响的时间变化混杂。

### D11 g-formula与双稳健估计

**适用**：按指定干预标准化结局，或结合治疗和结局模型估计目标效应。

**逻辑与操作**：先定义目标与数据单位，再核对假设、执行诊断并解释结果。完整步骤、代码和边界见 [g-formula与双稳健估计专题](advanced-causal-inference-skill.md)。

**报告要点**：目标人群、干预策略、模型设定、标准化流程和推断方法。

**常见错误**：把双稳健误解为对未测量混杂也稳健；不核对两模型的假设。

### D12 双重机器学习 DML

**适用**：高维或非线性混杂下，利用正交得分与交叉拟合估计因果参数。

**逻辑与操作**：先定义目标与数据单位，再核对假设、执行诊断并解释结果。完整步骤、代码和边界见 [双重机器学习 DML专题](advanced-causal-inference-skill.md)。

**报告要点**：得分/模型、估计目标、折分单位、学习器、调参与聚类推断。

**常见错误**：把高预测准确率视为因果识别，或在测试折调参导致信息泄漏。

### D13 合成双重差分 SDID

**适用**：政策面板中同时构造单位权重与时间权重。

**逻辑与操作**：先定义目标与数据单位，再核对假设、执行诊断并解释结果。完整步骤、代码和边界见 [合成双重差分 SDID专题](advanced-causal-inference-skill.md)。

**报告要点**：供体池、处理日期、政策前拟合、权重、溢出及少簇推断。

**常见错误**：忽略供体受政策影响，或把交错处理直接套入同时处理的块状实现。

### D14 定量偏倚与敏感性分析

**适用**：评估未测量混杂、误分类和选择机制对主要结论的影响。

**逻辑与操作**：先定义目标与数据单位，再核对假设、执行诊断并解释结果。完整步骤、代码和边界见 [定量偏倚与敏感性分析专题](advanced-causal-inference-skill.md)。

**报告要点**：偏倚机制、参数来源、情景范围、效应变化及剩余局限。

**常见错误**：把敏感性摘要当作不存在偏倚的证据，或随意选择参数范围。

### D15 交错 DID / 分批处理

**适用**：按首次政策批次估计ATT(g,t)并聚合动态与总体效应。

**逻辑与操作**：先定义目标与数据单位，再核对假设、执行诊断并解释结果。完整步骤、代码和边界见 [交错 DID / 分批处理专题](staggered-did-skill.md)。

**报告要点**：处理批次、对照、预期、支持、聚合权重、置信带与聚类。

**常见错误**：异质效应下直接套传统TWFE，或把已处理单位当合格对照。

### D16 熵平衡与重叠权重

**适用**：通过矩约束或强调重叠构建可比样本，明确新的目标总体。

**逻辑与操作**：先定义目标与数据单位，再核对假设、执行诊断并解释结果。完整步骤、代码和边界见 [熵平衡与重叠权重专题](propensity-score-skill.md)。

**报告要点**：目标、约束/权重公式、重叠、有效样本量与推断。

**常见错误**：只看平衡不看权重集中，或把ATO结果仍称原总体ATE。

## E 类：数据科学与预测建模（8个方法）

> 方法学速查手册 E 类条目片段（E1–E6）。每个方法按「适用 / 要点 / 代码（Stata + R）/ 报告要点 / 常见错误」展开；代码为可运行核心命令，示例数据与阈值仅作演示。E3/E4 为速查条目，完整流程详见机器学习 skill。

### E1 缺失数据与多重插补

**适用**：数据存在缺失值但需完整数据集进行回归/模型分析时，用多重插补替代删除法以减少偏倚与效能损失（如问卷调查、纵向随访、电子病历数据）。

**要点**：缺失机制决定处理策略——完全随机缺失 MCAR（缺失与任何变量无关）、随机缺失 MAR（缺失与已观测变量有关，条件于已观测变量后可忽略）、非随机缺失 MNAR（缺失与缺失值本身有关）。多重插补（MI）用链式方程生成 m 个（建议 20–50 次，缺失比例越高 m 越大）完整数据集，分别分析后用 Rubin 规则合并点估计与方差，正确体现插补不确定性；优于均值填补与完整病例分析（后者仅在 MCAR 且缺失比例很小时基本无偏）。MNAR 下 MI 仍有偏，需做敏感性分析（如 worst-case、δ 调整）；插补模型应纳入与缺失性及结局相关的辅助变量。

**代码**：

```stata
* ===== Stata =====
mi set mlong                                  // 声明多重插补 long 格式
mi register imputed y x                       // 登记含缺失的待插补变量
mi impute chained (regress) y (logit) x = z age, add(20) rseed(2026)
                                              // y 连续用 regress、x 二分类用 logit；z age 为完整辅助变量
mi estimate: regress y x age                  // 逐集估计 + Rubin 规则合并
* ===== R =====
library(mice)
imp <- mice(data, m = 20, seed = 2026)        # 链式方程多重插补
densityplot(imp)                              # 检查插补值分布
fit <- with(imp, glm(y ~ x + age, family = binomial()))   # 逐集估计
pool(fit)                                     # Rubin 规则合并
```

**报告要点**：报告各变量缺失比例与缺失模式，明确缺失机制假设（MCAR/MAR/MNAR 判断依据）、插补模型与 m 值、Rubin 合并规则；并与完整病例分析并列作敏感性比较。

**常见错误**：用均值/末次观测填补、只插补 1 次（m=1）当多重插补，或插补模型漏掉预测缺失与结局的关键变量。

### E2 样本量与统计效能计算

**适用**：研究设计阶段确定所需样本量、或评估既有样本的检验效能，保证结果可解释（RCT、两率比较、抽样调查、预测模型开发）。

**要点**：先固定四个量：效应量（取最小临床重要差异 MCID，或文献/预试验值）、显著性水平 α（通常 0.05）、目标效能 1−β（通常 0.8/0.9）与设计参数（组间比、方差），已知任意三个可解出第四个。效应量须由专业判断或外部证据给定，不能用当前观测数据倒推（事后效能无意义）。连续结局用标准化均数差 d = (μ1−μ2)/σ，分类结局用率差或 OR；分层、整群与重复测量设计须乘设计效应 DE = 1 + (m−1)ICC 并预留脱落率。

**代码**：

```stata
* ===== Stata =====
power twomeans 100 110, sd(20) power(0.8)    // 两组均数 100 vs 110、SD 20 → 每组 n
power twomeans 100 110, sd(20) n(64)         // 固定每组 n=64 → 检验效能
power twoproportions 0.30 0.20, power(0.8)   // 两率 0.30 vs 0.20 → 每组 n
power oneproportion 0.20 0.25                // 单组率 0.20 对目标 0.25
power twomeans 100 110, sd(20) power(0.8) nratio(2)   // 组间比 1:2 设计
* ===== R =====
library(pwr)
pwr.t.test(d = 0.5, sig.level = 0.05, power = 0.8, type = "two.sample")  // 每组 n
pwr.t.test(d = 0.5, sig.level = 0.05, n = 64, type = "two.sample")       // 固定 n → 效能
pwr.2p.test(h = ES.h(0.3, 0.2), sig.level = 0.05, power = 0.8)           // 两率
pwr.anova.test(k = 3, f = 0.25, sig.level = 0.05, power = 0.8)           // 多组方差分析
pwr.chisq.test(w = 0.1, df = 1, sig.level = 0.05, power = 0.8)           // 卡方检验
```

**报告要点**：报告四个要素（效应量及其来源、α、1−β、设计参数），给出每组所需样本量、考虑脱落后最终样本量；附效能曲线或关键参数敏感性表。

**常见错误**：用观察到的效应量做“事后效能”论证、忽略脱落率与整群/重复测量的设计效应，或多重比较不校正 α。

### E3 LASSO/弹性网与正则化

**适用**：高维数据（变量数接近或超过样本量）下的变量筛选与惩罚回归，防止过拟合。

**要点**：LASSO 用 L1 惩罚把部分系数压缩为 0，实现变量选择；岭回归用 L2 收缩但不稀疏；弹性网混合两者，变量高度相关时更稳。λ 用交叉验证选择（常取 1-SE 规则，模型更简约）；结局决定 family（连续/二分类）。LASSO 系数有收缩偏倚，P 值需谨慎（样本拆分或去偏）。完整预处理、调参与评估流程详见机器学习 skill。

**代码**：

```stata
* ===== Stata =====
lasso linear y x1-x200, selection(cv) nolog    // 连续结局，CV 选 λ
lasso logit y x1-x200, selection(cv)           // 二分类结局
* ===== R =====
cvfit <- glmnet::cv.glmnet(x, y, family = "binomial", alpha = 0.5)   // 弹性网
coef(cvfit, s = "lambda.1se")                  // 1-SE λ 的系数
```

**报告要点**：报告惩罚类型与 α、λ 选择规则（min/1se）与 CV 折数、最终保留变量及系数（注明标准化与否）。
**常见错误**：把 LASSO 系数直接报显著性 P 值、在测试集上选 λ、连续变量不标准化。

### E4 随机森林与 XGBoost

**适用**：非线性、含复杂交互或高维的分类/回归预测任务，作为灵活强基线模型（风险预测、结局分类）。

**要点**：随机森林 = 多棵决策树 bagging + 随机特征子集，抗过拟合、稳健，袋外（OOB）误差可作内部验证；XGBoost = 梯度提升迭代修正残差，精度常更高但对超参敏感、需早停。两者均须调参（树数/深度/学习率）并在独立测试集或交叉验证评估。完整调参、变量重要性与模型解释流程详见机器学习 skill。

**代码**：

```stata
* ===== Stata =====
* Stata 无内置实现；可经 PyStata 调用 Python（sklearn/xgboost）
* ===== R =====
library(randomForest); library(xgboost); set.seed(2026)
rf <- randomForest(y ~ ., data = train, ntree = 500, importance = TRUE)   # 分类/回归自动识别
bst <- xgboost(data = xgb.DMatrix(as.matrix(train_x), label = train_y),
               nrounds = 100, eta = 0.1, max_depth = 3, objective = "binary:logistic")
```

**报告要点**：报告调参范围、重抽样策略（CV/独立测试集）与区分度、校准指标（AUC、Brier）。
**常见错误**：只在训练集报告精度（过拟合乐观），或不做调优直接套用默认参数。

### E5 聚类分析（K-means/层次聚类）

> 深入阅读：[聚类的距离、算法与稳定性](clustering-analysis-skill.md)。

**适用**：无监督地将个体或变量分成同质组，用于人群分型（患者亚组、健康素养/就医行为类型）、变量降维与问卷条目归类。

**要点**：分析前须标准化（量纲不同时）；K-means 将样本迭代分配到最近质心、最小化组内平方和，需预先指定 K；层次聚类（凝聚/分裂）不预设 K，按距离逐层合并并用树状图展示。K 的选择：肘部法（组内平方和随 K 的拐点）、轮廓系数（越接近 1 越好）或树状图截断，最终由专业可解释性定夺。结果依赖距离度量（欧氏/曼哈顿）、标准化与初始值，须设种子并比较多种方案验证稳定性。

**代码**：

```stata
* ===== Stata =====
cluster kmeans x1 x2, k(3) start(krandom(2026)) name(k3)   // K-means（x1 x2 宜先标准化）
cluster stop, rule(duda)                      // 肘部指标辅助选 K（Duda-Hart）
cluster wardslinkage x1 x2, name(hc)          // 层次聚类（Ward 法）
cluster dendrogram hc, labels(id)             // 树状图
cluster generate g = groups(k3)               // 保存 K-means 分组结果
* ===== R =====
set.seed(2026); km <- kmeans(scale(x), centers = 3, nstart = 25)   # K-means（scale 标准化）
d <- dist(scale(x)); hc <- hclust(d, method = "ward.D2")           # 层次聚类（Ward 法）
plot(hc); table(cutree(hc, k = 3), km$cluster)                     # 树状图；两法结果交叉
library(cluster)
mean(silhouette(km$cluster, dist(scale(x)))[, 3])                  # 平均轮廓系数（选 K）
```

**报告要点**：报告标准化方式、距离度量与聚类方法、K 的选择依据（肘部/轮廓系数/树状图）与各组样本量；描述各组特征并验证稳定性（不同种子/子样本重复）。

**常见错误**：不标准化直接聚类、凭主观随意定 K 不报告依据，或聚类后不验证稳定性与可解释性。

### E6 贝叶斯统计入门

**适用**：需要结合先验知识、小样本推断、或输出参数完整后验分布与不确定性区间的分析（网状 meta 分析、卫生经济学评价、适应性设计、层次模型）。

**要点**：贝叶斯推断 = 后验 ∝ 先验 × 似然，先验（文献/专家/无信息弱信息）与数据结合更新信念；区间用 95% 可信区间（credible interval：参数有 95% 概率落于其中），区别于频率学派的置信区间。用 MCMC 抽样近似后验，必须检查收敛（链轨迹混合、R-hat < 1.01、有效样本量 ESS 充足）并报告链数、迭代数与预热期。先验选择需说明依据并做先验敏感性分析（不同先验下结论是否稳健）。

**代码**：

```stata
* ===== Stata =====
bayes, mcmcsize(10000) rseed(2026): regress y x   // 默认弱信息先验的贝叶斯回归
bayesgraph diagnostics {y:x}                      // 轨迹/自相关/R-hat 收敛诊断
bayesstats ess                                   // 有效样本量
bayesstats summary, credible                     // 后验均值与 95% 可信区间
bayes, prior({y:x}, normal(0, 10)) rseed(2026): regress y x   // 自定义先验 → 敏感性分析
* ===== R =====
library(brms)
fit <- brm(y ~ x, data = d, chains = 4, iter = 2000, warmup = 1000, seed = 2026)
summary(fit)                                 # 后验均值、95% CI、R-hat、ESS
plot(fit)                                    # 链轨迹与后验密度
hypothesis(fit, "x > 0")                     # 后验概率 P(x > 0)
```

**报告要点**：报告先验分布及依据、MCMC 设置（链数/迭代/预热/种子）与收敛指标（R-hat、ESS）；效应量给出后验均值与 95% 可信区间，附先验敏感性分析。

**常见错误**：把可信区间当置信区间解释、不检查收敛就下结论，或先验无依据且不做敏感性分析。

---


### E7 纵向轨迹与潜类别

**适用**：识别重复测量数据中的不同变化模式。

**逻辑与操作**：先定义目标与数据单位，再核对假设、执行诊断并解释结果。完整步骤、代码和边界见 [纵向轨迹与潜类别专题](longitudinal-public-data-skill.md)。

**报告要点**：时间编码、模型/类数选择、类别大小、后验概率及失访处理。

**常见错误**：把统计类别当自然人群，忽略后验分类不确定性和类数稳定性。

### E8 预测验证、校准与净获益

**适用**：从内部/外部验证判断模型判别、风险准确性和决策价值。

**逻辑与操作**：先定义目标与数据单位，再核对假设、执行诊断并解释结果。完整步骤、代码和边界见 [预测验证、校准与净获益专题](medical-ai-evaluation-skill.md)。

**报告要点**：独立验证设计、校准截距/斜率、区间、阈值及净获益比较。

**常见错误**：仅凭训练集AUC或SHAP图宣称模型临床可用。

## 方法学速查手册 · F 类：社会医学与卫生经济学理论框架（11个方法）

> 理论框架类不做数值计算代码，统一用「论文应用模板」：变量清单 / 分析段落提纲 / 简化估计式，能配 Stata / R 示例的一律给出。每个理论都要落到「变量选择—分析—报告」的论文流程上，而不是停在名词介绍。

### F1 Andersen 卫生服务利用行为模型

**适用**：解释与预测个体卫生服务利用（是否就诊、就诊次数、慢病服务利用），为就医行为与卫生服务研究提供变量选择框架。

**要点**：模型由三类因素构成——倾向特征（predisposing：年龄、性别、教育、健康信念）、使能资源（enabling：收入、医保、机构可及性）、需要因素（need：自评健康、疾病状况），其中需要因素通常对利用的解释力最强。初始模型（1960s）后经多轮扩展，加入卫生系统、环境与健康行为/结局（BMH 版）。论文用法：按三因素组织自变量并分组报告，检验「需要主导」假设。

**代码**（论文应用模板：三因素变量清单 + 回归）：

```stata
* Andersen 三因素变量清单（就诊行为研究示例）
* 倾向特征 predisposing：age 年龄、female 性别(0/1)、edu 教育年限
* 使能资源 enabling：lnincome 家庭收入对数、insured 是否参保(0/1)、dist 距最近机构(km)
* 需要因素 need：sahealth 自评健康(1-5)、chronic 慢病种数
logit visit age female edu lnincome insured dist sahealth chronic, or
```

**报告要点**：理论框架部分画三因素模型图，逐项说明本研究变量与模型的对应关系；讨论中用「需要因素是否主导、使能因素是否受限」呼应模型预测并推导政策含义。

**常见错误**：三因素不齐却声称「基于 Andersen 模型」；只列变量不说明归属与依据，模型沦为装饰。

### F2 Grossman 健康需求模型

**适用**：把健康视为人力资本，分析健康投资的决定因素及健康与教育、收入、年龄的关系，用于健康不平等与老年健康研究。

**要点**：健康既是消费品（健康本身产生效用）又是投资品（健康时间增加劳动供给）；健康存量随年龄折旧，个体通过医疗服务等投资维持存量，投资量由工资率、教育效率与医疗服务价格决定。论文用法：用模型说明健康方程为何必须控制收入、教育与年龄，并据此提出机制性假设（教育提高健康生产效率）。

**代码**（论文应用模板：需求简化式示意）：

```stata
* 健康需求简化式：H = f(工资率 w, 教育 E, 年龄 t, 医疗服务价格 p)
* 预期：教育、工资系数为正（效率与投资回报），年龄为负（折旧），价格为负
reg health lnwage edu age age2 lnprice
* 教育→健康的机制检验：加入知识/行为中介后看 edu 系数变化
reg health edu age
reg health edu age knowl healthbehavior
```

**报告要点**：在理论框架部分以「健康存量—投资」逻辑引出变量；讨论中解释教育与年龄的系数方向如何与折旧、效率机制一致。

**常见错误**：与 Andersen 模型混用（前者是需求决定机制，后者是利用分析框架）；只做相关回归不交代机制。

### F3 健康信念模型 HBM

**适用**：解释与干预个体预防性健康行为（疫苗接种、筛查、体检、遵医服药），为问卷维度设计与干预设计提供依据。

**要点**：行为由六个构念驱动——感知易感性、感知严重性、感知收益、感知障碍、行动线索、自我效能（后两者为修订版加入）。论文用法：按维度编制 Likert 量表条目（每维度 ≥ 3 题，取均值入模），以预防行为为因变量做 logistic 回归或结构方程。

**代码**（论文应用模板：维度变量清单）：

```stata
* HBM 维度量表（Likert 1-5，各维度多题取均值）与预防行为模型
* perc_sus 感知易感性 | perc_sev 感知严重性 | perc_ben 感知收益 | perc_bar 感知障碍
* cue 行动线索(0/1) | selfeff 自我效能
logit vaccinate perc_sus perc_sev perc_ben perc_bar cue selfeff, or
```

**报告要点**：方法部分报各维度的信度（Cronbach's α）与效度；讨论按维度解释作用方向，并把「感知障碍最显著」等结果转化为干预靶点。

**常见错误**：每维度只设 1 题且不报信效度；用 HBM 解释治疗行为（HBM 针对预防行为，治疗行为宜用 TPB）。

### F4 计划行为理论 TPB

**适用**：解释由行为意向驱动的健康行为（锻炼、戒烟、手卫生、用药依从），用于问卷编制与行为干预研究。

**要点**：行为意向由态度、主观规范、知觉行为控制（PBC）三者决定；行为则由意向与 PBC 共同预测，且 PBC 可绕过意向直接作用于行为。论文用法：用结构方程模型（SEM）检验 TPB 全路径，报告路径系数与模型拟合指标。

**代码**（论文应用模板：SEM 语法）：

```stata
* Stata sem：观测题项均值入模（单指标路径模型）
sem (intention <- att sn pbc) (behavior <- intention pbc), standardized
estat gof, stats(all)
```

```r
# R lavaan 等价写法（多题项做潜变量时用）
library(lavaan)
model <- 'intention ~ att + sn + pbc
          behavior ~ intention + pbc'
fit <- sem(model, data = d)
summary(fit, standardized = TRUE, fit.measures = TRUE)
```

**报告要点**：报告路径系数、R² 与 CFI/TLI/RMSEA；讨论中解释意向→行为缺口（intention-behavior gap）及 PBC 直接路径的干预含义。

**常见错误**：用普通回归替代路径检验且不报拟合指标；遗漏「知觉行为控制→行为」这条直接路径。

### F5 社会生态学模型

**适用**：识别个体、人际、社区/组织、政策多层影响因素，为多水平干预设计（慢病管理、控烟、体力活动促进）提供框架。

**要点**：行为由嵌套层级共同决定——个体内（知识、信念）、人际（家庭、同伴）、组织/社区（学校、工作场所、社区资源）、政策（法规、环境）。论文用法：按层级组织变量，用多水平模型同时估计个体层与群体层效应，干预建议对应各层级。

**代码**（论文应用模板：分层变量 + 多水平模型）：

```stata
* 个体层：age sex edu | 人际层：fam_support 家庭支持(0-3) | 社区层：park_density 绿地密度
* 随机截距两水平模型（个体嵌套于社区）
mixed behavior age sex edu fam_support park_density || community: , mle
* 跨层交互：社区环境调节个体因素
mixed behavior age sex edu fam_support c.fam_support#c.park_density || community: , mle
```

**报告要点**：理论框架部分画出层级图并标出本研究落在哪几层；讨论按层级解读系数（个体层 vs 群体层）并给出分层干预建议。

**常见错误**：声称用生态学框架却把社区变量当个体变量做 OLS（忽视组内相关、易犯生态谬误）；层级划分与数据结构不匹配。

### F6 健康公平与正义理论（Rawls / Sen 可行能力）

**适用**：为健康公平测量与卫生政策评价提供规范基础，用于健康不平等测量、医保待遇公平性与政策伦理分析。

**要点**：Rawls 差别原则——社会经济不平等安排应使最不利者获益最大（maximin）；Sen 可行能力——评价的核心是「人实际能做到什么（functionings/capabilities）」而非资源占有。论文用法：理论部分明确采纳的正义观，并据此选择公平测量指标（如集中指数、公平缺口）与「有利变化」的判定标准。

**代码**（论文应用模板：集中指数计算）：

```stata
* 集中指数 CI（便利回归法）：按收入排序后，2*σ²_rank*(h/μ) 对 rank 回归
sort income
gen rank = _n / _N
quietly summarize h
local mu = r(mean)
quietly summarize rank
gen lhs = 2 * r(Var) * (h / `mu')
reg lhs rank
* _b[rank] 即 CI（正=亲富，负=亲穷）；SSC 版：ssc install conindex; conindex h, rankvar(income)
```

**报告要点**：理论框架部分说明采纳 Rawls 或 Sen 的理由，并解释它如何决定公平指标选择与结果判定；讨论中回到所采纳的正义观检验结论。

**常见错误**：公平测量指标与所宣称的正义理论脱节；把「公平」与「平等」混为一谈，未交代价值判断。

### F7 健康社会决定因素框架（CSDH）

**适用**：分析结构性/中间决定因素如何沿社会经济梯度造成健康不平等，用于健康不平等机制与「将健康融入所有政策」研究。

**要点**：因果链为「社会经济政治环境 → 社会经济地位（SES）→ 中间决定因素（物质条件、行为、生物、心理社会）→ 健康」，卫生系统本身也是社会决定因素。论文用法：把变量明确归入结构层与中间层，用分解方法（Oaxaca-Blinder、集中指数分解）量化各因素对健康不平等的贡献。

**代码**（论文应用模板：分层变量 + 分解）：

```stata
* 结构层：ses 教育年限/收入/职业 | 中间层：housing 居住条件、smoke 吸烟、stress 心理压力 | 结局：health
* Oaxaca-Blinder 分解：高/低 SES 组健康差距分解为「禀赋效应 + 系数效应」
ssc install oaxaca
oaxaca health housing smoke stress, by(ses_group)
```

**报告要点**：在理论框架中画出 CSDH 因果链并把变量标注到对应层级；讨论中报告各决定因素的贡献排序，指出政策切入点（结构层优先）。

**常见错误**：把 CSDH 当普通回归变量清单，不做分解或机制分析；结构层与中间层混排、因果方向写反。

### F8 委托代理与供方诱导需求（SID）

**适用**：解释医患信息不对称下供方诱导过度需求，用于卫生服务利用、过度医疗与医保控费研究。

**要点**：医患信息不对称使医生同时充当患者代理人（决定需求）与服务提供者（获取收益），存在为自身利益诱导需求的动机；经典经验检验是「床位数/医生密度 → 利用量」正相关（Roemer 定律：造好的床位就会被填满）。论文用法：在控制需要与价格后，用供给资源变量的系数作为诱导需求的证据。

**代码**（论文应用模板：简化估计式）：

```stata
* 供方诱导需求简化估计式：y = β0 + β1·beds + β2·need + β3·price + ε
* β1 > 0 且在控制需要与价格后仍显著 → 诱导需求的证据
reg visits beds_per1000 chronic lnprice insurance age
* 稳健性：换供给指标（医生密度）重复
reg visits doctors_per1000 chronic lnprice insurance age
```

**报告要点**：讨论中如实报告识别问题（供给与需求同时决定、地区未观测因素），说明缓解策略（工具变量、自然实验、滞后期）并谨慎表述因果。

**常见错误**：把床位—利用正相关直接等同于诱导需求，忽视人口需要、价格与反向因果；不讨论内生性。

### F9 市场失灵与政府干预（公共品 / 外部性 / 信息不对称）

**适用**：论证政府干预卫生领域的必要性与方式选择，用于卫生政策分析、医保制度设计与公共卫生筹资研究。

**要点**：卫生领域存在公共品（传染病防控、健康信息，非竞争非排他）、正外部性（疫苗接种、抗生素合理使用，私人收益低于社会收益）、信息不对称（医患关系诱导需求；保险市场逆选择与道德风险），市场配置失灵为政府干预提供理由。论文用法：把每条政策建议对应到具体失灵类型，形成「失灵—干预—机制」论证链。

**代码**（论文应用模板：失灵—干预论证链提纲）：

```text
论文应用模板：市场失灵 → 对应卫生服务 → 干预手段（论证链）
· 公共品：传染病监测、控烟立法（非竞争、非排他）→ 政府提供或强制
· 正外部性：疫苗接种（私人收益 < 社会收益，私人最优接种量低于社会最优）→ 补贴、免疫规划
· 信息不对称①：医患（供方诱导需求）→ 支付方式改革、监管、信息公开
· 信息不对称②：保险市场（逆选择、道德风险）→ 强制参保、共付与起付线设计
```

**报告要点**：在政策建议部分逐条注明依据的是哪类市场失灵及其证据；讨论政府干预本身可能的失灵（政府失灵）以保持分析平衡。

**常见错误**：只罗列失灵类型不落到具体干预设计；不区分市场失灵与政府失灵，政策建议缺乏对应机制。

### F10 制度变迁与路径依赖（医改分析）

**适用**：解释医改政策演进、制度为何难以变革及政策扩散规律，用于卫生体制改革与医保制度变迁研究。

**要点**：制度变迁受历史路径约束——初始制度选择通过规模报酬递增、学习效应、协调效应、适应性预期与利益集团锁定而自我强化；制度突破依赖关键节点或外部冲击。论文用法：以政策时间线证据识别锁定机制与变迁触发点，解释医改反复或试点—推广过程。

**代码**（论文应用模板：制度变迁分析提纲）：

```text
论文应用模板：医改制度变迁分析提纲
1) 锁定起点：初始制度安排（如公费/劳保/新农合分轨起点）与关键节点（2009 新医改）
2) 自我强化机制：规模报酬递增、沉没成本、利益集团、适应性预期
3) 锁定证据：政策时间线——改革方案反复收敛于既有路径（如碎片化格局持续）
4) 变迁触发：外部冲击（疫情、财政压力）或内部矛盾积累 → 制度突破/渐进调整
```

**报告要点**：用时间线表格或图呈现制度沿革，逐条对应锁定机制；讨论说明本案例中路径依赖的强度与突破条件，避免历史决定论。

**常见错误**：把路径依赖当「历史决定论」只叙述不分析机制；时间线证据与机制脱节，未说明变迁触发条件。

---



### F11 实施科学：CFIR / RE-AIM

**适用**：解释干预为何难落地，并评价触达、实施与维持。

**逻辑与操作**：先定义目标与数据单位，再核对假设、执行诊断并解释结果。完整步骤、代码和边界见 [实施科学：CFIR / RE-AIM专题](implementation-equity-skill.md)。

**报告要点**：框架版本、构念定义、分母、层级、时间窗与弱势群体触达。

**常见错误**：堆叠框架名称而没有构念测量，把实施结局与健康结局混为一谈。

## G 类：定性与结构方程专题（4个方法）

### G1 扎根理论（Grounded Theory）

**适用**：从访谈/观察/文本材料中归纳建构理论（医患体验、政策执行过程、患者旅程）。

**要点**：三级编码——开放式编码（贴标签）、主轴编码（范畴与关系）、选择性编码（核心范畴与故事线）；理论抽样与饱和（新资料不再产生新范畴）；备忘录贯穿全程。Strauss-Corbin 偏结构化程序，Charmaz 偏建构主义。质性分析以**人工编码为主**，软件（NVivo/MAXQDA）与文本挖掘只是辅助；报告遵循 COREQ。

**代码**：R 文本辅助（词频与共现），编码本身仍由人完成：

```r
library(quanteda)
corp <- corpus(data.frame(text = interviews$text, doc_id = interviews$id))
dfm(corp, remove = stopwords("zh"), remove_punct = TRUE) |>
  textstat_frequency(n = 30)          # 高频词提示开放编码线索
```

**报告要点**：编码表（范畴-子范畴-原始引文）、理论模型图、饱和度说明、研究者立场。

**常见错误**：只贴词频不做理论建构；样本量小却宣称饱和；混淆描述与理论。

### G2 结构方程模型（SEM）

**适用**：多个潜变量（如健康素养、自我效能）与其测量条目、结构路径的联合检验。

**要点**：测量模型（CFA，效度：载荷、CR、AVE）与结构模型（路径）两步或联合估计；拟合指标 CFI/TLI ≥ 0.90、RMSEA < 0.08、SRMR < 0.08，修正指数仅用于理论允许的修正；样本量经验：每个自由参数 10–20 例。

**代码**：

```stata
* Stata：三潜变量 SEM
sem (HL -> x1 x2 x3) (SE -> y1 y2 y3) (AD -> z1 z2 z3) (HL -> SE) (SE -> AD), method(mlmv)
estat gof
```

```r
# R：lavaan 等价写法
library(lavaan)
model <- ' HL =~ x1 + x2 + x3
           SE =~ y1 + y2 + y3
           AD =~ z1 + z2 + z3
           SE ~ HL
           AD ~ SE '
fit <- sem(model, data = dat)
fitMeasures(fit, c("cfi","tli","rmsea","srmr"))
```

**报告要点**：模型图、载荷与路径系数表（标准化）、拟合指标与判断标准、测量不变性（如做群组比较）。

**常见错误**：把探索性结果当验证性模型报告；只看卡方显著性；无理论依据乱加修正路径。

### G3 多层 / 多重嵌套 SEM（Multilevel SEM）

**适用**：嵌套数据（患者—科室—医院、居民—社区）的潜变量与结构关系，区分组内与组间效应。

**要点**：先检验 ICC 判断是否需要多层；组内/组间变异分解；样本量经验：组数至少 30–50，组内个体可少；随机截距与随机斜率设定要有理论依据。

**代码**：

```stata
* Stata：gsem 多层（医院随机截距）
gsem (HL -> x1 x2 x3) (SE -> y1 y2 y3) (SE <- HL M1[hospital]), vce(cluster hospital)
```

```r
# R：lavaan 双层写法
library(lavaan)
model2 <- '
  level: 1
    SEw =~ y1 + y2 + y3
    SEw ~ HLw
  level: 2
    SEb =~ y1 + y2 + y3
    SEb ~ HLb '
fit2 <- sem(model2, data = dat, cluster = "hospital")
```

**报告要点**：ICC、组内与组间两层结果分表、层级说明与软件语法对照。

**常见错误**：组数很少却做多层 SEM；把组间结论套到个体；忽略聚类稳健标准误。

### G4 fsQCA 模糊集定性比较分析

**适用**：中小样本、多条路径达到同一结果（组态视角），如「基层能力建设成效」的条件组合：资源投入、人员配置、激励机制、信息化。

**要点**：校准（直接法三锚点：完全隶属/交叉点/完全不隶属）；必要条件（一致性 ≥ 0.9）与充分条件（一致性 ≥ 0.75–0.8）；真值表与最小化得到复杂解/简约解/中间解；覆盖率（原始/唯一）；与回归互补：fsQCA 问「哪些组合」，回归问「净效应」。

**代码**：

```r
library(QCA)
dat2 <- data.frame(成效 = calibrate(score, c(60, 75, 90)),
                   资源 = calibrate(res, c(10, 20, 30)),
                   人员 = calibrate(staff, c(5, 10, 15)),
                   激励 = calibrate(inc, c(0.2, 0.5, 0.8)),
                   信息化 = calibrate(it, c(1, 3, 5)))
tt <- truthTable(dat2, outcome = "成效", n.cut = 1, incl.cut = 0.8)
minimize(tt, include = "?")            # 中间解
```

```stata
* Stata：SSC 的 fuzzy 包做校准等（以 help fuzzy 为准）
ssc install fuzzy
fzcalc zy, low(60) cross(75) high(90)
```

**报告要点**：校准锚点与理由、真值表、各解的组态表、一致性与覆盖率、稳健性（锚点微调/阈值变动）。

**常见错误**：校准锚点拍脑袋不给理由；把组态解当净效应做因果推断；样本与条件数比例失衡。

> 以上 4 条的完整教程（含完整模拟数据与更多代码）见 **sem-qca-qualitative-skill.md**。


---

## 深度 Skill 目录（配套教程）

| Skill | 文件 | 一句话 |
| --- | --- | --- |
| 卫生经济学评价教程 | health-economics-tutorial-skill.md | CEA/CUA 总纲（9 步，含 CHEERS 报告） |
| DCE 设计助手 | dce-design-assistant-skill.md | 离散选择实验正交/D-效率设计与 clogit/mixlogit/潜类别 |
| Markov 模型助手 | markov-model-skill.md | 队列模拟成本-效果分析（ICER、PSA） |
| 机器学习助手 | machine-learning-skill.md | 费用预测与风险分层（LASSO/RF/XGBoost/SHAP） |
| DID 双重差分助手 | did-skill.md | 政策效果评估（含多期 csdid） |
| ITS 间断时间序列助手 | its-skill.md | 单序列干预的水平与趋势变化 |
| DDD 三重差分助手 | ddd-skill.md | 双重差分之差 |
| Meta 分析助手 | meta-analysis-skill.md | 系统评价效应合并与异质性 |
| 定性方法与结构方程专题 | sem-qca-qualitative-skill.md | 扎根理论 / SEM / 多层SEM / fsQCA |
| 学术写作规范润色 | academic-copyediting-skill.md | 中文学术文本规范润色 |

## 常见错误清单（跨方法通用）

- [ ] 方法选择先于研究问题（应该反过来：问题 → 设计 → 方法）
- [ ] 只报告系数不报告假设检验（平行趋势、IIA、比例风险等）
- [ ] 标准误层级与数据层级不符（未 cluster 到合适的层级）
- [ ] 把「相关/预测」当「因果」表述
- [ ] 第三方命令未注明来源与版本（ssc / R 包版本）
- [ ] 敏感性分析只做一种或不做
- [ ] 效应量只报 p 值不报置信区间与实际意义（临床/经济意义）
- [ ] 理论与变量脱节（理论框架当装饰）
- [ ] 代码不可复现（未设种子、未保存 do/R 脚本与数据版本）
- [ ] 报告模板生搬硬套，未按目标期刊调整

## 使用提示

- 先查「适用」定方法，再读「要点」定口径，最后照「代码」落地；报告前过一遍对应深度 Skill 的报告清单。
- 本手册与十份深度 Skill 均为 MIT 许可的可移植提示词，可直接喂给大语言模型辅助起草方法学章节（AI 参与请如实披露）。

---

## 引用 / Citation

中文：杜思娴. socialmedicineskills：社医卫管方法学速查手册 [EB/OL]. (2026). https://naturedu.github.io/socialmedicine/.

English: Du, S. (2026). *socialmedicineskills: A methods quick-reference for social medicine and health management* [Skill definition]. https://naturedu.github.io/socialmedicine/.
## H 类：证据综合

### H1 系统评价与证据分级

**适用**：对明确研究问题系统检索、筛选、评价并综合证据。

**逻辑与操作**：明确研究单位与目标，按专题完成设计、估计与验证。详细流程和示例见 [系统评价与证据分级专题](research-workflow-skill.md)。

**报告要点**：方案、检索式/日期、双人流程、排除原因、偏倚与确定性。

**常见错误**：只有检索和文章汇总，没有预设标准、偏倚评价或排除记录。

### H2 成对 Meta 分析

**适用**：对可合并的同类比较与结局估计综合效应。

**逻辑与操作**：明确研究单位与目标，按专题完成设计、估计与验证。详细流程和示例见 [成对 Meta 分析专题](meta-analysis-skill.md)。

**报告要点**：效应方向、模型、τ²、区间、研究设计与异质性解释。

**常见错误**：混合不相容效应尺度，按I²阈值机械选择模型。

### H3 网状 Meta 分析 NMA

**适用**：在连通且可比的研究网络中比较三个及以上干预。

**逻辑与操作**：明确研究单位与目标，按专题完成设计、估计与验证。详细流程和示例见 [网状 Meta 分析 NMA专题](network-meta-analysis-skill.md)。

**报告要点**：节点、网络、多臂相关、直接间接证据、诊断与CINeMA。

**常见错误**：缺少传递性论证，仅凭排序宣布最佳干预。

### H4 meta-meta / 伞状综述

**适用**：以系统综述为单位绘制证据版图并解释结论差异。

**逻辑与操作**：明确研究单位与目标，按专题完成设计、估计与验证。详细流程和示例见 [meta-meta / 伞状综述专题](umbrella-review-skill.md)。

**报告要点**：综述家族、研究重叠矩阵、CCA、方法质量与重叠处理。

**常见错误**：忽略原始研究重复，直接将多个Meta合并效应再次独立加权。

### H5 范围综述 Scoping review

**适用**：梳理概念、研究类型、测量方法和证据缺口。

**逻辑与操作**：明确研究单位与目标，按专题完成设计、估计与验证。详细流程和示例见 [范围综述 Scoping review专题](research-workflow-skill.md)。

**报告要点**：问题框架、检索范围、筛选、资料制图与PRISMA-ScR。

**常见错误**：把非系统的文献罗列称范围综述，或据研究数量断言干预有效。


## I 类：模拟与决策

### I1 蒙特卡洛方法学模拟

**适用**：在已知真值下评估估计方法的偏倚、覆盖与效能。

**逻辑与操作**：明确研究单位与目标，按专题完成设计、估计与验证。详细流程和示例见 [蒙特卡洛方法学模拟专题](monte-carlo-simulation-skill.md)。

**报告要点**：ADEMP、场景、种子、重复次数依据、性能及MC误差。

**常见错误**：不报告MCSE与失败率，或只选择对方法有利的数据生成机制。

### I2 概率敏感性分析 PSA

**适用**：传播模型参数不确定性，估计成本效果决策的不确定性。

**逻辑与操作**：明确研究单位与目标，按专题完成设计、估计与验证。详细流程和示例见 [概率敏感性分析 PSA专题](monte-carlo-simulation-skill.md)。

**报告要点**：联合分布、参数依据、相关性、阈值、INMB与CEAC。

**常见错误**：破坏参数相关性，把成本效果概率当临床有效概率。

### I3 个体微观模拟

**适用**：模拟具有异质风险和历史依赖的个体路径。

**逻辑与操作**：明确研究单位与目标，按专题完成设计、估计与验证。详细流程和示例见 [个体微观模拟专题](simulation-models-skill.md)。

**报告要点**：个体属性、事件风险、路径记忆、校准、验证与随机数。

**常见错误**：混淆个体随机变异与参数不确定性，忽略模拟噪声收敛。

### I4 离散事件模拟 DES

**适用**：分析到达、排队、床位与转诊等资源受限系统。

**逻辑与操作**：明确研究单位与目标，按专题完成设计、估计与验证。详细流程和示例见 [离散事件模拟 DES专题](simulation-models-skill.md)。

**报告要点**：实体、事件、队列纪律、分布、容量、重复与验证。

**常见错误**：忽略到达率、容量、暖机期或重复运行，仅展示单次输出。

### I5 系统动力学 SD

**适用**：刻画存量、流量、反馈与延迟驱动的系统变化。

**逻辑与操作**：明确研究单位与目标，按专题完成设计、估计与验证。详细流程和示例见 [系统动力学 SD专题](simulation-models-skill.md)。

**报告要点**：边界、存量流量方程、延迟、参数、校准与情景。

**常见错误**：仅画因果回路图便声称完成定量模拟，或忽视量纲一致。

### I6 多主体模型 ABM

**适用**：通过异质主体互动和适应解释系统涌现。

**逻辑与操作**：明确研究单位与目标，按专题完成设计、估计与验证。详细流程和示例见 [多主体模型 ABM专题](simulation-models-skill.md)。

**报告要点**：主体、环境、决策与互动、调度、参数来源及验证。

**常见错误**：把AI助手称为仿真主体，或用无依据行为规则预设政策效果。


## J 类：政策文本与AI评价

### J1 三维政策框架与 PMC

**适用**：按可复核codebook整理政策工具、对象、目标和内容覆盖。

**逻辑与操作**：明确研究单位与目标，按专题完成设计、估计与验证。详细流程和示例见 [三维政策框架与 PMC专题](policy-text-analysis-skill.md)。

**报告要点**：政策范围、单位、指标依据、编码规则、权重与原文定位。

**常见错误**：把文件得分直接解释为政策执行或健康改善。

### J2 LDA / BERTopic 主题分析

**适用**：探索政策语料中的主题及其变化。

**逻辑与操作**：明确研究单位与目标，按专题完成设计、估计与验证。详细流程和示例见 [LDA / BERTopic 主题分析专题](policy-text-analysis-skill.md)。

**报告要点**：语料、预处理、词典/嵌入、参数、主题稳定性及代表文本。

**常见错误**：只看主题词命名，不回读原文或检验参数/主题数稳定性。

### J3 LLM辅助编码与关系抽取

**适用**：把政策或病历条款转成有证据定位的结构化变量。

**逻辑与操作**：明确研究单位与目标，按专题完成设计、估计与验证。详细流程和示例见 [LLM辅助编码与关系抽取专题](policy-text-analysis-skill.md)。

**报告要点**：codebook、人工仲裁、模型/prompt版本、测试、错误与修订率。

**常见错误**：无人工金标准、无独立测试，用模型自报信心代替评价。

### J4 医疗大模型配对评价

**适用**：比较模型与人工的准确性、安全性、时间和实际决策表现。

**逻辑与操作**：明确研究单位与目标，按专题完成设计、估计与验证。详细流程和示例见 [医疗大模型配对评价专题](medical-ai-evaluation-skill.md)。

**报告要点**：病例与参考标准、盲评、配对/聚类、区间、失败及亚组。

**常见错误**：把同一病例多轮回答当独立样本，忽略拒答或严重错误。
