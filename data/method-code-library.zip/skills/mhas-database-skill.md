---
name: mhas-database
description: 健康、家庭和经济追踪；Core、代理、家属、Master Follow-Up、Mex-Cog及插补资料分开。
---

# 🌍 MHAS / ENASEM · Mexican Health and Aging Study

核验日期：2026-10-23。健康、家庭和经济追踪；Core、代理、家属、Master Follow-Up、Mex-Cog及插补资料分开。

## 先用主随访框架辨识样本

本机清洗CSV242列、wave1—5；原始目录另有2021主随访、直接/代理/家属访谈和认知文件。这说明“存在原始资料”和“已整理为可分析面板”不同，不能把CSV中的最后一波当作调查所有可用数据的终点。

`H_MHAS_c2`元数据的`r1wthh`和`r1wtresp`分别为家庭、个人分析权重。原始经济题、构造变量与插补经济文件分开：缺失、插补和观测标记都应保留；财富极端值、币值和家庭/夫妻单位按文档处理。

### 认知、代理与退出

对每次直接访谈、代理访谈、知情人及家属退出建立类型标记。不能把代理未做本人认知题看作0分，也不能把不同测验的缺测当作患病。Mex-Cog是深度认知产品；与Core连接时保留进入该子研究的资格和选择概率，不能把其诊断标签不加校正外推到全体。

Master Follow-Up辅助核对可访、存活/死亡及跨波状态，但只有官方定义支持的日期才能用于随访。对于访谈间新发失能，事件时间通常为区间；要区分基线患病、首次观察阳性与确切起病。

### 家庭与迁移研究

子女迁移、汇款、同住和照护是不同暴露。海外迁移选择可能与家庭资源和健康相关；个体FE、匹配或加入更多控制不自动解决该选择。建议先明确照护者是谁、照护对象是谁、回顾窗口和转移方向，再提出有时间顺序的模型。

### 复现材料

保存官方Question Concordance中对应题目位置、跨波合并规则和本地字段映射。公共复现包发布脚本和字典，不附再分发受限的微观文件；按MHAS使用条款保留项目致谢和研究成果报告要求。


## R与Stata：标准化层的最小接口

以下变量名是**分析层约定**，不是原始数据库通用字段。必须先完成题级映射。若没有所需设计变量，先回查官方设计文件，不能任意生成PSU或权重。

```r
# d: id=字符个人键, year=实际访谈年, y=已核对结局, x=预定协变量
stopifnot(!anyNA(d$id), !anyDuplicated(d[c("id", "year")]))
d <- d[order(d$id, d$year), ]
# 纵向条件关联；不自动等于政策因果效应
m <- fixest::feols(y ~ x | id + year, cluster = ~id, data = d)
summary(m)
# 按复杂抽样作描述应另用对应设计与权重，而非仅cluster=id。
```

```stata
* id_s 是字符键，pid 仅作当前数据内面板编码，不输出映射。
assert !missing(id_s, year)
isid id_s year
egen long pid = group(id_s)
xtset pid year
xtreg y x i.year, fe vce(cluster pid)
* 单波数据不运行此面板流程；先选择合适的survey描述/横断面模型。
```

## 🧺 先把数据放进正确的小篮子

建立文件清单：`study / release / module / wave / visit_date / unit / key / source / permission`。文件名中的版本字母、下载年份和访谈波次分开。原始文件只读；另存标准化层和分析层。先输出字段名、标签、值标签、缺失码和连接诊断，再决定变量能否使用。

每个分析变量至少记录：概念、原题、来源变量、适用人群、回顾窗口、单位、跳答路径、特殊码、代理回答、派生公式、可用波次、权重及核验状态。不得只凭中文列名判断值域或方向；`weight`在多份表中是体重。

## 从问题到估计的顺序

1. 写清目标人群、暴露/政策、比较组、结局和时间零点。区分人群患病比例、个体内变化、预测准确性和政策效应。
2. 画样本流：原始入样→年龄/资格→完成访谈→完成测量→连接随访→分析样本。死亡、失访、跳题、拒答、未测量分别记，不统一改成0。
3. 描述研究所需字段在每波的可用性。两波数据最多支持一次变化；多波轨迹需要足够重复观测、可比较测量与合理类数。
4. 按估计目标选择横断面、纵向或特定组件权重；权重不能凭变量名相似借用。失访加权需要可解释的响应模型和正值性诊断。
5. 面板FE估计的是个体内关联；PSM不能消除未测混杂；交错DID还需真实政策起始、前期趋势和有效对照；TTE需对齐资格、分组及随访起点。
6. 保留未加权人数、加权估计与区间。重复测量、家庭和地区依赖按设计处理；缺失值插补与抽样设计的结合需写明方法，避免把插补当作增加独立样本。

## 交付与报告

交付版本清单、变量字典、跨波可用矩阵、连接诊断、样本流、缺失/失访表、模型脚本和执行记录。公共教程仅包含方法与元数据；获准数据留在授权环境。问卷存在某题、当前文件有字段、分析样本有有效观测是三个不同层次。

相关路线：[纵向研究](longitudinal-public-data-skill.md)、[PSM/加权](propensity-score-skill.md)、[分批DID](staggered-did-skill.md)、[目标试验模拟](target-trial-emulation-skill.md)、[计量模型](econometric-modeling-skill.md)。R/Stata代码为接口模板，本次未在这两个运行时执行。

## 官方出处与版本边界

- [MHAS Data Products](https://www.mhasweb.org/DataProducts/Home.aspx)：注册和使用条款；公共数据不等于可任意再分发。
- [MHAS Documentation](https://www.mhasweb.org/Documentation/Home.aspx)：抽样权重、跨波合并、直接/代理/家属问卷和问题对照。
- [Gateway Harmonized Data](https://www.g2aging.org/harmonized-data/overview?dataset=2)：跨研究产品导航；统一变量仍有研究特定差异。
