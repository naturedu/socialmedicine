普贤社会医学方法与数据库代码包

当前索引286段教学代码，完整Skill及支持资源在skills/。
snippets/保存每段代码；data/code-library.json和CSV保留原始来源行号、上下文和执行状态。
原有代码与新增数据库接口均保留。混合或不完整片段必须结合完整Skill审读，不能批量直接执行。
R/Stata示例未逐项运行，不表示已对真实数据完成验证；变量、权重、版本和识别假设需先核对。
不含受访者微观数据或私人聊天。网页：https://naturedu.github.io/socialmedicine/
